import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


            /* jQuery(document).ready(function () {
                 jQuery('#sidebarCollapse').on('click', function () {
                     jQuery('#sidebar').toggleClass('active');
                     jQuery(this).toggleClass('active');
                 });
             });
      */
    
}
