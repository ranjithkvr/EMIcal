import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landingheader',
  templateUrl: './landingheader.component.html',
  styleUrls: ['./landingheader.component.css']
})
export class LandingheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
