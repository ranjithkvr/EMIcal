$(function(){

    $('#startdate').datetimepicker({
        mask:'9999/19/39',
        format:'Y-m-d',       
        timepicker:false,
        minDate:'-1970/01/01' 
    });


    $('#enddate_cal').datetimepicker({
        mask:'9999/19/39',
        format:'Y-m-d',
        timepicker:false,
        minDate:'-1970/01/01'
    });

    $('#starttime').datetimepicker({       
        datepicker:false,
        mask:'29:59',
        format:'H:i a'
    });



    $('#endtime').datetimepicker({       
        datepicker:false,
        mask:'29:59',
        format:'H:i a'
        
    });

    document.getElementById('createRequest_form')[0].focus()

})

/* 
(function() { 
    
      
    // startDate
         var StartDate = new mdDateTimePicker.default({
            type: 'date',
            orientation : 'Landscape',
            mode : false,
            future : moment().add(100, 'years'),
            past : moment().subtract(0, 'days')
          });

          
      
          var toggleButton = document.getElementById('startdate');
          var toggleButtonIcon = document.getElementById('id-of-button-to-open-it');

          toggleButtonIcon.addEventListener('click', function() {
            StartDate.toggle();
          });
    
          toggleButton.addEventListener('click', function() {
            StartDate.toggle();
          });
    
          StartDate.trigger = document.getElementById('startdate');
          
          document.getElementById('startdate').addEventListener('onOk', function() {
             this.value = moment(StartDate.time.toString()).format("YYYY-MM-DD");
        });
    
        document.getElementById('startdate').addEventListener('onCancel', function() {
                  this.value = "YYYY-MM-DD";
                });



     // endDate
         var endDate = new mdDateTimePicker.default({
            type: 'date',
            orientation : 'Landscape',
            mode : false,
            future : moment().add(100, 'years'),
            past : moment().subtract(0, 'days')
          });
          var toggleButton = document.getElementById('enddate_icon');
          var toggleButtonEndDate = document.getElementById('enddate_cal');

          toggleButtonEndDate.addEventListener('click', function() {
            endDate.toggle();
          });
    
          toggleButton.addEventListener('click', function() {
            endDate.toggle();
          });
    
          endDate.trigger = document.getElementById('enddate_cal');
          
          document.getElementById('enddate_cal').addEventListener('onOk', function() {
                        this.value = moment(endDate.time.toString()).format("YYYY-MM-DD");
        });
    
        document.getElementById('startdate').addEventListener('onCancel', function() {
                  this.value = "YYYY-MM-DD";
                });
    
    //  start time
        var startTime = new mdDateTimePicker.default({
            type: 'time',
          orientation: 'PORTRAIT'
        });


        document.getElementById('starttime').addEventListener('click', function() {
            startTime.toggle();
        });
        
        document.getElementById('startTime_icon').addEventListener('click', function() {
            startTime.toggle();
        });
    
        startTime.trigger = document.getElementById('starttime');
    
        document.getElementById('starttime').addEventListener('onOk', function() {         
            var time = moment(startTime.time).format('hh:mm A');
            this.value = time;
        });


        //  end time
        var endTime = new mdDateTimePicker.default({
            type: 'time',
          orientation: 'PORTRAIT'
        });
    
      
    
        document.getElementById('endTime_icon').addEventListener('click', function() {
            endTime.toggle();
        });

        document.getElementById('endtime').addEventListener('click', function() {
            endTime.toggle();
        });
    
        endTime.trigger = document.getElementById('endtime');
    
        document.getElementById('endtime').addEventListener('onOk', function() {
            //  this.value = moment(StartDate.time.toString()).format("MM/DD/YYYY");
            var time = moment(endTime.time).format('hh:mm A');
            this.value = time;
        });
       
       
    
    }).call(this); */


    // daily / weekly / monthly


    function clearWeekly(){
        $('#advanced_settings .mdl-graybox input.mdl-checkbox__input').each(function(index){
            if(this.checked){
                $(this).prop('checked', false); 
                $(this).parent().removeClass('is-checked');

            }
        })
    }

    var recurOptions = document.getElementsByName("recurOptions");
    var recu_value;

    for(let i=0; i < recurOptions.length;i++){
        recurOptions[i].addEventListener('click',function(){
            

            if(this.checked){
                recu_value = this.value;
              //  console.log(recu_value);

                if(recu_value === 'daily'){
                 
                        document.getElementById('monthly-section').style.display = 'none';
                        document.getElementById('weekly-section').style.display = 'none';
                        document.getElementById('daily-section').style.display = 'block';

                        $("select.selct_months").multipleSelect("uncheckAll");
                        $("select.selct_days").multipleSelect("uncheckAll");


                        clearWeekly();
                      
                }

                else if(recu_value === 'weekly'){
                        
                               document.getElementById('daily-section').style.display = 'none';
                               document.getElementById('monthly-section').style.display = 'none';
                             document.getElementById('weekly-section').style.display = 'block';

                             $(document).find("#every").val("");
                             $("select.selct_months").multipleSelect("uncheckAll");
                             $("select.selct_days").multipleSelect("uncheckAll");
                      
                }
                else if(recu_value === 'monthly'){

                    
                           document.getElementById('daily-section').style.display = 'none';
                           document.getElementById('monthly-section').style.display = 'block';
                         document.getElementById('weekly-section').style.display = 'none';                        
                         
                         clearWeekly();
                         $(document).find("#every").val("");
                  
            }
               }
           
           
        })
     
    }

    
 
  
    $( document ).ready(function() {



        var recurrence = document.getElementById("recurrence");
        var advancedSettings = document.getElementById("advanced_settings");
        var chekedValue = null;
    
                // tabs
                function DWMTabs(){       
                    
                    let recurOptions = document.getElementsByName("recurOptions");
                    let recu_value = 'daily';

                            for(let i=0; i < recurOptions.length;i++){
                            
                                if(recu_value === 'daily'){
                                        
                                            document.getElementById('monthly-section').style.display = 'none';
                                            document.getElementById('weekly-section').style.display = 'none';
                                            document.getElementById('daily-section').style.display = 'block';
                                            $('#daily').attr('checked');
                                            $('#daily').parent().addClass('is-checked');

                                            $('#weekly').removeAttr('checked');
                                            $('#weekly').parent().removeClass('is-checked');

                                            $('#monthly').removeAttr('checked');
                                            $('#monthly').parent().removeClass('is-checked');

                                            $('.mdl-checkbox').removeClass('is-checked');

                                            $('.selct_months button span').html("");
                                            $('.selct_days button span').html("")
                                        
                                    }

                                
                        }

                    }
                    



        // recurrence

 
  

    function clearVal(recurrenceInput){

        
       
        if(recurrenceInput){  
            $('#advanced_settings .mdl-graybox input').each(function(index){
               $(this).attr('disabled',false);
               $(this).parent().removeClass('is-disabled');
               
           })
   
           $('#advanced_settings .mdl-graybox button').each(function(index){
               $(this).attr('disabled',false); 
           })
   
           $('.mdl-graybox span,.mdl-graybox label').removeClass('is-disabled');

           $('.recurrence label').addClass('is-checked');
           $('#recurrence').attr('checked',true); 
   
           }else{     

              $('#advanced_settings .mdl-graybox input').each(function(index){
               $(this).attr('disabled',true);   
               $(this).parent().addClass('is-disabled');
   
               })
   
               $('#advanced_settings .mdl-graybox button').each(function(index){
                   $(this).attr('disabled',true);
                 
                   
               })
               $('.recurrence label').removeClass('is-checked');
               $('#recurrence').attr('checked',false); 
   
               $('.mdl-graybox span,.mdl-graybox label').addClass('is-disabled');
           }
    }


    recurrence.addEventListener('change', function(){
        chekedValue = recurrence.checked;  
        clearVal(chekedValue);
    })

// Reset
    $(document).on('click','#reset', function(){
       /*  $('.recurrence label').removeClass('is-checked');
        $('#recurrence').attr('checked',false); 
 */
        chekedValue = recurrence.checked;

     if(chekedValue === true){       
        clearVal(false);       
        DWMTabs();
     }else{
        DWMTabs();
     }
     
     $("select.selctOpt_groups").multipleSelect("uncheckAll");
       
      })
  
 
   var IsRecurrenceVal = document.getElementById("recurrence").checked;
   clearVal(IsRecurrenceVal);

    // on form submit
    $(document).on('click','#createRequestData', function(e){

        e.preventDefault();
        IsRecurrenceVal =  document.getElementById("recurrence").checked;
        
        var Frequency,
            weekly = [],
            selectClsMutipleDD,
            Recurr_monthly,
            Recurr_Days,
            endDate = 
            enddate_cal =  $('#enddate_cal').val(),
            daysByWeekly = [],
            userName = $.session.get("userName");
           

            if(enddate_cal === "" || enddate_cal === null){
                enddate_cal = null
            }

            if(IsRecurrenceVal === false){
                Frequency = "OneTime";
            }else{
                $('input:radio[name=recurOptions]').each(function() 
                {    
                    if($(this).is(':checked'))
                    Frequency = $(this).val();

                  
                });             
            }


            $('input[name=weeklyOption]:checked').map(function(){
                weekly.push($(this).val())
            })
          
            Recurr_monthly =   $("select.selct_months").multipleSelect("getSelects");            
            Recurr_Days = $("select.selct_days").multipleSelect("getSelects");

            selectClsMutipleDD = $("select#selctOpt_groups").multipleSelect("getSelects");

            $("input:checkbox[name=weeklyOption]:checked").each(function() {
                daysByWeekly.push($(this).val());
           });
           

          function createRequest(){ 

          //  chekedValue = recurrence.checked;  

            
            let createData = JSON.stringify({
                "Name": $('#nameofRequest').val(),
                "CIs": selectClsMutipleDD.toString(),
                "StartDate": $('#startdate').val(),
                "StartTime": $('#starttime').val(),
                "EndTime": $('#endtime').val(),
                "IsRecurrence": IsRecurrenceVal ,
                "Frequency": Frequency,
                "Dates":  Recurr_Days.toString(),
                "Days":   daysByWeekly.toString(),
                "IsEnddate": false,
                "EndDate": enddate_cal,
                "IsActive": true,
                "CreatedBy": userName,
                "CreatedDateTime": moment().format(),
                "ModifiedBy": null,
                "ModifiedDateTime": null,
                "Month": Recurr_monthly.toString(),
                "Recurevery": $("#every").val()
              });

            
            console.log(createData);
              

             var settings = {
                "async": true,
                "crossDomain": true,
                "url": APIurl+"Api/AddRequest",
                "method": "POST",
                "headers": {
                  "content-type": "application/json",
                  "authenticationtoken": "testuser",
                
                },
                "processData": false,
                "data": createData
              }
             

              $.ajax(settings).done(function (response) { 

             console.log(response);
                window['counter'] = 0;
                var snackbarContainer = document.querySelector('#demo-toast-example');
                var showToastButton = document.querySelector('#demo-show-toast');          
                   
                var data = {message: 'your request was submitted successfully',  timeout: 2000 };
                    snackbarContainer.MaterialSnackbar.showSnackbar(data);

                    
             $('input[type=text]').val('');
             $('input[type=radio]').checked=false;
             $('input[type=checkbox]').checked=false;
             $('.selct_months button span').html("");
             $('.selct_days button span').html("")
             $('.selctOpt_groups button span').html("");  
             $('.recurrence label').addClass('is-checked');
             $('#recurrence').attr('checked');
    
           /*  chekedValue = recurrence.checked;

            if(chekedValue === false){
                chekedValue = fasle;       
                clearVal(chekedValue);        
                DWMTabs();
            }else{
                DWMTabs();
            } */

            clearVal(false); 
            DWMTabs();

            $("select.selctOpt_groups").multipleSelect("uncheckAll");


                  
              });

}

var currentDate = moment().format("YYYY-MM-DD");
var startTimeval  = $('#starttime').val();
var EndTimeVal = $('#endtime').val();

var start =  $('#startdate').val();
var end = enddate_cal;


function checkDate(start, end){
    var mStart = moment(start);
    var mEnd = moment(end);   
   return mEnd.isSameOrAfter(mStart)  
   }

   var checkEndDate = checkDate(start, end);
  
// validation
if($('#nameofRequest').val() === null || $('#nameofRequest').val() === ""){
    alert("Name of Request is required");
    return false;
} else if(selectClsMutipleDD.length === 0){
    alert("Select Servers is required");
    return false; 
}  
else if($('#startdate').val() === null || $('#startdate').val() === ""){
    alert("Please select Start Date");
    return false; 
}
else if(enddate_cal === null || enddate_cal === ""){
    alert("Please select End Date");
    return false; 
}
else  if(!checkEndDate){
        alert('End date should not less than start date');
        return false;
} 
else if($('#starttime').val() === null || $('#starttime').val() === ""){
    alert("Please select Start Time");
    return false; 
}

else if($('#endtime').val() === null || $('#endtime').val() === ""){
    alert("Please select End Time");
    return false; 
}


else if(recurrence.checked === true){
 
     
    for(let i=0; i < recurOptions.length;i++){

        if(recurOptions[i].checked){
            recu_value = recurOptions[i].value;
         
            if(recu_value === 'daily'){

                if($("#every").val() === "" || $("#every").val() === null ){
                    alert("Please select the number of days");
                    return false;
                }
                else{
                    createRequest();            
                    return true;
                }

            }
             else if(recu_value === 'weekly'){

                var checkedLength = $('input[name=weeklyOption]:checked').length;
                   if( checkedLength === 0)
                    {
                        alert("Please select the Weekly");
                        return false;
                    }
                    else{

                        createRequest(); 
                        return true;
                    }
            }
            else if(recu_value === 'monthly'){

                if(Recurr_monthly.length === 0){
                    alert("Please select any one Month ");
                    return false;

                }else if(Recurr_Days.length  === 0){
                    alert("Please select any one day");
                    return false;
                }  
                else{
                    createRequest(); 
                    return true;
                }         
            }
           
        } 
    }
    return false;
 }
else{
   
    createRequest();
    return true; 
}
       
    })






})