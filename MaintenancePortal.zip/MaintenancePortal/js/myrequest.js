"use strict";
  
$( document ).ready(function() {

    function MyRequests(){

        var html ="";
        var dataID = document.getElementById("myRequest_data");
        var serverDD,
            frequencyData;
        $(document).find('.loader').show();
        var settings = {
            "async": true,
            "crossDomain": true,
            "url": APIurl+"Api/MyRequests",
            "method": "GET",
            "headers": {
              "content-type": "application/json",
              "authenticationtoken": "testuser",
              "cache-control": "no-cache",
              "postman-token": "447a0142-440f-79ff-b898-861179c2cf4b"
            }
          }

          $.ajax(settings).done(function (response) {

           var data = JSON.parse(response);
          
           var numbHits;
           numbHits = data.hits.hits;

           if(data.hits !== undefined || data.hits.hits !== undefined || data.hits !== null || data.hits.hits !== null){

            var datLength = numbHits.length,
                checkboxSlider,
                colunCLS,
                colunList = [],
                html2,
                colunList,
                title,
                noOfDays,
                titleHead;

     

           for(let i=0; i < datLength; i++){
             
         
            var serverDD = "",
            frequencyData = "", 
            frequencyDD = "",
            numberofDayDD = "",         
             frquencyLink = "";

             frquencyLink += '<a style="cursor:pointer;color:black;"  class="show-dialog ' + numbHits[i]._source.Frequency + '"><span style="min-width:60px;display:inline-block">' + numbHits[i]._source.Frequency + '</span><img  src="images/calendar.svg" style="font-size:16px;position: relative;top:0px;" class="material-icons">'
                       
             frquencyLink += '</a>' 

              colunCLS = numbHits[i]._source.CIs.split(',');


               if( numbHits[i]._source.EndDate === null){
                 numbHits[i]._source.EndDate = "-"
               } 

               if(numbHits[i]._source.IsActive === false){ 
                checkboxSlider = '<label class="switch" for="status_'+ [i] + '"><input  data-id='+ numbHits[i]._source.MaintenanceId +' type="checkbox" name="status_' + [i] +'"><span class="slider round"></span></label>'
             }else{
                checkboxSlider = '<label  class="switch" for="status_'+ [i] + '"><input data-id='+ numbHits[i]._source.MaintenanceId +' type="checkbox" name="status_' + [i] +'" checked="' + numbHits[i]._source.IsActive + '"><span class="slider round"></span></label>'
             } 


             if(numbHits[i]._source.Frequency === 'daily'){
               title = "";
               titleHead = "Daily"

               frequencyDD = numbHits[i]._source.Recurevery
             
             }else if(numbHits[i]._source.Frequency === 'weekly')
              {
                title = numbHits[i]._source.Days;
                titleHead = "Weeks"

                $.each(title.split(','),function (index,value) {
                  frequencyDD += '<li class="mdl-list__item mdl-card--border" style="float:left;min-width:120px">'
                  frequencyDD +=  value +' </li>';
              });
              
  
                
              }else if(numbHits[i]._source.Frequency === 'monthly')
              {

                title = numbHits[i]._source.Month;
                titleHead = "Months"
                noOfDays =  numbHits[i]._source.Dates;

           

                $.each(title.split(','),function (index,value) {
                  frequencyDD += '<li class="mdl-list__item mdl-card--border" style="float:left">'
                  frequencyDD +=  value +' </li>';
                });
               
                numberofDayDD = '<h6 style="clear:both;margin-top:65px">Days</h6><hr><ul>'

                $.each(noOfDays.split(','),function (index,value) {
                  numberofDayDD += '<li class="mdl-list__item mdl-card--border" style="float:left">'
                  numberofDayDD +=  value +' </li>';
                });
                
               // frequencyDD += '<li style="clear:both;mdl-list__item mdl-card--border">' + numberofDayDD + '</li>';
               numberofDayDD += '<ul>'

              }else{
                title = "";

                frquencyLink =  '<a style="color:black;"><span style="min-width:60px;display:inline-block">' + numbHits[i]._source.Frequency + '</span>'             
                frquencyLink += '</a>'
              }

            if(title.split(',').length !== 1){

             /*  $.each(title.split(','),function (index,value) {
                frequencyDD += '<li class="mdl-list__item mdl-card--border" style="float:left">'
                frequencyDD +=  value +' </li>';   
            });
            */

            }
            


/* $.each(title,function (index,value) {
       frequencyDD += '<li>' + value + '</li>'  
}); */
                  

              $.each(colunCLS,function (index,value) {
                serverDD += '<li class="mdl-list__item mdl-card--border">'
                serverDD +=  value +' </li>';
             });

              html += '<tr><td>' + numbHits[i]._source.Name + '</td>'
              html += '<td>' + colunCLS.length  +  '<a class="show-dialog" style="line-height: 29px;min-width:auto;height:25px;box-shodow:0 0 0 #fff;font-size:12px;border-radius:0" id="show-dialog" type="button" class="mdl-button " > <img  src="images/view.svg" class="material-icons" style="width:24px;font-size:16px;cursor:pointer;position: relative;top: 0px;">'
             
             
              html += '</a><dialog class="mdl-dialog" style="display:none;background:#fff;position:absolute;top:30%;margin:0 250px 0 380px;padding:15px;"><div class="mdl-dialog__content"><h6>Servers</h6><hr/><ul class="demo-list-item mdl-list">' + serverDD + '</ul></div></dialog></td>' 
              html += '<td>' + numbHits[i]._source.StartDate + '</td>'     
              html += '<td>' + numbHits[i]._source.EndDate + '</td>'     
              html += '<td class="text-Caps">' 


              html += frquencyLink

          /*     html += '<a style="cursor:pointer;color:black;" title="' + title  + '" class="show-dialog ' + numbHits[i]._source.Frequency + '"><span style="min-width:60px;display:inline-block">' + numbHits[i]._source.Frequency + '</span><i style="font-size:16px;position: relative;top: 4px;" class="material-icons">'
              html += 'calendar_today</i>'              
              html += '</a>'  */
              
              html +='<dialog class="mdl-dialog" style="width:630px;display:none;background:#fff;position:absolute;top:30%;left:0;margin:0 250px 0 250px;padding:15px;"><div class="mdl-dialog__content"><h6>' + titleHead + '</h6><hr/><ul class="demo-list-item mdl-list">' + frequencyDD + '</ul>'+  numberofDayDD  + '</div></dialog></td>'     
              html += '<td>' + numbHits[i]._source.StartTime + '</td>'
              html += '<td>' + numbHits[i]._source.EndTime + '</td>'
              html += '<td>' + checkboxSlider + '</td>'
              
              html += '</tr>';
 
            
           }

         
          
 
           $("#myRequest_data").html(html);
          $('.dataTableInit').DataTable( {
            columnDefs: [
                { "width": "28%","targets": 0 , searchable: true },
                { "width": "10%","targets": 1 ,searchable: true },
                { "width": "20%","targets": 2  },
                { "width": "20%","targets": 3  },
                { "width": "10%","targets": 4  },
                { "width": "10%","targets": 5  },
                { "width": "20%","targets": 6  },

                {
                     className: 'mdl-data-table__cell--non-numeric',
                   
                }
            ],
            "search": {
              "regex": true
            }
        } ); 


    /*     $('.dataTables_filter input').on( 'keyup', function () {
     
          $('.dataTableInit').DataTable()
              .columns( 1 )
              .search( this.value )
              .draw();
      } ); */


       
      //   $('.dataTableInit tfoot th').each(function () {
         
      //     var title = $('.dataTableInit tfoot th').eq($(this).index()).text();
      //     if (title != '') {
      //         $(this).html('<input type="text" style="max-width:100px" placeholder="Search ' + title + '" />');
      //     }
      // });


   /*    // DataTable
    var table = $('.dataTableInit').DataTable({
      // stateSave: true,  // save search and sort state between pages
      responsive: true,  // make table responsive
      columns: [
          null, null, null, null, null, null,
          {"orderable": false}
      ]
  }); */  


       /*  $('#requestDataTable').DataTable().columns().every(function () {
          var that = this;
          $('input', this.footer()).on('keyup change', function () {
              var arr = this.value.split(";");
            var pattern = ("\\b" + arr.join('\\b|\\b') + '\\b'); // full word
              // var pattern = this.value.replace(/;/g, '|') // fuzzy search
              that
                  .search( pattern, true, false )
                  .draw();
          });
      }); */
      
     
      /*   $('#requestDataTable_filter input').on( 'keyup', function () {
          $('.dataTableInit').DataTable().search( this.value ).draw();
      } );
 */



        $('.dataTables_filter input').attr("placeholder", "Search All");
        $(document).find('.loader').hide();
 
        $(document).on('click','.slider.round', function(){

          let checkedStatus = $(this).prev().attr('checked');
          let MaintenanceId = $(this).prev().data("id");

      

            if (confirm('Are you sure you want to change the status?')) {

                      if(checkedStatus === 'checked'){
                       
                        $(this).prev().removeAttr('checked');
                          checkedStatus = false;
                        }else{
                        
                          $(this).prev().attr('checked','true');
                          checkedStatus = true;
                          }
                          $(document).find('.loader').show();
                          updateRequest(checkedStatus,MaintenanceId);


          } else {
              return false
          }
           
          function updateRequest(checkedStatus__,MaintenanceId__){
                

            var updateData = JSON.stringify({
                "query": {
                  "match_phrase": {
                    "MaintenanceId": MaintenanceId__
                  }
                },
                "script": {
                  "inline": "ctx._source.IsActive="+checkedStatus__,
                  "lang": "painless"
                }
              });
              
  
          
          
            var settings = {
                "async": true,
                "crossDomain": true,
                "url":  APIurl+"Api/UpdateRequest",
                "method": "POST",
                "headers": {
                  "content-type": "application/json",
                  "authenticationtoken": "testuser",
               
                },
                "processData": false,
                "data": updateData
              }
              
              $.ajax(settings).done(function (response) {
                $(document).find('.loader').hide();
              });
        }
  
   


        })

      
          

           }
           else{
               console.log("hits is not available");
           }
          
          });
    
    }
    
    MyRequests();

   




    
      });
    


