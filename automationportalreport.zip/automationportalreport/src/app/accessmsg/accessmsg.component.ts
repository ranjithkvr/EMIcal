import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accessmsg',
  templateUrl: './accessmsg.component.html',
  styleUrls: ['./accessmsg.component.scss']
})
export class AccessmsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
