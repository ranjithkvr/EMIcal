import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CustomerComponent } from './dashboard/customer/customer.component';
import { UsecasesComponent } from './dashboard/usecases/usecases.component';
import { CustomersComponent } from './dashboard/customers/customers.component';
import { CustomerviewComponent } from './dashboard/customerview/customerview.component';

export const routes: Routes = [
	{ path: '', redirectTo: '/home', pathMatch: 'full' },
	{ path : 'home', component : HomeComponent },
	{ 
	  path : 'dashboard', component :  DashboardComponent , children : [  
	  { path: '', redirectTo: 'customer', pathMatch: 'full' },
    { path : 'customer', component : CustomerComponent, outlet : 'dashboardrouter'},
    { path: 'usecases', component : UsecasesComponent, outlet: 'dashboardrouter'},
    { path: 'customers', component : CustomersComponent, outlet: 'dashboardrouter'},  
    { path: 'customerview', component : CustomerviewComponent, outlet: 'dashboardrouter'},   
    { path: 'customerview/:id', component : CustomerviewComponent, outlet: 'dashboardrouter'}
	], runGuardsAndResolvers: 'always'}
];

@NgModule({
   exports : [RouterModule],
   imports : [RouterModule.forRoot(routes, {enableTracing: true})]
})
export class AppRoutingModule { }
