import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import * as $ from "jquery";

@Component({
  selector: 'app-artuseractivities',
  templateUrl: './artuseractivities.component.html',
  styleUrls: ['./artuseractivities.component.scss']
})
export class ArtuseractivitiesComponent implements OnInit {

  GetARTDetails : any = [];
  GetARTDetailsPassCount : string;

  constructor(private httpService : HttpClient) { }



__GetARTDetails(){

      this.httpService.get('https://reportit.hexaware.com/Report/Api/GetARTDetails').subscribe(
             data => {
                    this.GetARTDetails =  data as any [];
               
                     if(data[0].useractivity === 'CHANGE_PASSWORD'){
                        
                       this.GetARTDetailsPassCount =  data[0].Count;


                    /* data[0].ismobiledeviceYesCnt
                       data[0].ismobiledeviceNoCnt
                       data[0].isinternetYesCnt
                       data[0].isinternetNoCnt */
                    
                   } 
                       
                   },
             (err: HttpErrorResponse) => {
              console.log(err.message);
             }
      );
   
}



  ngOnInit() {

  this.__GetARTDetails();

  }

}
