import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import * as $ from "jquery";
import * as echarts from 'echarts';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})




export class CustomerComponent implements OnInit {

  title = 'CUSTOMERS OVERVIEW';
  constructor( private httpService : HttpClient ) { }
  
  topAutoIncident: any = [];
  selected = null;
  productos: any = [];
  ServiceRequest : any = [];	
  GetCustomerUseCaseDetails : any = [];
  UPComingRelease : any = [];




  __GetCustomerUseCaseWiseRequestType(){

           this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseWiseRequestType').subscribe(
      data => {
         this.topAutoIncident = data as any [];	// FILL THE ARRAY WITH DATA.

         this.productos = this.topAutoIncident.Incident;
         this.ServiceRequest = this.topAutoIncident.ServiceRequest;

            },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


  }



__GetCustomerUseCaseDetails(){
	

     this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseDetails/0').subscribe(
      data => {
         this.GetCustomerUseCaseDetails = data as any [];	// FILL THE ARRAY WITH DATA.
         this.UPComingRelease = this.GetCustomerUseCaseDetails.UPComingRelease;
          
            },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


}



__BindAAIInfo() {       
     
        $.getJSON("https://reportit.hexaware.com/Report/Api/GetCustomerWiseAAI/0", function(data) {

            $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
               $("#AAIRequssseCaseDev").html(data.InProgressCnt);            
            
        })
    };






  ngOnInit () {
     
     this.__GetCustomerUseCaseWiseRequestType();
   
     this.__GetCustomerUseCaseDetails();

    

     this.__BindAAIInfo();

  

     var customerDetails;
     var  url = "https://reportit.hexaware.com/Report";

function allCustomer() {   
        
        $.getJSON(  url+ "/Api/GetCustomerDetails", function(data) {
                customerDetails = data;
               
                BindAutomationStaticstics();
                 fnAutomatedTicketVolume()
                 BindAutomatedUseCaseCategoryWise();
               BindAutomationUseCaseGrowthTrend();
               fnBindAutomationEffertReduction();
              bindIncidentUseCase();
        })
        
    }

allCustomer();


function SortByDate(x,y) {
      return ((x.OnBoardDate == y.OnBoardDate) ? 0 : ((new Date(x.OnBoardDate) > new Date(y.OnBoardDate)) ? 1 : -1 ));
    }


 function find_in_object(my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    }




function bindIncidentUseCase() {
        
        //var self = this;
        //self.customers = ko.observableArray([]);
        //self.customersCount;

        $.getJSON( "https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseDetails/0", function(data) {

            if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
            {
                var filterjson = find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                {
                    $("#hincidentUseCaseProd").html(filterjson[0].Count);
                }
                var srfilterjson = find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                {
                    $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                }
                
            }
            if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined)
            {
                 var filterjson = find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hincidentUseCaseDev").html(filterjson[0].Count);
                }
                
                var srfilterjson = find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                }
            }
            if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined)
            {
                 var filterjson = find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                }
                
                var srfilterjson = find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                }
            }
            
            //self.customers(data);
            
        })
    }



function fnBindAutomationEffertReduction() {
    

        var dom = document.getElementById("resolutionEffectReduction");
        var myChart = echarts.init(dom,'light');
        var app = {};
        var option = null;

        let  AutomationMTTR : any = [];
        let  ManualMTTR : any = [];


        $.getJSON("https://reportit.hexaware.com/Report/Api/GetResolutionEffortDeduction", function(data) {
           // debugger
            var customerName = []
            //console.log(data)
             var charseries =[];
            var effortArry = [];
            for(var i = 0;i<customerDetails.length;i++)
            {
                var value = []
                var auotMTTR = 0;
                var manMTTR = 0;
                
                customerName.push(customerDetails[i].CustomerName);
                
                var filterjson = find_in_object(data, {CustomerName: customerDetails[i].CustomerName})
                if(filterjson.length > 0)
                    {
                 AutomationMTTR.push(Math.round(filterjson[0].AutomationMTTR));       // PUSH THE VALUES INSIDE THE ARRAY.
                 ManualMTTR.push(Math.round(filterjson[0].ManualMTTR)); 
                        auotMTTR = Math.round(filterjson[0].AutomationMTTR);
                        manMTTR = Math.round(filterjson[0].ManualMTTR);
                    }
                else
                    {
                        AutomationMTTR.push(0)
                        ManualMTTR.push(0)
                        
                        auotMTTR = 0;
                        manMTTR = 0;
                    }
                
                var effort = {
                    customerName : customerDetails[i].CustomerName,
                    automationMTTR : auotMTTR,
                    manualMTTR : manMTTR
                }
                effortArry.push(effort)
            }
            
        //    console.log(effortArry)
         //   console.log(effortArry.sort(ResolutionEffortSort))
            
            AutomationMTTR = [];
            ManualMTTR = [];
            customerName = []
            
            for(var j=0;j<effortArry.length;j++)
                {
                    AutomationMTTR.push(effortArry[j].automationMTTR)
                    ManualMTTR.push(effortArry[j].manualMTTR)
                    customerName.push(effortArry[j].customerName);
                }
            
            var series = {
                name:'Automated',
                type:'bar',
                stack: 'true',
                barWidth : 25,
                label: {
                    normal: {
                        show: true
                    }
                },
                data: AutomationMTTR
            }
            charseries.push(series)

            var series1 = {
                name:'Manual',
                type:'bar',
                stack: 'true',
                barWidth : 35,
                label: {
                    normal: {
                        show: true
                    }
                },
                data: ManualMTTR
            }

            charseries.push(series1)
            
        option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {          
                    type : 'shadow'     
                }
            },
            legend: {
                data:['Automated','Manual']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'value'
                }
            ],
            yAxis : [
                {
                    type : 'category',
                    axisTick : {show: false},
                    data : customerName
                }
            ],
            series : charseries
        };
        ;
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
           

           });
}






function fnAutomatedTicketVolume() {

    $.getJSON( url+ "/Api/GetCustomerLast5MonthsAutomatedTickets", function(data) {
           
            var uniqueMonthAndYear = [];
             var monthXAxis =[]
             var customerName = []
             var charseries =[];

            for(i = 0; i< data.length; i++){    
                if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                    uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                     monthXAxis.push(data[i].Month)
                }        
            }

            //console.log(uniqueMonthAndYear)
            var customerArry = [];

             for(var i = 0;i<customerDetails.length;i++)
            {
                var value = []
                customerName.push(customerDetails[i].CustomerName);
                var filterjson = find_in_object(data, {CustomerName: customerDetails[i].CustomerName})

                for(var j =0;j<uniqueMonthAndYear.length;j++)
                {
                   var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
                   var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

                   if(finalfilterjson.length > 0)
                    {
                        value.push(finalfilterjson[0].Count);
                    }
                    else
                     {
                        value.push(0);
                    }   
                }

                var chartseries = {
                        name: customerDetails[i].CustomerName,
                        type: 'bar',
                        stack: '总量',
                        barWidth : 40,
                        label: {
                            normal: {
                                show: true,
                                //position: 'insideRight'
                            }
                        },
                        data: value
                    }

                charseries.push(chartseries)
            }


             var dom = document.getElementById("auto-ticketVol");
            var myChart = echarts.init(dom,'light');
            var app = {};
            var option = null;


            option = {
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {          
                        type : 'shadow'      
                    }
                },
                legend: {
                    data: customerName
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis:  {
                    type: 'category',
                    data: monthXAxis
                  
                },
                yAxis: {
                    type: 'value'
                },
                series: charseries
            };;
            if (option && typeof option === "object") {
                myChart.setOption(option, true);
            }
    })



   
}






    function BindAutomatedUseCaseCategoryWise() {
        $.getJSON(url+"/Api/GetCustomerUseCaseDetails/0", function(data) {
         
            
            var customerArry = []
            for(var i = 0;i<customerDetails.length;i++)
            {
                //debugger
                var value = []
                var incidneCnt = 0;
                var serviceReqCnt = 0
                customerArry.push(customerDetails[i].CustomerName);
                var filterjson = find_in_object(data.AutomatedUseCaseCategory, {CustomerName: customerDetails[i].CustomerName})
                
                if(filterjson.length > 0)
                {
                    var incidentFilter = find_in_object(filterjson, {RequestType: 'Incident'})
                    if(incidentFilter.length > 0)
                        {
                            incidneCnt = incidentFilter[0].Count
                        }
                    else
                        {
                            incidneCnt = 0;
                        }

                     var servRegFilter = find_in_object(filterjson, {RequestType: 'Service Request'})
                    if(servRegFilter.length > 0)
                        {
                            serviceReqCnt = servRegFilter[0].Count
                        }
                    else
                        {
                            serviceReqCnt = 0
                        }
                        

                    var inde = (i+1)
                    var dom = document.getElementById("autousecase"+inde);
                    var myChart = echarts.init(dom,'light');
                    var app = {};
                    var option = null;
                    
                    
                    option = {
                        title : {
                            text: customerDetails[i].CustomerName,
                            x:'center',
                            textStyle: {
                                color: '#333',
                                fontWeight: 'normal',
                                fontFamily: 'sans-serif',
                                fontSize: 12,
                            }
                        },
                        tooltip: {
                            trigger: 'item',
                            formatter: "{a} <br/>{b}: {c} ({d}%)"
                        },

                        series: [

                            {
                                name:customerDetails[i].CustomerName,
                                type:'pie',
                                radius: ['29%', '42%'], 
                                label: {
                                    normal: {
                                        formatter: ' {b|{b}：}{c} ',
                                        backgroundColor: '#eee',
                                        borderColor: '#aaa',
                                        borderWidth: 0,
                                        borderRadius: 1,


                                        rich: {
                                            a: {
                                                color: '#999',
                                                fontSize: 8,
                                                lineHeight: 22,
                                                align: 'center'
                                            },

                                            hr: {
                                                borderColor: '#aaa',
                                                width: '10%',
                                                fontSize: 8,
                                                borderWidth: 0.5,
                                                height: 0
                                            },
                                            b: {
                                                fontSize: 8,
                                                lineHeight: 20
                                            },
                                            per: {
                                                color: '#eee',
                                                backgroundColor: '#334455',
                                                fontSize: 8,
                                                padding: [2, 4],
                                                borderRadius: 2
                                            },
                                            c: {
                                                     color: '#999',
                                                fontSize: 8,
                                                lineHeight: 22,
                                                align: 'center'

                                            }
                                        }
                                    }
                                },
                                data:[
                                     {value:serviceReqCnt, name:'SR'},
                                    {value:incidneCnt, name:'IN'}
                                ]
                            }
                        ]
                    };


                    


                    if (option && typeof option === "object") {
                        myChart.setOption(option, true);
                    }
                }
                
            }
            
            
            
           


        })
}





function BindAutomationUseCaseGrowthTrend()
{
    $.getJSON(url+"/Api/GetCustomerUseCaseDetailsMonthYr/0", function(data) {
        console.log(customerDetails)
        
        
         var uniqueMonthAndYear = [];
         var monthXAxis =[]
         var customerName = []
         var charseries =[];

        for(i = 0; i< data.length; i++){    
            if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                 monthXAxis.push(data[i].Month)
            }        
        }

        //console.log(uniqueMonthAndYear)
        var customerArry = [];
        var customerSortedArr = customerDetails.sort(SortByDate); 
        
         for(var i = 0;i<customerSortedArr.length;i++)
        {
            var value = []
            customerName.push(customerSortedArr[i].CustomerName);
            var filterjson = find_in_object(data, {CustomerName: customerSortedArr[i].CustomerName})

            for(var j =0;j<uniqueMonthAndYear.length;j++)
            {
               var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
               var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

               if(finalfilterjson.length > 0)
                {
                    value.push(finalfilterjson[0].Count);
                }
                else
                 {
                    value.push(0);
                }   
            }
                var valueArr = []
            var growthCnt =0;
            for(var k=0;k<value.length;k++)
                {
                    
                    growthCnt += value[k]
                    valueArr.push(growthCnt)
                    
                } 
            var series = {
                name:customerSortedArr[i].CustomerName,
                type:'line',
                //smooth:true,
                areaStyle: {normal: {}},
                data: valueArr
            }
            charseries.push(series)
        }
        
        
        
        var dom = document.getElementById("growthTrend");
        var myChart = echarts.init(dom,'light');
        var app = {};
       var option = null;
        option = {

            tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {

                data:customerName
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : monthXAxis
                }
            ],
            yAxis : [
                {
                    type : 'value'
                }
            ],
            series : charseries
        };
        ;
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
        });
    
    

}


       function BindAutomationStaticstics(){ 

	var dom = document.getElementById("raiseItAutomationStat");
    var myChart = echarts.init(dom,'light');
    var app = {};
    var option = null;
    var monthXAxis;
    var    customerName;
     var   count = [];

    $.getJSON("https://reportit.hexaware.com/Report/Api/GetCustomerLast12MonthsTickets", function(data) {

        //debugger;
        //console.log(JSON.stringify(customerDetails))
        var uniqueMonthAndYear = [];
         var monthXAxis =[];
         var customerName = [];
         var charseries =[];
        
        var customerSortedArr = customerDetails.sort(SortByDate); 
        
        for(i = 0; i< data.length; i++){    
            if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                 monthXAxis.push(data[i].Month)
            }        
        }

        //console.log(uniqueMonthAndYear)
        var customerArry = [];

         for(var i = 0;i<customerSortedArr.length;i++)
        {
            var value = []
            customerName.push(customerSortedArr[i].CustomerName);
            var filterjson = find_in_object(data, {CustomerName: customerSortedArr[i].CustomerName})

            for(var j =0;j<uniqueMonthAndYear.length;j++)
            {
               var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
               var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

               if(finalfilterjson.length > 0)
                {
                    value.push(finalfilterjson[0].Count);
                }
                else
                 {
                    value.push(0);
                }   
            }

            var series = {
                name:customerSortedArr[i].CustomerName,
                type:'line',
                //smooth:true,
                areaStyle: {normal: {}},
                data: value
            }
            charseries.push(series)
        }



        //monthXAxis = ['JAN','FEB','MAR','APR','MAY','JUN','JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        //customerName = ['Customer 1','Customer 2','Customer 3']


    option = {    
        tooltip : {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
        legend: {
            data: customerName
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : monthXAxis
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : charseries
    };
    ;
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    } 
            })


       };

  }


}
