import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import * as $ from "jquery";
import * as echarts from 'echarts';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})




export class CustomerComponent implements OnInit {

  title = 'CUSTOMERS OVERVIEW';
  constructor( private httpService : HttpClient ) { }
  
  topAutoIncident: any = [];
  selected = null;
  productos: any = [];
  ServiceRequest : any = [];	
  GetCustomerUseCaseDetails : any = [];
  UPComingRelease : any = [];
  GetARTDetails : any = [];
  GetARTDetailsPassCount : string;



  __GetCustomerUseCaseWiseRequestType(){

           this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseWiseRequestType').subscribe(
      data => {
         this.topAutoIncident = data as any [];	// FILL THE ARRAY WITH DATA.

         this.productos = this.topAutoIncident.Incident;
         this.ServiceRequest = this.topAutoIncident.ServiceRequest;

            },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


  }



__GetCustomerUseCaseDetails(){
	

     this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseDetails/0').subscribe(
      data => {
         this.GetCustomerUseCaseDetails = data as any [];	// FILL THE ARRAY WITH DATA.
         this.UPComingRelease = this.GetCustomerUseCaseDetails.UPComingRelease;
          
            },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


}


__GetARTDetails(){

      this.httpService.get('https://reportit.hexaware.com/Report/Api/GetARTDetails').subscribe(
             data => {
                    this.GetARTDetails =  data as any [];
               

                    if(data[0].useractivity === 'CHANGE_PASSWORD'){
                        
                       this.GetARTDetailsPassCount =  data[0].Count;
                       console.log(this.GetARTDetailsPassCount);
                    
                   }
                   },
             (err: HttpErrorResponse) => {
              console.log(err.message);
             }
      );
   
}





  ngOnInit () {
     
     this.__GetCustomerUseCaseWiseRequestType();
   
     this.__GetCustomerUseCaseDetails();

     this.__GetARTDetails();

     var customerDetails;
     var  url = "https://reportit.hexaware.com/Report";

function allCustomer() {   
        
        $.getJSON(  url+ "/Api/GetCustomerDetails", function(data) {
                customerDetails = data;
               
                BindAutomationStaticstics();

        })
        
    }

allCustomer();


function SortByDate(x,y) {
      return ((x.OnBoardDate == y.OnBoardDate) ? 0 : ((new Date(x.OnBoardDate) > new Date(y.OnBoardDate)) ? 1 : -1 ));
    }


 function find_in_object(my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    }


       function BindAutomationStaticstics(){ 

	var dom = document.getElementById("raiseItAutomationStat");
    var myChart = echarts.init(dom,'customed');
    var app = {};
    var option = null;
    var monthXAxis;
    var    customerName;
     var   count = [];

    $.getJSON("https://reportit.hexaware.com/Report/Api/GetCustomerLast12MonthsTickets", function(data) {

        //debugger;
        //console.log(JSON.stringify(customerDetails))
        var uniqueMonthAndYear = [];
         var monthXAxis =[];
         var customerName = [];
         var charseries =[];
        
        var customerSortedArr = customerDetails.sort(SortByDate); 
        
        for(i = 0; i< data.length; i++){    
            if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                 monthXAxis.push(data[i].Month)
            }        
        }

        //console.log(uniqueMonthAndYear)
        var customerArry = [];

         for(var i = 0;i<customerSortedArr.length;i++)
        {
            var value = []
            customerName.push(customerSortedArr[i].CustomerName);
            var filterjson = find_in_object(data, {CustomerName: customerSortedArr[i].CustomerName})

            for(var j =0;j<uniqueMonthAndYear.length;j++)
            {
               var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
               var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

               if(finalfilterjson.length > 0)
                {
                    value.push(finalfilterjson[0].Count);
                }
                else
                 {
                    value.push(0);
                }   
            }

            var series = {
                name:customerSortedArr[i].CustomerName,
                type:'line',
                //smooth:true,
                areaStyle: {normal: {}},
                data: value
            }
            charseries.push(series)
        }



        //monthXAxis = ['JAN','FEB','MAR','APR','MAY','JUN','JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        //customerName = ['Customer 1','Customer 2','Customer 3']


    option = {    
        tooltip : {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
        legend: {
            data: customerName
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : monthXAxis
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : charseries
    };
    ;
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    } 
            })


       };

  }


}
