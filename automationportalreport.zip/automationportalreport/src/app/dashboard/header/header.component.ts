import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';


import * as $ from "jquery";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  customerID: any

  constructor (private httpService: HttpClient,  private activatedRoute: ActivatedRoute,  private location: Location) {


          this.customerID = (this.activatedRoute.snapshot.params).id;

          this.customerID == undefined ?  this.customerID = 0 :  this.customerID = (this.activatedRoute.snapshot.params).id; 


          let customerID = this.customerID;


         function __auto_Tkt_count(customerID){                                   
                $.getJSON( "https://reportit.hexaware.com/Report/Api/GetAutomatedTicketCount/"+ customerID , function(data) {  
                   $('#automated_Tkt_count').html(data.Total);
                
                 
                });
           }

  

       __auto_Tkt_count(customerID);

       
/* setInterval(function(){  
   __auto_Tkt_count(customerID);
}, 6000);

*/





    }

  // AutomatedTicketCount: any = [];




/*  __AutomatedTicketCount(){

     this.customerID = (this.activatedRoute.snapshot.params).id;
     this.customerID == undefined ?  this.customerID = 0 :  this.customerID = (this.activatedRoute.snapshot.params).id;

    this.httpService.get('https://reportit.hexaware.com/Report/Api/GetAutomatedTicketCount/'+  this.customerID ).subscribe(
      data => {
          this.AutomatedTicketCount = data as any [];	// FILL THE ARRAY WITH DATA.
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


 } */


   

  ngOnInit () {
           // this.__AutomatedTicketCount();
 

  }






}
