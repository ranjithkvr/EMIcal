import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  customerID: any

  constructor (private httpService: HttpClient,  private activatedRoute: ActivatedRoute,  private location: Location) { }

 AutomatedTicketCount: any = [];

 __AutomatedTicketCount(){

     this.customerID = (this.activatedRoute.snapshot.params).id;

     this.customerID == undefined ?  this.customerID = 0 :  this.customerID = (this.activatedRoute.snapshot.params).id;



    this.httpService.get('https://reportit.hexaware.com/Report/Api/GetAutomatedTicketCount/'+  this.customerID ).subscribe(
      data => {
          this.AutomatedTicketCount = data as any [];	// FILL THE ARRAY WITH DATA.
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


 }


  ngOnInit () {
            this.__AutomatedTicketCount();
  }




}
