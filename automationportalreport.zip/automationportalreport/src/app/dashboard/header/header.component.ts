import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor (private httpService: HttpClient) { }

 AutomatedTicketCount: any = [];

 __AutomatedTicketCount(){


    this.httpService.get('https://reportit.hexaware.com/Report/Api/GetAutomatedTicketCount/0').subscribe(
      data => {
          this.AutomatedTicketCount = data as any [];	// FILL THE ARRAY WITH DATA.
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


 }


  ngOnInit () {

    
            this.__AutomatedTicketCount();


  }




}
