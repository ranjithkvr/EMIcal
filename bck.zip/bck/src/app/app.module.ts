import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { SigninComponent } from './signin/signin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CustomerComponent } from './dashboard/customer/customer.component';
import { UsecasesComponent } from './dashboard/usecases/usecases.component';
import { CustomersComponent } from './dashboard/customers/customers.component';
import { HeaderComponent } from './dashboard/header/header.component';
import { SidebarnavComponent } from './dashboard/sidebarnav/sidebarnav.component';
import { SidebarComponent } from './dashboard/sidebar/sidebar.component';
import { CustomerviewComponent } from './dashboard/customerview/customerview.component';


import { AppRoutingModule } from './app-routing.module';
import { AccessmsgComponent } from './accessmsg/accessmsg.component';
import { ArtuseractivitiesComponent } from './dashboard/artuseractivities/artuseractivities.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SigninComponent,
    DashboardComponent,
    CustomerComponent,
    UsecasesComponent,
    CustomersComponent,
    HeaderComponent,
    SidebarnavComponent,
    SidebarComponent,
    CustomerviewComponent,
    AccessmsgComponent,
    ArtuseractivitiesComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
