import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtuseractivitiesComponent } from './artuseractivities.component';

describe('ArtuseractivitiesComponent', () => {
  let component: ArtuseractivitiesComponent;
  let fixture: ComponentFixture<ArtuseractivitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArtuseractivitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtuseractivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
