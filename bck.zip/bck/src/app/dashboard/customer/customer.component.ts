import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})




export class CustomerComponent implements OnInit {


  title = 'CUSTOMERS OVERVIEW';

  constructor( private httpService : HttpClient ) { }

  
  topAutoIncident: any = [];
  selected = null;
  productos: any = [];
  ServiceRequest : any = [];	
  GetCustomerUseCaseDetails : any = [];
   UPComingRelease : any = [];
   GetARTDetails : any = [];
  GetARTDetailsPassCount : string;



  __GetCustomerUseCaseWiseRequestType(){

           this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseWiseRequestType').subscribe(
      data => {
         this.topAutoIncident = data as any [];	// FILL THE ARRAY WITH DATA.

         this.productos = this.topAutoIncident.Incident;
         this.ServiceRequest = this.topAutoIncident.ServiceRequest;

            },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


  }



__GetCustomerUseCaseDetails(){
	

     this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerUseCaseDetails/0').subscribe(
      data => {
         this.GetCustomerUseCaseDetails = data as any [];	// FILL THE ARRAY WITH DATA.
         this.UPComingRelease = this.GetCustomerUseCaseDetails.UPComingRelease;
          
            },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


}


__GetARTDetails(){

      this.httpService.get('https://reportit.hexaware.com/Report/Api/GetARTDetails').subscribe(
             data => {
                    this.GetARTDetails =  data as any [];
               

                    if(data[0].useractivity === 'CHANGE_PASSWORD'){
                        
                       this.GetARTDetailsPassCount =  data[0].Count;
                       console.log(this.GetARTDetailsPassCount);
                    
                   }
                   },
             (err: HttpErrorResponse) => {
              console.log(err.message);
             }
      );
   
}

  ngOnInit () {
     
     this.__GetCustomerUseCaseWiseRequestType();
   
     this.__GetCustomerUseCaseDetails();

    this.__GetARTDetails();

  }


}
