import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerview',
  templateUrl: './customerview.component.html',
  styleUrls: ['./customerview.component.scss']
})
export class CustomerviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
