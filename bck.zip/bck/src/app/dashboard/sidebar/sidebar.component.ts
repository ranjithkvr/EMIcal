import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import * as moment from 'moment/moment';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {


   title = "DASHBOARD";

  constructor (private httpService: HttpClient) { }

  myCustomers: any = [];
  selected = null;	
  totalCustomer : number;


    __GetCustomerDetails(){


    this.httpService.get('https://reportit.hexaware.com/Report/Api/GetCustomerDetails').subscribe(
      data => {
        this.myCustomers = data as any [];	// FILL THE ARRAY WITH DATA.
        this.totalCustomer = this.myCustomers.length;
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


    }	

 ngOnInit () {
    
    this.__GetCustomerDetails();

  }

 
    onChange() {
         alert( (event.target as HTMLInputElement).value);


  }

}
