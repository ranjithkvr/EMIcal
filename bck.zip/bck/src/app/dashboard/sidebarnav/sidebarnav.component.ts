import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import {  RouterModule, Router, NavigationEnd , NavigationStart, ActivatedRoute, Params } from '@angular/router';
import { serviceURL } from '../../serviceURL';

import { sidebarService } from '../../sidebar.service';

import * as moment from 'moment';
import * as $ from "jquery";

@Component({
  selector: 'app-sidebarnav',
  templateUrl: './sidebarnav.component.html',
  styleUrls: ['./sidebarnav.component.scss']  , providers : [
     sidebarService
  ]
})
export class SidebarnavComponent implements OnInit {

path: any;

  constructor (private httpService: HttpClient, private router: Router, public url : serviceURL,  public sidebarnav: sidebarService , private activatedRoute: ActivatedRoute){ 


   
       this.activatedRoute.snapshot.firstChild.url[0].path;

  }

  ngOnInit() {  
   this.sidebarnav.hide();

  }

  message(){ 




}




}
