import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usecases',
  templateUrl: './usecases.component.html',
  styleUrls: ['./usecases.component.scss']
})
export class UsecasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
