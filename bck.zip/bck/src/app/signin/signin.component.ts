import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Router } from '@angular/router';
import { serviceURL } from '../serviceURL';
import * as $ from "jquery";

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
  providers : [
    serviceURL
  ]
})
export class SigninComponent implements OnInit {

  constructor(private httpService: HttpClient, private router: Router, public url : serviceURL) {}


   userName : string;
   Password : any;
   success : any;


    
  __signIn(event: any){
            
            this.userName =  $("#txtUserName").val();
            this.Password =  $("#txtPassword").val();;


           this.httpService.get("https://reportit.hexaware.com/Report/Api/Authenticate/"+this.userName+"/"+this.Password).subscribe(
      data => {

         this.success = data as any []; // FILL THE ARRAY WITH DATA.
        
         if( (this.success).toUpperCase() === "LOGIN SUCCESSFULLY"){
           this .router.navigate(['/dashboard',{outlets: {'dashboardrouter' : ['customer']}}]);
         }
              else{
               alert('Invalid UserName / Password')
              }
             

            },
      (err: HttpErrorResponse) => {
      console.log("error ")
        console.log (err.message);
      }
    );


  }




  ngOnInit() {

 

  }

}
