import { Component, OnInit } from '@angular/core';
import { User, AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrls: ['./app.scss']
})
export class AppComponent implements OnInit {

  coaches: User[] = [];
  students: User[] = [];

  constructor(private AppService: AppService) {}

  ngOnInit() {
    this.AppService.GetCoaches().subscribe(data => this.coaches = data);
    this.AppService.GetStudents().subscribe(data => this.students = data);
  }
}
