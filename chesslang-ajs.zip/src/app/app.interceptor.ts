import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AppService } from './app.service';

@Injectable()
export class AppInterceptor implements HttpInterceptor {

  constructor(private AppService: AppService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({url: 'https://staging.chessf5.com/' + req.url});
    req = req.clone({setHeaders: {'x-authorization': 'Bearer ' + this.AppService.GetToken()}});
    return next.handle(req);
  }
}
