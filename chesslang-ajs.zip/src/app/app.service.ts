import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

export interface User {
  uuid: string;
  username: string;
  firstname: string;
  lastname: string;
}

@Injectable()
export class AppService {

  constructor(private http: HttpClient) { }


  GetToken() {
    return 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJjaGVzc2xhbmciLCJleHAiOjE1MjExODQyNjc5MTksInVzZXIiOnsidXVpZCI6IjVlODYzNDAyLWYwNDYtNDdkYy05ZWIyLTgzMzVlYWI0Nzg1MCIsInVzZXJuYW1lIjoiQmFsYUBDb2FjaCIsInJvbGUiOjUwfX0.8aL1H6ggbuafZxhd78jvV4Bz9HTseiSWNlh1xCbPvOY';
  }

  GetCoaches(): Observable<User[]> {
    return this.http.get<User[]>(`identity/api/v1/network/coaches`);    
  }

  GetStudents(): Observable<User[]> {
    return this.http.get<User[]>(`identity/api/v1/network/students`);    
  }

}
