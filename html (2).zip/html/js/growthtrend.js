
var dom = document.getElementById("growthTrend");
var myChart = echarts.init(dom);
var app = {};
option = null;
option = {
    
    tooltip : {
        trigger: 'axis',
        axisPointer: {
            type: 'cross',
            label: {
                backgroundColor: '#6a7985'
            }
        }
    },
    legend: {
        data:['Cutomer 1','Customer 2','Customer 3']
    },
    toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis : [
        {
            type : 'category',
            boundaryGap : false,
            data : ['DEC','JAN','FEB','MAR','APR','MAY','JUN']
        }
    ],
    yAxis : [
        {
            type : 'value'
        }
    ],
    series : [
        {
            name:'Cutomer 1',
            type:'line',
            stack: '总量',
            areaStyle: {normal: {}},
            data:[20, 50, 25, 34, 90, 30, 10]
        },
        {
            name:'Customer 2',
            type:'line',
            stack: '总量',
            areaStyle: {normal: {}},
            data:[60, 40, 91, 34, 20, 30, 10]
        },
        {
            name:'Customer 3',
            type:'line',
            stack: '总量',
            areaStyle: {normal: {}},
            data:[50, 52, 61, 54, 90, 30, 10]
        }
    ]
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
  