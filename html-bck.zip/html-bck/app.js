var express = require('express')
var app = express()
app.use(express.static('ReportIT'))
 
app.get('/', function (req, res) {
  //res.send('Hello World')
  res.sendfile('index.html')
})
 
app.listen(3000)