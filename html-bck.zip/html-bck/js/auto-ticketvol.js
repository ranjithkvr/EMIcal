/*
var dom = document.getElementById("auto-ticketVol");
var myChart = echarts.init(dom,'customed');
var app = {};
option = null;


option = {
    tooltip : {
        trigger: 'axis',
        axisPointer : {          
            type : 'shadow'      
        }
    },
    legend: {
        data: ['Customer 1', 'Customer 2','Customer 3']
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis:  {
        type: 'category',
        data: ['DEC','JAN','FEB','MAR','APR']
      
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name: 'Customer 1',
            type: 'bar',
            stack: '总量',
            barWidth : 30,
            label: {
                normal: {
                    show: true,
                    position: 'insideRight'
                }
            },
            data: [90, 140, 180, 80, 80]
        },
        {
            name: 'Customer 2',
            type: 'bar',
            stack: '总量',
            barWidth : 30,
            label: {
                normal: {
                    show: true,
                    position: 'insideRight'
                }
            },
            data: [180, 220, 290, 340, 290]
        },
        {
            name: 'Customer 3',
            type: 'bar',
            stack: '总量',
            barWidth : 30,
            label: {
                normal: {
                    show: true,
                    position: 'insideRight'
                }
            },
            data: [290, 300, 291, 434, 390]
        }
    ]
};;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}*/