
var dom = document.getElementById("autousecase1");
var myChart = echarts.init(dom,'customed');
var app = {};
option = null;


option = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    }/*,
    legend: {
        // orient: 'vertical',
        // top: 'middle',
        bottom: 0,
        left: 'center',
        data: ['Service Request', 'Incidents']
    }*/,
    series: [
        {
            name:'1',
            type:'pie',
            radius: ['43%', '65%'],
            avoidLabelOverlap: false,
            label: {
                normal: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    show: true,
                    textStyle: {
                        fontSize: '10',
                        fontWeight: 'bold'
                    }
                }
            },
            labelLine: {
                normal: {
                    show: false
                }
            },
            data:[
                 {value:335, name:'Service Request'},
                {value:310, name:'Incidents'}
            ]
        }
    ]
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
    



var dom = document.getElementById("autousecase2");
var myChart = echarts.init(dom,'customed');
var app = {};
option = null;

option = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    }/*, legend: {
        // orient: 'vertical',
        // top: 'middle',
        bottom: 0,
        left: 'center',
        data: ['Service Request', 'Incidents']
    }*/,
    series: [
        {
            name:'2',
            type:'pie',
            radius: ['43%', '65%'],
            avoidLabelOverlap: false,
            label: {
                normal: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    show: true,
                    textStyle: {
                        fontSize: '10',
                        fontWeight: 'bold'
                    }
                }
            },
            labelLine: {
                normal: {
                    show: false
                }
            },
            data:[
                 {value:335, name:'Service Request'},
                {value:310, name:'Incidents'}
            ]
        }
    ]
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
    



var dom = document.getElementById("autousecase3");
var myChart = echarts.init(dom,'customed');
var app = {};
option = null;


option = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    }/*, legend: {
        // orient: 'vertical',
        // top: 'middle',
        bottom: 0,
        left: 'center',
        data: ['Service Request', 'Incidents']
    }*/,
    series: [
        {
            name:'3',
            type:'pie',
            radius: ['43%', '65%'],
            avoidLabelOverlap: false,
            label: {
                normal: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    show: true,
                    textStyle: {
                        fontSize: '10',
                        fontWeight: 'bold'
                    }
                }
            },
            labelLine: {
                normal: {
                    show: false
                }
            },
            data:[
                {value:335, name:'Service Request'},
                {value:310, name:'Incidents'}
            ]
        }
    ]
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
    



var dom = document.getElementById("autousecase4");
var myChart = echarts.init(dom,'customed');
var app = {};
option = null;

option = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    }/*, legend: {
        // orient: 'vertical',
        // top: 'middle',
        bottom: 0,
        left: 'center',
        data: ['Service Request', 'Incidents']
    }*/,
    series: [
        {
            name:'4',
            type:'pie',
            radius: ['43%', '65%'],
            avoidLabelOverlap: true,
            label: {
                normal: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    show: true,
                    textStyle: {
                        fontSize: '12',
                        fontWeight: 'bold'
                    }
                }
            },
            labelLine: {
                normal: {
                    show: false
                }
            },
            data:[
                {value:335, name:'Service Request'},
                {value:310, name:'Incidents'}
            ]
        }
    ]
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
    

