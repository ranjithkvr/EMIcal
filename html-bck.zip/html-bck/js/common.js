
 var url = "https://reportit.hexaware.com/Report";
 var devURL = "http://172.25.164.72:8033/";

function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
    vars[key] = value;
    });
return vars;
}



var customerID; 

  if(customerID == undefined){
      customerID = 0;
  }
  else{
    customerID = getUrlVars()["Id"]; 
  }

 auto_Tkt_count();

function auto_Tkt_count(){


$.getJSON( url+"/Api/GetAutomatedTicketCount/"+ customerID , function(data) {

  $("#od-ShwHide").show();
   automated_Tkt_count.innerHTML = (data.Total);
});
}
  


 setInterval(function(){  
   auto_Tkt_count();
}, 60000);