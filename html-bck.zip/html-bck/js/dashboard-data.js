﻿  var customerDetails;
   url = "https://reportit.hexaware.com/Report";



function allCustomer() {
   
        var self = this;
        self.customers = ko.observableArray([]);
        self.customersCount;
        $.getJSON(  url+ "/Api/GetCustomerDetails", function(data) {
                customerDetails = data;
               self.customers(data);
               customersCount = data.length;
               $("#customersCount").html(customersCount);
                BindAutomationStaticstics()
               fnAutomatedTicketVolume()
               BindAutomatedUseCaseCategoryWise();
                BindAutomationUseCaseGrowthTrend();
                fnBindAutomationEffertReduction();


        })
        
    }



 ko.applyBindings(new allCustomer(),select_customer);



    function userActivities(){

$.getJSON( url+ "/Api/GetARTDetails", function(data) {


                    for(var i=0; i < data.length; i++){

                        if(data[i].useractivity == "CHANGE_PASSWORD"){
                           $("#CHANGE_PASSWORD #hUseCaseManualMTTR_0").html(data[i].Count);
                             $("#CHANGE_PASSWORD .Mobile_user").html(data[i].ismobiledeviceYesCnt);
                               $("#CHANGE_PASSWORD .Destop_user").html(data[i].ismobiledeviceNoCnt);
                                 $("#CHANGE_PASSWORD .Internet_user").html(data[i].isinternetYesCnt);
                                   $("#CHANGE_PASSWORD .Intranet_user").html(data[i].isinternetNoCnt);

                        }

                        else if(data[i].useractivity == "Forgot_Password"){
                               $("#Forgot_Password #hUseCaseManualMTTR_0").html(data[i].Count);
                                  $("#Forgot_Password .Mobile_user").html(data[i].ismobiledeviceYesCnt);
                               $("#Forgot_Password .Destop_user").html(data[i].ismobiledeviceNoCnt);
                                 $("#Forgot_Password .Internet_user").html(data[i].isinternetYesCnt);
                                   $("#Forgot_Password .Intranet_user").html(data[i].isinternetNoCnt);

                        }
                        else if( data[i].useractivity  == "Unlock_Account"){
                               $("#Unlock_Account #hUseCaseManualMTTR_0").html(data[i].Count);
                                   $("#Unlock_Account .Mobile_user").html(data[i].ismobiledeviceYesCnt);
                               $("#Unlock_Account .Destop_user").html(data[i].ismobiledeviceNoCnt);
                                 $("#Unlock_Account .Internet_user").html(data[i].isinternetYesCnt);
                                   $("#Unlock_Account .Intranet_user").html(data[i].isinternetNoCnt);

                        }
                        else if( data[i].useractivity  == "User_Register"){
                               $("#User_Register #hUseCaseManualMTTR_0").html(data[i].Count);  
                               $("#User_Register .Mobile_user").html(data[i].ismobiledeviceYesCnt);
                               $("#User_Register .Destop_user").html(data[i].ismobiledeviceNoCnt);
                               $("#User_Register .Internet_user").html(data[i].isinternetYesCnt);
                               $("#User_Register .Intranet_user").html(data[i].isinternetNoCnt);                     
                        }
                    }
        })


    }



    userActivities();



    function GetCustomerUseCaseWiseRequestType() {
        var self = this;
        self.top_5AutomatedInc = ko.observableArray([]);
        self.top_5AutomatedSrvsRqst = ko.observableArray([]);

        $.getJSON( url+ "/Api/GetCustomerUseCaseWiseRequestType", function(data) {

            self.top_5AutomatedInc(data.Incident);
            self.top_5AutomatedSrvsRqst(data.ServiceRequest);

        })
    }

    ko.applyBindings(new GetCustomerUseCaseWiseRequestType(),top_5AutomatedInc);
    ko.applyBindings(new GetCustomerUseCaseWiseRequestType(),top_5AutomatedSrvsRqst);


// http://172.25.164.72:8033/Api/GetCustomerUseCaseDetails/0


    function GetCustomerUPComingRelease() {
        var self = this;
        self.upcomingReleaseDataGrid = ko.observableArray([]);

        $.getJSON( url+ "/Api/GetCustomerUseCaseDetails/0", function(data) {
            self.upcomingReleaseDataGrid(data.UPComingRelease);
        })
    }

    ko.applyBindings(new GetCustomerUPComingRelease(),upcomingReleaseDataGrid);



function fnAutomatedTicketVolume() {

    $.getJSON( url+ "/Api/GetCustomerLast5MonthsAutomatedTickets", function(data) {
           
            var uniqueMonthAndYear = [];
             var monthXAxis =[]
             var customerName = []
             var charseries =[];

            for(i = 0; i< data.length; i++){    
                if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                    uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                     monthXAxis.push(data[i].Month)
                }        
            }

            //console.log(uniqueMonthAndYear)
            var customerArry = [];

             for(var i = 0;i<customerDetails.length;i++)
            {
                var value = []
                customerName.push(customerDetails[i].CustomerName);
                var filterjson = find_in_object(data, {CustomerName: customerDetails[i].CustomerName})

                for(var j =0;j<uniqueMonthAndYear.length;j++)
                {
                   var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
                   var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

                   if(finalfilterjson.length > 0)
                    {
                        value.push(finalfilterjson[0].Count);
                    }
                    else
                     {
                        value.push(0);
                    }   
                }

                var chartseries = {
                        name: customerDetails[i].CustomerName,
                        type: 'bar',
                        stack: '总量',
                        barWidth : 40,
                        label: {
                            normal: {
                                show: true,
                                //position: 'insideRight'
                            }
                        },
                        data: value
                    }

                charseries.push(chartseries)
            }


             var dom = document.getElementById("auto-ticketVol");
            var myChart = echarts.init(dom,'customed');
            var app = {};
            option = null;


            option = {
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {          
                        type : 'shadow'      
                    }
                },
                legend: {
                    data: customerName
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis:  {
                    type: 'category',
                    data: monthXAxis
                  
                },
                yAxis: {
                    type: 'value'
                },
                series: charseries
            };;
            if (option && typeof option === "object") {
                myChart.setOption(option, true);
            }
    })



   
}

     function find_in_object(my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    }



function bindIncidentUseCase() {
        
        //var self = this;
        //self.customers = ko.observableArray([]);
        //self.customersCount;

        $.getJSON( url+"/Api/GetCustomerUseCaseDetails/0", function(data) {

            if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
            {
                var filterjson = find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                {
                    $("#hincidentUseCaseProd").html(filterjson[0].Count);
                }
                var srfilterjson = find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                {
                    $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                }
                
            }
            if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined)
            {
                 var filterjson = find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hincidentUseCaseDev").html(filterjson[0].Count);
                }
                
                var srfilterjson = find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                }
            }
            if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined)
            {
                 var filterjson = find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                }
                
                var srfilterjson = find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                }
            }
            
            //self.customers(data);
            
        })
    }


    function find_in_object(my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    }


    bindIncidentUseCase();



    function BindAutomatedUseCaseCategoryWise() {
        $.getJSON(url+"/Api/GetCustomerUseCaseDetails/0", function(data) {
         
            
            var customerArry = []
            for(var i = 0;i<customerDetails.length;i++)
            {
                //debugger
                var value = []
                var incidneCnt = 0;
                var serviceReqCnt = 0
                customerArry.push(customerDetails[i].CustomerName);
                var filterjson = find_in_object(data.AutomatedUseCaseCategory, {CustomerName: customerDetails[i].CustomerName})
                
                if(filterjson.length > 0)
                {
                    var incidentFilter = find_in_object(filterjson, {RequestType: 'Incident'})
                    if(incidentFilter.length > 0)
                        {
                            incidneCnt = incidentFilter[0].Count
                        }
                    else
                        {
                            incidneCnt = 0;
                        }

                     var servRegFilter = find_in_object(filterjson, {RequestType: 'Service Request'})
                    if(servRegFilter.length > 0)
                        {
                            serviceReqCnt = servRegFilter[0].Count
                        }
                    else
                        {
                            serviceReqCnt = 0
                        }
                        

                    var inde = (i+1)
                    var dom = document.getElementById("autousecase"+inde);
                    var myChart = echarts.init(dom,'customed');
                    var app = {};
                    option = null;
                    
                    
                    option = {
                        title : {
                            text: customerDetails[i].CustomerName,
                            x:'center',
                            textStyle: {
                                color: '#333',
                                fontWeight: 'normal',
                                fontFamily: 'sans-serif',
                                fontSize: 12,
                            }
                        },
                        tooltip: {
                            trigger: 'item',
                            formatter: "{a} <br/>{b}: {c} ({d}%)"
                        },

                        series: [

                            {
                                name:customerDetails[i].CustomerName,
                                type:'pie',
                                radius: ['29%', '42%'], 
                                label: {
                                    normal: {
                                        formatter: ' {b|{b}：}{c} ',
                                        backgroundColor: '#eee',
                                        borderColor: '#aaa',
                                        borderWidth: 0,
                                        borderRadius: 1,


                                        rich: {
                                            a: {
                                                color: '#999',
                                                fontSize: 8,
                                                lineHeight: 22,
                                                align: 'center'
                                            },

                                            hr: {
                                                borderColor: '#aaa',
                                                width: '10%',
                                                fontSize: 8,
                                                borderWidth: 0.5,
                                                height: 0
                                            },
                                            b: {
                                                fontSize: 8,
                                                lineHeight: 20
                                            },
                                            per: {
                                                color: '#eee',
                                                backgroundColor: '#334455',
                                                fontSize: 8,
                                                padding: [2, 4],
                                                borderRadius: 2
                                            },
                                            c: {
                                                     color: '#999',
                                                fontSize: 8,
                                                lineHeight: 22,
                                                align: 'center'

                                            }
                                        }
                                    }
                                },
                                data:[
                                     {value:serviceReqCnt, name:'SR'},
                                    {value:incidneCnt, name:'IN'}
                                ]
                            }
                        ]
                    };


                    


                    if (option && typeof option === "object") {
                        myChart.setOption(option, true);
                    }
                }
                
            }
            
            
            
           


        })
}


function BindAutomationStaticstics()
{

    var dom = document.getElementById("raiseItAutomationStat");
    var myChart = echarts.init(dom,'customed');
    var app = {};
    option = null;
    var monthXAxis,
        customerName,
        count = [];

    $.getJSON(url+"/Api/GetCustomerLast12MonthsTickets", function(data) {

        //debugger;
        //console.log(JSON.stringify(customerDetails))
        var uniqueMonthAndYear = [];
         var monthXAxis =[]
         var customerName = []
         var charseries =[];
        
        var customerSortedArr = customerDetails.sort(SortByDate); 
        
        for(i = 0; i< data.length; i++){    
            if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                 monthXAxis.push(data[i].Month)
            }        
        }

        //console.log(uniqueMonthAndYear)
        var customerArry = [];

         for(var i = 0;i<customerSortedArr.length;i++)
        {
            var value = []
            customerName.push(customerSortedArr[i].CustomerName);
            var filterjson = find_in_object(data, {CustomerName: customerSortedArr[i].CustomerName})

            for(var j =0;j<uniqueMonthAndYear.length;j++)
            {
               var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
               var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

               if(finalfilterjson.length > 0)
                {
                    value.push(finalfilterjson[0].Count);
                }
                else
                 {
                    value.push(0);
                }   
            }

            var series = {
                name:customerSortedArr[i].CustomerName,
                type:'line',
                //smooth:true,
                areaStyle: {normal: {}},
                data: value
            }
            charseries.push(series)
        }



        //monthXAxis = ['JAN','FEB','MAR','APR','MAY','JUN','JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        //customerName = ['Customer 1','Customer 2','Customer 3']


    option = {    
        tooltip : {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
        legend: {
            data: customerName
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : monthXAxis
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : charseries
    };
    ;
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    } 
            })


}


function BindAutomationUseCaseGrowthTrend()
{
    $.getJSON(url+"/Api/GetCustomerUseCaseDetailsMonthYr/0", function(data) {
        console.log(customerDetails)
        
        
         var uniqueMonthAndYear = [];
         var monthXAxis =[]
         var customerName = []
         var charseries =[];

        for(i = 0; i< data.length; i++){    
            if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
                uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
                 monthXAxis.push(data[i].Month)
            }        
        }

        //console.log(uniqueMonthAndYear)
        var customerArry = [];
        var customerSortedArr = customerDetails.sort(SortByDate); 
        
         for(var i = 0;i<customerSortedArr.length;i++)
        {
            var value = []
            customerName.push(customerSortedArr[i].CustomerName);
            var filterjson = find_in_object(data, {CustomerName: customerSortedArr[i].CustomerName})

            for(var j =0;j<uniqueMonthAndYear.length;j++)
            {
               var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
               var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})

               if(finalfilterjson.length > 0)
                {
                    value.push(finalfilterjson[0].Count);
                }
                else
                 {
                    value.push(0);
                }   
            }
                var valueArr = []
            var growthCnt =0;
            for(var k=0;k<value.length;k++)
                {
                    
                    growthCnt += value[k]
                    valueArr.push(growthCnt)
                    
                } 
            var series = {
                name:customerSortedArr[i].CustomerName,
                type:'line',
                //smooth:true,
                areaStyle: {normal: {}},
                data: valueArr
            }
            charseries.push(series)
        }
        
        
        
        var dom = document.getElementById("growthTrend");
        var myChart = echarts.init(dom,'customed');
        var app = {};
        option = null;
        option = {

            tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {

                data:customerName
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : monthXAxis
                }
            ],
            yAxis : [
                {
                    type : 'value'
                }
            ],
            series : charseries
        };
        ;
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
        });
    
    

}

function fnBindAutomationEffertReduction() {
    

        var dom = document.getElementById("resolutionEffectReduction");
        var myChart = echarts.init(dom,'customed');
        var app = {};
        option = null;

          AutomationMTTR = [];
          ManualMTTR = [];


        $.getJSON("https://reportit.hexaware.com/Report/Api/GetResolutionEffortDeduction", function(data) {
           // debugger
            var customerName = []
            //console.log(data)
             var charseries =[];
            var effortArry = [];
            for(var i = 0;i<customerDetails.length;i++)
            {
                var value = []
                var auotMTTR = 0;
                var manMTTR = 0;
                
                customerName.push(customerDetails[i].CustomerName);
                
                var filterjson = find_in_object(data, {CustomerName: customerDetails[i].CustomerName})
                if(filterjson.length > 0)
                    {
                 AutomationMTTR.push(Math.round(filterjson[0].AutomationMTTR,0));       // PUSH THE VALUES INSIDE THE ARRAY.
                 ManualMTTR.push(Math.round(filterjson[0].ManualMTTR,0)); 
                        auotMTTR = Math.round(filterjson[0].AutomationMTTR,0);
                        manMTTR = Math.round(filterjson[0].ManualMTTR,0);
                    }
                else
                    {
                        AutomationMTTR.push(0)
                        ManualMTTR.push(0)
                        
                        auotMTTR = 0;
                        manMTTR = 0;
                    }
                
                var effort = {
                    customerName : customerDetails[i].CustomerName,
                    automationMTTR : auotMTTR,
                    manualMTTR : manMTTR
                }
                effortArry.push(effort)
            }
            
            console.log(effortArry)
            console.log(effortArry.sort(ResolutionEffortSort))
            
            AutomationMTTR = [];
            ManualMTTR = [];
            customerName = []
            
            for(var j=0;j<effortArry.length;j++)
                {
                    AutomationMTTR.push(effortArry[j].automationMTTR)
                    ManualMTTR.push(effortArry[j].manualMTTR)
                    customerName.push(effortArry[j].customerName);
                }
            
            var series = {
                name:'Automated',
                type:'bar',
                stack: 'true',
                barWidth : 25,
                label: {
                    normal: {
                        show: true
                    }
                },
                data: AutomationMTTR
            }
            charseries.push(series)

            var series1 = {
                name:'Manual',
                type:'bar',
                stack: 'true',
                barWidth : 35,
                label: {
                    normal: {
                        show: true
                    }
                },
                data: ManualMTTR
            }

            charseries.push(series1)
            
        option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {          
                    type : 'shadow'     
                }
            },
            legend: {
                data:['Automated','Manual']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'value'
                }
            ],
            yAxis : [
                {
                    type : 'category',
                    axisTick : {show: false},
                    data : customerName
                }
            ],
            series : charseries
        };
        ;
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
           

           });
}


function BindAAIInfo() {
        
        //var self = this;
        //self.customers = ko.observableArray([]);
        //self.customersCount;

        $.getJSON( url+"/Api/GetCustomerWiseAAI/0", function(data) {

            $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
               $("#AAIRequssseCaseDev").html(data.InProgressCnt);
            //self.customers(data);
            
        })
    }

    BindAAIInfo();

function SortByDate(x,y) {
      return ((x.OnBoardDate == y.OnBoardDate) ? 0 : ((new Date(x.OnBoardDate) > new Date(y.OnBoardDate)) ? 1 : -1 ));
    }

    function ResolutionEffortSort(x,y) {
      return ((x.manualMTTR == y.manualMTTR) ? 0 : ((new Date(x.manualMTTR) < new Date(y.manualMTTR)) ? 1 : -1 ));
    }


