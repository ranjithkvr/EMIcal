
$(function(){

var dom = document.getElementById("raiseItAutomationStat");
var myChart = echarts.init(dom,'customed');
var app = {};
option = null;
var monthXAxis,
    customerName,
    count = [];



$.getJSON("https://reportit.hexaware.com/Report/Api/GetCustomerLast12MonthsTickets", function(data) {
   
    //debugger;
         
    var uniqueMonthAndYear = [];
     var monthXAxis =[]
     var customerName = []
     var charseries =[];
   
    for(i = 0; i< data.length; i++){    
        if(uniqueMonthAndYear.indexOf(data[i].Month+"_"+data[i].Year) === -1){
            uniqueMonthAndYear.push(data[i].Month+"_"+data[i].Year);       
             monthXAxis.push(data[i].Month)
        }        
    }
    
   // console.log(uniqueMonthAndYear)
    var customerArry = [];
   
     for(var i = 0;i<customerDetails.length;i++)
    {
        var value = []
        customerName.push(customerDetails[i].CustomerName);
        var filterjson = find_in_object(data, {CustomerName: customerDetails[i].CustomerName})
        
        for(var j =0;j<uniqueMonthAndYear.length;j++)
        {
           var monthfilterjson = find_in_object(filterjson, {Month: uniqueMonthAndYear[j].split('_')[0]})
           var finalfilterjson = find_in_object(monthfilterjson, {Year: uniqueMonthAndYear[j].split('_')[1]})
           
           if(finalfilterjson.length > 0)
            {
                value.push(finalfilterjson[0].Count);
            }
            else
             {
                value.push(0);
            }   
        }
        
        var series = {
            name:customerDetails[i].CustomerName,
            type:'line',
            //smooth:true,
            areaStyle: {normal: {}},
            data: value
        }
        charseries.push(series)
    }
     
       

    //monthXAxis = ['JAN','FEB','MAR','APR','MAY','JUN','JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
    //customerName = ['Customer 1','Customer 2','Customer 3']


option = {    
    tooltip : {
        trigger: 'axis',
        axisPointer: {
            type: 'cross',
            label: {
                backgroundColor: '#6a7985'
            }
        }
    },
    legend: {
        data: customerName,
         textStyle: {text-transform: 'uppercase'}
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis : [
        {
            type : 'category',
            boundaryGap : false,
            data : monthXAxis
        }
    ],
    yAxis : [
        {
            type : 'value'
        }
    ],
    series : charseries
};
;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
} 
        })
 


});

 function find_in_object(my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    }