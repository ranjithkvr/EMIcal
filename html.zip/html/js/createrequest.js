
(function() {  
      
    // startDate
         var StartDate = new mdDateTimePicker.default({
            type: 'date',
            orientation : 'Landscape',
            mode : false,
            future : moment().add(100, 'years'),
          });
          var toggleButton = document.getElementById('id-of-button-to-open-it');
    
          toggleButton.addEventListener('click', function() {
            StartDate.toggle();
          });
    
          StartDate.trigger = document.getElementById('startdate');
          
          document.getElementById('startdate').addEventListener('onOk', function() {
             this.value = moment(StartDate.time.toString()).format("YYYY-MM-DD");
        });
    
        document.getElementById('startdate').addEventListener('onCancel', function() {
                  this.value = "YYYY-MM-DD";
                });



                   // endDate
         var endDate = new mdDateTimePicker.default({
            type: 'date',
            orientation : 'Landscape',
            mode : false,
            future : moment().add(100, 'years'),
          });
          var toggleButton = document.getElementById('enddate_icon');
    
          toggleButton.addEventListener('click', function() {
            endDate.toggle();
          });
    
          endDate.trigger = document.getElementById('enddate_cal');
          
          document.getElementById('enddate_cal').addEventListener('onOk', function() {
                        this.value = moment(endDate.time.toString()).format("YYYY-MM-DD");
        });
    
        document.getElementById('startdate').addEventListener('onCancel', function() {
                  this.value = "YYYY-MM-DD";
                });
    
    //  start time
        var startTime = new mdDateTimePicker.default({
            type: 'time',
          orientation: 'PORTRAIT'
        });
    
      
    
        document.getElementById('startTime_icon').addEventListener('click', function() {
            startTime.toggle();
        });
    
        startTime.trigger = document.getElementById('starttime');
    
        document.getElementById('starttime').addEventListener('onOk', function() {
            //  this.value = moment(StartDate.time.toString()).format("MM/DD/YYYY");
            var time = moment(startTime.time).format('h:ma z');
            this.value = time;
        });


        //  end time
        var endTime = new mdDateTimePicker.default({
            type: 'time',
          orientation: 'PORTRAIT'
        });
    
      
    
        document.getElementById('endTime_icon').addEventListener('click', function() {
            endTime.toggle();
        });
    
        endTime.trigger = document.getElementById('endtime');
    
        document.getElementById('endtime').addEventListener('onOk', function() {
            //  this.value = moment(StartDate.time.toString()).format("MM/DD/YYYY");
            var time = moment(endTime.time).format('h:ma z');
            this.value = time;
        });
       
       
    
    }).call(this);


    // daily / weekly / monthly

    var recurOptions = document.getElementsByName("recurOptions");
    var recu_value;

    for(let i=0; i < recurOptions.length;i++){
        recurOptions[i].addEventListener('click',function(){
            

            if(recurOptions[i].checked){
                recu_value = recurOptions[i].value;
              //  console.log(recu_value);

                if(recu_value === 'daily'){
                 
                        document.getElementById('monthly-section').style.display = 'none';
                        document.getElementById('weekly-section').style.display = 'none';
                      document.getElementById('daily-section').style.display = 'block';
                }

                else if(recu_value === 'weekly'){
                        
                               document.getElementById('daily-section').style.display = 'none';
                               document.getElementById('monthly-section').style.display = 'none';
                             document.getElementById('weekly-section').style.display = 'block';
                      
                }
                else if(recu_value === 'monthly'){
                    
                           document.getElementById('daily-section').style.display = 'none';
                           document.getElementById('monthly-section').style.display = 'block';
                         document.getElementById('weekly-section').style.display = 'none';
                  
            }
               }
           
           
        })
        
        // if(recurOptions[i].checked){
        //     recu_value = recurOptions[i].value;
        //   //  console.log(recu_value);
        // }
    }

    


    

    // recurrence

    var recurrence = document.getElementById("recurrence");
    var advancedSettings = document.getElementById("advanced_settings");
    var chekedValue = null;
    recurrence.addEventListener('change', function(){
        chekedValue = recurrence.checked;

        if(chekedValue === true){
            advancedSettings.style.display = "flex"
        }else{
            
            advancedSettings.style.display = "none"
               
          
        }
               
    })

    // submit form
  
    $( document ).ready(function() {
        
       
       
/* 
    function createRequest(){       
                var createData = JSON.stringify({
                    "Name": "AutomationRequestCollector03",
                    "CIs": "MNCOUTIJ29,MNCOUTIJ30",
                    "StartDate": "2018-08-07",
                    "StartTime": "6:00 PM",
                    "EndTime": "6:30 PM",
                    "IsRecurrence": false,
                    "Frequency": "OneTime",
                    "Dates": "0",
                    "Days": null,
                    "IsEnddate": false,
                    "EndDate": null,
                    "IsActive": true,
                    "CreatedBy": "created",
                    "CreatedDateTime": "2018-04-12T05:07:20.55Z",
                    "ModifiedBy": null,
                    "ModifiedDateTime": null,
                    "Monthly": "J,F,M",
                    "Recurevery": "0"
                  });
                  


                 var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "http://172.25.164.72:8013/Api/AddRequest",
                    "method": "POST",
                    "headers": {
                      "content-type": "application/json",
                      "authenticationtoken": "testuser",
                      "cache-control": "no-cache",
                      "postman-token": "7dc8ba90-2111-8fe1-5924-c4994473bdfd"
                    },
                    "processData": false,
                    "data": createData
                  }
                  
                  $.ajax(settings).done(function (response) {
                
                    console.log("data created Successfully");
                    console.log(response);
                  });

    } */


    // months DD
    $("ul[for=months] li").on('click', function(e){
       $(".mdl-menu__outline").addClass("is-visible")
    })

    var chkchange = []

    $(document).on('click','#createRequestData', function(e){

        e.preventDefault();
        
        var IsRecurrenceVal = document.getElementById("recurrence").checked,
            Frequency,
            weekly = [],
            selectClsMutipleDD = [];

            if(IsRecurrenceVal === false){
                Frequency = "OneTime"
            }else{
                $('input:radio[name=recurOptions]').each(function() 
                {    
                    if($(this).is(':checked'))
                    Frequency = $(this).val();
                });             
            }


            $('input[name=weeklyOption]:checked').map(function(){
                weekly.push($(this).val())
            })

          
            $('input[name=selectClsMutipleDD]:checked').map(function(){
                selectClsMutipleDD.push($(this).val());
           })
          


            selectClsMutipleDD = selectClsMutipleDD.toString();
     

          function createRequest(){  
              
            
            let createData = JSON.stringify({
                "Name": $('#nameofRequest').val(),
                "CIs": selectClsMutipleDD,
                "StartDate": $('#startdate').val(),
                "StartTime": $('#starttime').val(),
                "EndTime": $('#endtime').val(),
                "IsRecurrence": IsRecurrenceVal ,
                "Frequency": Frequency,
                "Dates": "0",
                "Days": null,
                "IsEnddate": false,
                "EndDate": $('#enddate_cal').val(),
                "IsActive": true,
                "CreatedBy": "created",
                "CreatedDateTime": moment().format(),
                "ModifiedBy": null,
                "ModifiedDateTime": null,
                "Monthly": "J,F,M",
                "Recurevery": $("#every").val()
              });
              


             var settings = {
                "async": true,
                "crossDomain": true,
                "url": "http://172.25.164.72:8013/Api/AddRequest",
                "method": "POST",
                "headers": {
                  "content-type": "application/json",
                  "authenticationtoken": "testuser",
                  "cache-control": "no-cache",
                  "postman-token": "7dc8ba90-2111-8fe1-5924-c4994473bdfd"
                },
                "processData": false,
                "data": createData
              }
             

              $.ajax(settings).done(function (response) { 

                 
                window['counter'] = 0;
                var snackbarContainer = document.querySelector('#demo-toast-example');
                var showToastButton = document.querySelector('#demo-show-toast');
           
                   
                    var data = {message: 'Data created Successfully',  timeout: 2000 };
                    snackbarContainer.MaterialSnackbar.showSnackbar(data);
               

               
               
              });

}
createRequest();
       
    })
})