
(function() {  
      
         var StartDate = new mdDateTimePicker.default({
            type: 'date',
            orientation : 'Landscape',
            mode : false,
            future : moment().add(100, 'years'),
          });
          var toggleButton = document.getElementById('id-of-button-to-open-it');
    
          toggleButton.addEventListener('click', function() {
            StartDate.toggle();
          });
    
          StartDate.trigger = document.getElementById('startdate');
          
          document.getElementById('startdate').addEventListener('onOk', function() {
             this.value = moment(StartDate.time.toString()).format("MM/DD/YYYY");
        });
    
        document.getElementById('startdate').addEventListener('onCancel', function() {
                  this.value = "MM/DD/YYYY";
                });
    
    
        var startTime = new mdDateTimePicker.default({
            type: 'time',
          orientation: 'PORTRAIT'
        });
    
      
    
        document.getElementById('startTime_icon').addEventListener('click', function() {
            startTime.toggle();
        });
    
        startTime.trigger = document.getElementById('starttime');
    
        document.getElementById('starttime').addEventListener('onOk', function() {
            //  this.value = moment(StartDate.time.toString()).format("MM/DD/YYYY");
            var time = moment(startTime.time).format('h:ma z');
            this.value = time;
        });
       
    
    }).call(this);



    // recurrence

    var recurrence = document.getElementById("recurrence");
    var advancedSettings = document.getElementById("advanced_settings");
    var chekedValue = null;
    recurrence.addEventListener('change', function(){
        chekedValue = recurrence.checked;

        if(chekedValue === true){
            advancedSettings.style.display = "flex"
        }else{
            
            advancedSettings.style.display = "none"
               
          
        }
               
    })