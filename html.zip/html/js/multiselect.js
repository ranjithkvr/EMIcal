            /* Anything that gets to the document
            will hide the dropdown */
            $(document).click(function(){
              $(".customMultiselect_DD .demo-card-event.mdl-card").hide();
            });


            $("#selectCls").focus(function() { 
               $(".customMultiselect_DD .demo-card-event.mdl-card").show();
            })

            /* Clicks within the dropdown won't make
            it past the dropdown itself */
            $(".customMultiselect_DD").click(function(e){
                  e.stopPropagation();
            });



            $(function(){
                 var selectOption = "";
            function multiselectCls(){

                    var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "http://172.25.164.72:8013/Api/GetCiList",
                    "method": "GET",
                    "headers": {
                    "authenticationtoken": "testuser",
                    "cache-control": "no-cache",
                    "postman-token": "f64b14a0-7d2a-d8ac-cc8c-ea129d47eb4a"
                    }
                    }

            $.ajax(settings).done(function (response) {

            for(let i=0; i < response.length; i++){
           
            if(response[i].appname !== "" ){                
                selectOption += '<li class="mdl-list__item optgroup" data-appname="' +  response[i].appname + '">' + response[i].appname + '</li>'
            }else{
                selectOption += ''
            }

            for(let j =0; j < response[i].cidata.length; j++){
                if(response[i].appname !== "" ){
                selectOption += '<li class="mdl-list__item optgroup-option"> <label for="' + response[i].appname + "_" +  response[i].cidata[j] + '"> <input name="selectClsMutipleDD" type="checkbox" value="' + response[i].cidata[j] + '" id="' + response[i].appname + "_" +  response[i].cidata[j] + '">' + response[i].cidata[j]  + '</label></li>'
            }else{
                selectOption += '<li class="mdl-list__item optgroup"> <label for="' + response[i].appname + "_" +  response[i].cidata[j] + '"> <input name="selectClsMutipleDD" type="checkbox" value="' + response[i].cidata[j] + '" id="' + response[i].appname + "_" +  response[i].cidata[j] + '">' + response[i].cidata[j]  + '</label></li>'
            }
                
            }


            }


            $("#selectCls-multipleOption .selectCls-multipleOptionData ul").append(selectOption);

            var multSelectVal = []
            $("input[type=checkbox]").on('click', function(){

            var categories = $("input[name=selectClsMutipleDD]:checked").map(function () {
            return this.value
            }).get()

            $('#selectCls').val(categories); 
            })

            });


            }

            multiselectCls();


            })


