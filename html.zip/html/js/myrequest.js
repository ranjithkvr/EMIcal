"use strict";
  
$( document ).ready(function() {
    
    function MyRequests(){

        var html ="";
        var dataID = document.getElementById("myRequest_data");
    
        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "http://172.25.164.72:8013/Api/MyRequests",
            "method": "GET",
            "headers": {
              "content-type": "application/json",
              "authenticationtoken": "testuser",
              "cache-control": "no-cache",
              "postman-token": "447a0142-440f-79ff-b898-861179c2cf4b"
            }
          }

/* 
          function update(name) {
            var listContainer = document.getElementById('features-list');
            var tmpl;
          
            // draw new element to the DOM
            tmpl = document.getElementById('list-element-template').cloneNode(true);
            tmpl.id = 'feature-' + name;
            
            tmpl.querySelector('.mdl-switch__label').innerHTML = name;
            tmpl.querySelector('.mdl-switch').setAttribute('for', 'list-switch-' + name);
            tmpl.querySelector('.mdl-switch__input').id = 'list-switch-' + name;
          
            listContainer.appendChild(tmpl);
          
            componentHandler.upgradeElement(tmpl);
          }
          
          update('a'); 
          update('b'); 
           */
          $.ajax(settings).done(function (response) {
           // console.log(JSON.parse(response));

           var data = JSON.parse(response);
           var numbHits;
           numbHits = data.hits.hits;

           if(data.hits !== undefined || data.hits.hits !== undefined || data.hits !== null || data.hits.hits !== null){

            var datLength = numbHits.length;
            var checkboxSlider;
         
         
 
           for(let i=0; i < datLength; i++){     
               
              
               if( numbHits[i]._source.EndDate === null){
                 numbHits[i]._source.EndDate = "-"
               }
 
               if(numbHits[i]._source.IsActive === false){ 
                  checkboxSlider = '<label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="status_'+ [i] + '"><input  data-id='+ numbHits[i]._source.MaintenanceId +' type="checkbox" name="status_' + [i] +'"><span class="mdl-switch__label"></span></label>'
               }else{
                  checkboxSlider = '<label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="status_'+ [i] + '"><input data-id='+ numbHits[i]._source.MaintenanceId +' type="checkbox" name="status_' + [i] +'" checked="' + numbHits[i]._source.IsActive + '"><span class="mdl-switch__label"></span></label>'
               }
              html += '<tr><td>' + numbHits[i]._source.Name + '</td>'
              html += '<td>' + numbHits[i]._source.CIs + '</td>' 
              html += '<td>' + numbHits[i]._source.StartDate + '</td>'     
              html += '<td>' + numbHits[i]._source.EndDate + '</td>'     
              html += '<td>' + numbHits[i]._source.Frequency + '</td>'     
              html += '<td>' + numbHits[i]._source.StartTime + '</td>'
              html += '<td>' + numbHits[i]._source.EndTime + '</td>'
              html += '<td>' + checkboxSlider
             /*  html += '<label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="status_'+ [i] + '"><input type="checkbox" name="status_' + [i] +'" checked="' + numbHits[i]._source.IsActive + '">'
              
              html += '<span class="mdl-switch__label"></span></label></td>'    */          
 
              
              html += '</tr>';
 
              
           }
 
           $(document).on('click',"#requestDataTable input[type=checkbox]", function(){
            
             var checkedStatus = this.checked;
             var MaintenanceId = $(this).data("id");
 
            /*   if(checkedStatus === false){               
                  $(this).parent().removeClass("is-checked")
              }
              else{
                 $(this).parent().addClass("is-checked");
              } */
 
                function updateRequest(checkedStatus__,MaintenanceId__){
                    console.log("---status---");
                    console.log(checkedStatus__);
                    console.log(MaintenanceId__);


                    var updateData = JSON.stringify({
                        "query": {
                          "match_phrase": {
                            "MaintenanceId": MaintenanceId__
                          }
                        },
                        "script": {
                          "inline": "ctx._source.IsActive="+checkedStatus__,
                          "lang": "painless"
                        }
                      });
                      

                  
                    console.log(updateData);
                    var settings = {
                        "async": true,
                        "crossDomain": true,
                        "url": "http://172.25.164.72:8013/Api/UpdateRequest",
                        "method": "POST",
                        "headers": {
                          "content-type": "application/json",
                          "authenticationtoken": "testuser",
                          "cache-control": "no-cache",
                          "postman-token": "e2987aeb-c5fc-b573-ddd0-cd5ce5e7c80a"
                        },
                        "processData": false,
                        "data": updateData
                      }
                      
                      $.ajax(settings).done(function (response) {
                        console.log(response);
                      });
                }
 
                updateRequest(checkedStatus,MaintenanceId);
           })
 
           $("#myRequest_data").html(html);
 

           }
           else{
               console.log("hits is not available");
           }
          
          });
    
    }
    
    MyRequests();






    
      });
    


