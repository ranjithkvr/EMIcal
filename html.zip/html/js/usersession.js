

var userSession = {
   
    checkUserSession: function(){
        if($.session.get("isValidUser") == "Y")
            {
                return true;
            }
        else
            {
                return false;
            }
    },
    removeUserSession : function(){
        //debugger;
        console.log("session out");
        $.session.remove("isValidUser");
        window.location = 'index.html'
    }
}