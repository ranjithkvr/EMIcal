//myProfileStrengthChart

// Script
var myProfileStrengthChart = bb.generate({
  data: {
    columns: [
	["data1", 30],
	["data2", 45]
    ],
    type: "donut"
  },
  donut: {
    title: "40%",
    padAngle: 0.1
  },
  bindto: "#myProfileStrengthChart"
});