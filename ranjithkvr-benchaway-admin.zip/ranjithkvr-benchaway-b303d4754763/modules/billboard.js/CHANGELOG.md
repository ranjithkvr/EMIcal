# 1.2.0 release (2017-12-15)

## Features :

- **Point**
	- Implement alternate markers ([#209](https://github.com/naver/billboard.js/issues/209))

- **Export**
	- Intent to ship export as an image ([#78](https://github.com/naver/billboard.js/issues/78))

- **Options**
	- Add custom classname for bind element (#212) ([#201](https://github.com/naver/billboard.js/issues/201))
	- Implement color.tile option ([#193](https://github.com/naver/billboard.js/issues/193))

- **Bubble**
	- Intent to ship bubble type (#195) ([#163](https://github.com/naver/billboard.js/issues/163))

- **Shape.line**
	- Allow customization of points ([#173](https://github.com/naver/billboard.js/issues/173))
	- Add a line_classes option ([#181](https://github.com/naver/billboard.js/issues/181))

## Bug Fixes :

- **Size**
	- Correct height increase during resize (#223) ([#155](https://github.com/naver/billboard.js/issues/155))
	- Correct width on resizing (#189) ([#179](https://github.com/naver/billboard.js/issues/179))

- **Bubble, Point**
	- Fix bubble size change on load API (#214) ([#163](https://github.com/naver/billboard.js/issues/163))

- **Data**
	- Correct data.onclick calls (#203) ([#202](https://github.com/naver/billboard.js/issues/202))

- **Readme**
	- Change broken link about license (#188) ([#188](https://github.com/naver/billboard.js/issues/188))

- **Bar**
	- Adjust bar width regardless tick count limit ([#166](https://github.com/naver/billboard.js/issues/166))

- **Data, Interaction**
	- Bar type interaction error on multiple x ([#178](https://github.com/naver/billboard.js/issues/178))

- **Zoom**
	- Correct zoom in rendering on 0 coord. ([#169](https://github.com/naver/billboard.js/issues/169))

## Documents :

- **Tooltip**
	- Add note for data.groups (#218) ([#216](https://github.com/naver/billboard.js/issues/216))

- **All**
	- Improve readability & undocumented APIs (#206) ([#190](https://github.com/naver/billboard.js/issues/190))

- **Example**
	- Add new options example (#176) ([#144](https://github.com/naver/billboard.js/issues/144))

- **Readme**
	- Clarifying loading files (#168) ([#165](https://github.com/naver/billboard.js/issues/165))

## Test Codes :

- **Data.xs**
	- Add data.onclick for multiple xs (#205) ([#202](https://github.com/naver/billboard.js/issues/202))

## Chore tasks :

- **Dev-env**
	- Increase node memory size (#157) ([#156](https://github.com/naver/billboard.js/issues/156))
	- Update dependency (#154) ([#151](https://github.com/naver/billboard.js/issues/151))
