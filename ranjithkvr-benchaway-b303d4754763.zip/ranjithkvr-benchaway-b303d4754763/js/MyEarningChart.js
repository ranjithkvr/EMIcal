// Script
var MyEarning = bb.generate({
  data: {
    columns: [
	["Actual", 2000, 5000, 2500,  4000, 2500 ]
    ]
  },
  axis: {
    y: {
      tick: {
        format: function (x) {
		    return d3.format("$,")(x);
		}
      }
    },
	   y2: {
      show: true
    }
  },
  grid: {
    y: {
      lines: [
        {
          value: 4000,
          text: "Label 50 for y",
			 position: "middle"
        }
      ]
    }
  },
  bindto: "#MyEarningChart"
});

