// Starrr plugin (https://github.com/dobtco/starrr)
var __slice = [].slice;

(function ($, window) {
    var Starrr;

    Starrr = (function () {
        Starrr.prototype.defaults = {
            rating: void 0,
            numStars: 5,
            change: function (e, value) {}
        };

        function Starrr($el, options) {
            var i, _, _ref,
                _this = this;

            this.options = $.extend({}, this.defaults, options);
            this.$el = $el;
            _ref = this.defaults;
            for (i in _ref) {
                _ = _ref[i];
                if (this.$el.data(i) != null) {
                    this.options[i] = this.$el.data(i);
                }
            }
            this.createStars();
            this.syncRating();
            this.$el.on('mouseover.starrr', 'span', function (e) {
                return _this.syncRating(_this.$el.find('span').index(e.currentTarget) + 1);
            });
            this.$el.on('mouseout.starrr', function () {
                return _this.syncRating();
            });
            this.$el.on('click.starrr', 'span', function (e) {
                return _this.setRating(_this.$el.find('span').index(e.currentTarget) + 1);
            });
            this.$el.on('starrr:change', this.options.change);
        }

        Starrr.prototype.createStars = function () {
            var _i, _ref, _results;

            _results = [];
            for (_i = 1, _ref = this.options.numStars; 1 <= _ref ? _i <= _ref : _i >= _ref; 1 <= _ref ? _i++ : _i--) {
                _results.push(this.$el.append("<span class='glyphicon .glyphicon-star-empty'></span>"));
            }
            return _results;
        };

        Starrr.prototype.setRating = function (rating) {
            if (this.options.rating === rating) {
                rating = void 0;
            }
            this.options.rating = rating;
            this.syncRating();
            return this.$el.trigger('starrr:change', rating);
        };

        Starrr.prototype.syncRating = function (rating) {
            var i, _i, _j, _ref;

            rating || (rating = this.options.rating);
            if (rating) {
                for (i = _i = 0, _ref = rating - 1; 0 <= _ref ? _i <= _ref : _i >= _ref; i = 0 <= _ref ? ++_i : --_i) {
                    this.$el.find('span').eq(i).removeClass('glyphicon-star-empty').addClass('glyphicon-star');
                }
            }
            if (rating && rating < 5) {
                for (i = _j = rating; rating <= 4 ? _j <= 4 : _j >= 4; i = rating <= 4 ? ++_j : --_j) {
                    this.$el.find('span').eq(i).removeClass('glyphicon-star').addClass('glyphicon-star-empty');
                }
            }
            if (!rating) {
                return this.$el.find('span').removeClass('glyphicon-star').addClass('glyphicon-star-empty');
            }
        };

        return Starrr;

    })();
    return $.fn.extend({
        starrr: function () {
            var args, option;

            option = arguments[0], args = 2 <= arguments.length ? __slice.call(arguments, 1) : [];
            return this.each(function () {
                var data;

                data = $(this).data('star-rating');
                if (!data) {
                    $(this).data('star-rating', (data = new Starrr($(this), option)));
                }
                if (typeof option === 'string') {
                    return data[option].apply(data, args);
                }
            });
        }
    });
})(window.jQuery, window);

$(function () {
    return $(".starrr").starrr();
});

$(document).ready(function () {

    $('#stars').on('starrr:change', function (e, value) {
        $('#count').html(value);
    });

    $('#stars-existing').on('starrr:change', function (e, value) {
        $('#count-existing').html(value);
    });

$('#calendar').fullCalendar({
        // put your options and callbacks here
	height: 350
    })

 
});


var scheduledDataSet = [
    ["1", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Tiger Nixon", "TigerNixon@gmail.com", "Dotnet Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],

    ["2", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Garrett Winters", "GarrettWinters@gmail.com", "Java Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],

    ["3", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Ashton Cox", "AshtonCox@gamil.com", "Python Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["4", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Cedric Kelly", "CedricKelly@gmail.com", "UI/UX Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["5", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Airi Satou", "AiriSatou@gmail.com", "Angular Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["6", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Brielle Williamson", "BrielleWilliamson@gmail.com", "Java Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["7", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Herrod Chandler", "HerrodChandler@gmail.com", "UI/UX Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["8", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Rhona Davidson", "RhonaDavidson@gmail.com", "Python Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["9", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Colleen Hurst", "ColleenHurst@gmail.com", "San Francisco", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["10", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Sonya Frost", "SonyaFrost@gmail.com", "UI/UX Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["11", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Jena Gaines", "JenaGaines@gmail.com", "Java Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["12", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Quinn Flynn", "QuinnFlynn@gmail.com", "Python Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["13", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Charde Marshall", "ChardeMarshall@gmail.com", "Java Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["14", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Haley Kennedy", "HaleyKennedy@gmail.com", "Java Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["15", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Tatyana Fitzpatrick", "TatyanaFitzpatrick@gmail.com", "Java Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span>"],


    ["16", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Michael Silva", "MichaelSilva@gmail.com", "Python Developer", "<span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2017</span> <span class='label label-warning'>19-DEC-2018</span>"]
];



var scheduledConfirmedDataSet = [
    ["1", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Tiger Nixon", "TigerNixon@gmail.com", "7789078908", "Dotnet Developer", "<span class='label label-warning'>19-DEC-2017</span>", "<button type='button' class='btn btn-default feedback' data-toggle='tooltip' data-placement='right' title='Feedback'><i class='fa fa-comments' aria-hidden='true' ></i></button>"],
    
    ["2", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Tiger Nixon", "TigerNixon@gmail.com", "7789078908", "Dotnet Developer", "<span class='label label-warning'>19-DEC-2017</span>", "<button type='button' class='btn btn-default feedback' data-toggle='tooltip' data-placement='right' title='Feedback 1'><i class='fa fa-comments' aria-hidden='true' ></i></button>"]
    ];





var selectedDataSet = [
     ["1", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Tiger Nixon", "TigerNixon@gmail.com", "7789078908", "Dotnet Developer", "<span class='label label-success'>19-DEC-2017</span>", "<button type='button' class='btn btn-default projectAllocation' data-toggle='tooltip' data-placement='bottom' title='Project Allocation'><i class='fa fa-paper-plane-o' aria-hidden='true' ></i></button>"]
    ];


var rejectedDataSet = [
    ["1", "<img alt='40x40' data-src='holder.js/40x40' class='img-circle' src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgdmlld0JveD0iMCAwIDE0MCAxNDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzE0MHgxNDAKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjA3NzRkYzFmYyB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2MDc3NGRjMWZjIj48cmVjdCB3aWR0aD0iMTQwIiBoZWlnaHQ9IjE0MCIgZmlsbD0iI0VFRUVFRSIvPjxnPjx0ZXh0IHg9IjQ0LjA1NDY4NzUiIHk9Ijc0LjUiPjE0MHgxNDA8L3RleHQ+PC9nPjwvZz48L3N2Zz4=' data-holder-rendered='true' style='width: 40px; height: 40px;'> Tiger Nixon", "TigerNixon@gmail.com", "7789078908", "Dotnet Developer", "<span class='label label-primary'>19-DEC-2017</span> <button type='button' class='btn btn-default' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa-eye' aria-hidden='true' ></i></button>"]
    ];


 var ongoingProjectDataSet = [
        
        [
           "1", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "2", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "3", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "4", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "5", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "6", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "7", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ],
        [
           "8", "Ben8721", "Sathish", "15-Nov-2017", "10-SEP-2017"            
        ]
    ]


     var InprogressDataSet = [
     ["1", "BNA15914180", "Bency Away", "T R Consultancy", "Kumar", "05-Jan-2018", "10-Jan-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["2", "BNA15914179", "Health Maintenanace System", "T R Consultancy", "Sthish", "10-Jan-2018", "20-Jan-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["3", "BNA15914178", "Cyber JobMela", "T R Consultancy", "Rossy Melina", "20-Jan-2018", "25-Jan-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["4", "BNA15914177", "Notepad Editor System", "T R Consultancy", "John Brito", "25-Jan-2018", "29-Jan-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["5", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["6", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["7", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["8", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["9", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["10", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["11", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ],
      ["12", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProjectDetails padding-5px' data-toggle='tooltip' data-placement='right' title='View Details'><i class='fa fa fa-eye' aria-hidden='true' ></i></button>"
      ]
    ];



     var completedDataSet = [
     ["1", "BNA15914180", "Bency Away", "T R Consultancy", "Kumar", "05-Jan-2018", "10-Jan-2018", 
     "<button type='button' class='btn btn-default viewProject  padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice  padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice  padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["2", "BNA15914179", "Health Maintenanace System", "T R Consultancy", "Sthish", "10-Jan-2018", "20-Jan-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["3", "BNA15914178", "Cyber JobMela", "T R Consultancy", "Rossy Melina", "20-Jan-2018", "25-Jan-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["4", "BNA15914177", "Notepad Editor System", "T R Consultancy", "John Brito", "25-Jan-2018", "29-Jan-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["5", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["6", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["7", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ],
      ["8", "BNA15914176", "SMS Based Student Initmation", "T R Consultancy", "David Grish", "30-Jan-2018", "10-Feb-2018", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa fa-eye' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default viewInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='View Invoice'><i class='fa fa-file-o' aria-hidden='true' ></i></button> <button type='button' class='btn btn-default addInvoice padding-5px' data-toggle='tooltip' data-placement='right' title='Add Invoice'><i class='fa fa-file-text-o' aria-hidden='true' ></i></button>"
      ]
    ];


    var upcomingDataSet = [
     ["1", "5-Jan-2017", "Freelancing", "H R Solution", "Raji - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["2", "7-Jan-2017", "Hire", "Cognizant", "Raja - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["3", "9-Jan-2017", "Freelancing", "H R Solution", "RMary - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["4", "18-Jan-2017", "Freelancing", "H R Solution", "Mara - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["5", "20-Jan-2017", "Hire", "Cognizant", "Sara - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["6", "21-Jan-2017", "Freelancing", "H R Solution", "Raji - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["7", "25-Jan-2017", "Hire", "TCS", "Rea - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ],
      ["8", "28-Jan-2017", "Hire", "Infosys", "Raji - 9843567890", 
     "<button type='button' class='btn btn-default viewProject padding-5px' data-toggle='tooltip' data-placement='right' title='View Project'><i class='fa fa-file-o' aria-hidden='true' ></i></button>"
      ]
    ];


    WaitingforConfirmationDataSet = [
          ["1", "Freelancing", "HR Solution", "Raji - 9843567890", "5-Jan-2017", "<a href='#' class='declainedDialog' data-toggle='modal' data-target='#acceptDialog' data-whatever='@mdo'><i class='fa fa fa-check text-orange' aria-hidden='true' ></i></a> <a   href='#' class='declainedDetailDialog' data-toggle='modal' data-target='#declainedDetailDialog' data-whatever='@mdo'><i class='fa fa-files-o text-blue' aria-hidden='true' ></i></a> <a  href='#' class='declainedDialog' data-toggle='modal' data-target='#declainedDialog' data-whatever='@mdo'><i class='fa fa-line-chart text-red' aria-hidden='true' ></i></a>"],
    ]

    DeclainedDataSet = [
          ["1", "Freelancing", "HR Solution", "Raji - 9843567890", "Commited", "<a href='#' class='declainedDetailDialog' data-toggle='modal' data-target='#declainedDetailDialog' data-whatever='@mdo'><i class='fa fa-files-o' aria-hidden='true' ></i></a> "],
    ]
 

   myInvoicesPendingDataSet = [
       [ "1", "1454245", "PRJ - Content Management", "ABC Private Limited", "$1200", "<span class='label label-warning'>PENDING<span>", "<a href='#'><i class='fa fa-eye text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-comments-o  text-black' aria-hidden='true' ></i></a> <a href='#' class='invoiceModal' data-toggle='modal' data-target='#invoiceModal'><i class='fa fa-files-o  text-black' aria-hidden='true' ></i></a>"    ]
   ]


   myInvoicesUnbilledDataSet = [
     ["1" ,"PRJ - Content Management", "ABC Private Limited", "$1200", "<span class='label badge-info'>UN-BILLED<span>", "<a href='#'><i class='fa fa-comments-o  text-black' aria-hidden='true' ></i></a> <a href='#' data-toggle='tooltip' data-original-title='View Project' data-placement='right'><i class='fa fa-files-o text-black' aria-hidden='true' ></i></a>"    ]
   ]


   myInvoicesRecievedDataSet = [
         ["1" ,"PRJ - Content Management", "ABC Private Limited", "$1200", "<span class='label label-success'>RECEIVED<span>", "<a href='#'><i class='fa fa-eye text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-comments-o  text-black' aria-hidden='true' ></i></a> <a href='#' class='invoiceModal' data-toggle='modal' data-target='#invoiceModal'><i class='fa fa-files-o  text-black' aria-hidden='true' ></i></a>"    ]
   ]

   myInvoicesRejectedDataSet = [
        ["1", "PRJ - Content Management", "ABC Private Limited", "$1200", "<span class='label badge-error'>REJECTED<span>", "<a href='#'><i class='fa fa-comments-o  text-black' aria-hidden='true' ></i></a> <a href='#' data-toggle='tooltip' data-original-title='View Project' data-placement='right'><i class='fa fa-files-o text-black' aria-hidden='true' ></i></a>"    ]
   ]



    myOffersRecievedDataSet = [
     ["1" ,"PRJ - Content Management", "ABC Private Limited", "", "01-FEB-2016", "08-JUN-2016", "<a href='#'><i class='fa fa-file-text-o  text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-check  text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-times text-black' aria-hidden='true' ></i></a>"    ]
   ]


   myOffersAcceptedDataSet = [
          ["1", "PRJ - Investment Mangement System", "Secores Technologies", "", "", "<a href='#'><i class='fa fa-file-text-o  text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-check  text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-times text-black' aria-hidden='true' ></i></a>"    ]
   ]


   myOffersRejectedDataSet = [
        ["1", "PRJ - Investment Mangement System", "Secores Technologies", "", "",  "<a href='#'><i class='fa fa-file-text-o  text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-check  text-black' aria-hidden='true' ></i></a> <a href='#'><i class='fa fa-times text-black' aria-hidden='true' ></i></a>"    ]
   ]


$(document).ready(function () {

$(document).on('click',"#myOffer-panel",function(){          
     window.location = 'myoffers.html'
   })

    $('#scheduledGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: scheduledDataSet,
		   responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Freelancer Name"
            },
            {
                title: "Email ID"
            },
            {
                title: "Role"
            },
            {
                title: "Interview Scheduled"
            }
        ]
    });
	

 
    $('#scheduledConfirmedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: scheduledConfirmedDataSet,
		responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Freelancer Name"
            },
            {
                title: "Email ID"
            },
            {
                title: "Contact No"
            },
            {
                title: "Role"
            },
            {
                title: "Confirmed Date"
            },
            {
                title: "Action"
            }
        ]
    });
    
   var table = $('#scheduledConfirmedGrid').DataTable();

    $('#scheduledConfirmedGrid tbody').on('click', '.feedback', function () {
      window.location = "feedback.html";
    });
	
	
	$('#ongoingProjectGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: ongoingProjectDataSet,
		responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project No"
            },
            {
                title: "Reprt Person"
            },
            {
                title: "Start"
            },
            {
                title: "End"
            }
        ]
    });


    $('#selectedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: selectedDataSet,
		 responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Freelancer Name"
            },
            {
                title: "Email ID"
            },
            {
                title: "Contact No"
            },
            {
                title: "Role"
            },
            {
                title: "Confirmed Date"
            },
            {
                title: "Action"
            }
        ]
    });

 var selectedtable = $('#selectedGrid').DataTable();

    $('#selectedGrid tbody').on('click', '.projectAllocation', function () {
      window.location = "projectallocation.html";
    });


    $('#rejectedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: rejectedDataSet,
		 responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Freelancer Name"
            },
            {
                title: "Email ID"
            },
            {
                title: "Contact No"
            },
            {
                title: "Role"
            },
            {
                title: "Interviewed Date"
            }
        ]
    });
    

   
 $('#InprogressGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: InprogressDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project ID"
            },
            {
                title: "Project Name"
            },
            {
                title: "Customer"
            },
            {
                title: "Reporting Person"
            },
            {
                title: "Start Date"
            },
            {
                title: "End Date"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var Inprogresstable = $('#InprogressGrid').DataTable();

    $('#InprogressGrid tbody').on('click', '.viewProjectDetails', function () {
      window.location = "projectviewdetails.html";
    });



     $('#completedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: completedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project ID"
            },
            {
                title: "Project Name"
            },
            {
                title: "Customer"
            },
            {
                title: "Reporting Person"
            },
            {
                title: "Start Date"
            },
            {
                title: "End Date"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var completedtable = $('#completedGrid').DataTable();

    $('#completedGrid tbody').on('click', '.viewProject', function () {
      window.location = "projectviewdetails.html";
    });

    $('#completedGrid tbody').on('click', '.viewInvoice', function () {
      //window.location = "viewinvoice.html";
    });

    $('#completedGrid tbody').on('click', '.addInvoice', function () {
     // window.location = "addinvoice.html";
    });



$('#UpcomingGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: upcomingDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Interview date"
            },
            {
                title: "Allocation tyoe"
            },
            {
                title: "Organization"
            },
            {
                title: "Point of contact"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#UpcomingGrid').DataTable();

    $('#UpcomingGrid tbody').on('click', '.viewProject', function () {
      window.location = "upcomingGrid.html";
    });



    $('#WaitingforConfirmationGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: WaitingforConfirmationDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Allocation type"
            },
            {
                title: "Organization"
            },
            {
                title: "Point of contact"
            },
            {
                title: "Creation date"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#WaitingforConfirmationGrid').DataTable();

    $('#WaitingforConfirmationGrid tbody').on('click', '.declainedDialog', function (event) {
    
    });


     $('#DeclainedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: DeclainedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Allocation type"
            },
            {
                title: "Organization"
            },
            {
                title: "Point of contact"
            },
            {
                title: "Reason"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#DeclainedGrid').DataTable();

    $('#DeclainedGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });



     $('#myInvoicesPendingGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myInvoicesPendingDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Invoice No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organization"
            },
            {
                title: "Invoice Amount"
            },
            {
                title: "Status"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myInvoicesPendingGrid').DataTable();

    $('#myInvoicesPendingGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });


    $('#myInvoicesUnbilledGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myInvoicesUnbilledDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organization"
            },
            {
                title: "Invoice Amount"
            },
            {
                title: "Status"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myInvoicesUnbilledGrid').DataTable();

    $('#myInvoicesUnbilledGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });



    $('#myInvoicesRecievedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myInvoicesRecievedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organization"
            },
            {
                title: "Invoice Amount"
            },
            {
                title: "Status"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myInvoicesRecievedGrid').DataTable();

    $('#myInvoicesRecievedGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });


    $('#myInvoicesRejectedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myInvoicesRejectedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organization"
            },
            {
                title: "Invoice Amount"
            },
            {
                title: "Status"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myInvoicesRejectedGrid').DataTable();

    $('#myInvoicesRejectedGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });




    $('#myOffersReceivedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myOffersRecievedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organization"
            },
            {
                title: "Allocation Type"
            },
            {
                title: "Project Start Date"
            },
            {
                title: "Project End Date"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myOffersReceivedGrid').DataTable();

    $('#myOffersReceivedGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });



    $('#myOffersAcceptedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myOffersAcceptedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organization"
            },
            {
                title: "Allocation Type"
            },
            {
                title: "Accepted Date"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myOffersAcceptedGrid').DataTable();

    $('#myOffersAcceptedGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });


    $('#myInvoiceRejectedGrid').DataTable({
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        data: myOffersRejectedDataSet,
         responsive: true,
        columns: [
            {
                title: "S.No"
            },
            {
                title: "Project Name/ID"
            },
            {
                title: "Organizations"
            },
            {
                title: "Allocation Type"
            },
            {
                title: "Rejected Date"
            },
            {
                title: "Actions"
            }
        ]
    });
   
     
    var upcomingtable = $('#myInvoiceRejectedGrid').DataTable();

    $('#myInvoiceRejectedGrid tbody').on('click', '.viewProject', function () {
      window.location = "declained.html";
    });



       
   
    $('[data-toggle="tooltip"]').tooltip();


   
});
