import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'


import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';

import { ArtuseractivitiesComponent } from './artuseractivities/artuseractivities.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomersComponent } from './customers/customers.component';
import { CustomerviewComponent } from './customerview/customerview.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SidebarnavComponent } from './sidebarnav/sidebarnav.component';
import { UsecasesComponent } from './usecases/usecases.component';

  


@NgModule({
  imports: [
  	BrowserModule,
  	DashboardRoutingModule,
    CommonModule,
    HttpClientModule,
    FormsModule

  ],
  declarations: [
      DashboardComponent,
      ArtuseractivitiesComponent,
      CustomerComponent,
      CustomersComponent,
      CustomerviewComponent,
      HeaderComponent,
      SidebarComponent,
      SidebarnavComponent,
      UsecasesComponent

  ],
  providers: [],
  bootstrap: [DashboardComponent]
})
export class DashboardModule { } 
