import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { serviceURL } from '../../serviceURL';
import {NgbDropdownConfig} from '@ng-bootstrap/ng-bootstrap';

import * as $ from "jquery";
declare var $: $
import * as echarts from 'echarts';

declare var Circles: any;
declare var multiselect: any;


@Component({
  selector: 'app-usecases',
  templateUrl: './usecases.component.html', 
  styleUrls: ['./usecases.component.scss'],
   providers : [
    serviceURL
  ]
})
export class UsecasesComponent implements OnInit { 
    
    customerID: any;
    isChecked : boolean = true;

    requestType =
     [
    {
      RequestType : "Service Request"
    },

    {
      RequestType : "Incident"
    }

    ];


    constructor(private router : Router, private httpService: HttpClient,  private activatedRoute: ActivatedRoute,  private location: Location,  public url : serviceURL, config: NgbDropdownConfig) {

          this.customerID = (this.activatedRoute.snapshot.params).id;
          this.customerID == undefined ?  this.customerID = 0 : 
          this.customerID = (this.activatedRoute.snapshot.params).id;
      


            config.placement = 'bottom-left';
            config.autoClose = 'outside';
         
        let totalCount : any; 

        $.getJSON(this.url.prodURL + 'Report/Api/GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;  
             
             $("#automated_Tkt_count").html(totalCount);
        })
     

       }

       __BindAAIInfo() {       
     
        $.getJSON(this.url.prodURL + "Report/Api/GetCustomerWiseAAI/" + this.customerID, function(data) {

            $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
            $("#AAIRequssseCaseDev").html(data.InProgressCnt);            
            
        })
    };

// console.log(event, ' ', event.checked,' ', event.source.value); 

getCheckedValue(event){
console.log(event);
console.log(event.target.checked);
console.log(event.target.defaultValue); 

if(event.target.checked == false && event.target.defaultValue == 'Service Request'){
  $("#dvUseCaseContainer div[data-requesttype='Service Request']").hide();
}
else if(event.target.checked == false && event.target.defaultValue == 'Incident'){   
   $("#dvUseCaseContainer div[data-requesttype='Incident']").hide();
}

if(event.target.checked == true && event.target.defaultValue == 'Service Request'){
  $("#dvUseCaseContainer div[data-requesttype='Service Request']").show();
}
else if(event.target.checked == true && event.target.defaultValue == 'Incident'){   
   $("#dvUseCaseContainer div[data-requesttype='Incident']").show();
}

}
   

 typeHideShow(isChecked: boolean, RequestType: string){

           if(isChecked) {

           alert(RequestType);
                 
      } else {
         alert(RequestType);
      }

 } 

  ngOnInit() {

     this.__BindAAIInfo(); 


   


       $('#option-droup-demo').multiselect({
            enableClickableOptGroups: true,
            nonSelectedText: 'Select Category',
            //   includeSelectAllOption: true,

            onChange : function(option, checked) {
                   useCase.filterByCategory(option, checked)
            },

        }); 


 
     var  url = this.url.prodURL;

        

              var useCase = {

					    defaults:{                              
                             customerId :  this.customerID                                      
					    },
					    init:function(){

					              useCase.bindIncidentUseCase();
        						  useCase.bindUseCase();
					    },
					    find_in_object: function (my_object, my_criteria) {
					        return my_object.filter(function (obj) {
					            return Object.keys(my_criteria).every(function (c) {
					                return obj[c] == my_criteria[c];
					            });
					        });
					    },
              bindIncidentUseCase : function() {

               $.getJSON( url + "Report/Api/GetCustomerUseCaseDetails/" + useCase.defaults.customerId, function(data) {
      
                var useCaseCnt = 0;
                var incidentCnt = 0;
                var serviceReqCnt = 0;         
         
                if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
            {
                var filterjson = useCase.find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                {
                    useCaseCnt += filterjson[0].Count;
                    incidentCnt = filterjson[0].Count;
                    $("#hincidentUseCaseProd").html(filterjson[0].Count);

                 
                }
                var srfilterjson = useCase.find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                {
                    useCaseCnt += srfilterjson[0].Count;
                    serviceReqCnt = srfilterjson[0].Count;
                    $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                    
                }
               
            }
            if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined)
            {
                 var filterjson = useCase.find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hincidentUseCaseDev").html(filterjson[0].Count);
                }
                
                var srfilterjson = useCase.find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                }
            }
            if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined)
            {
                 var filterjson = useCase.find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                }
                
                var srfilterjson = useCase.find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                }
            }
            
          
            
        })
   

                       },
                       bindUseCase : function() {

                          
        $.getJSON( url +"Report/Api/GetCustomerUseCaseWise/" + useCase.defaults.customerId, function(data) {
           
            var useCaseTemplate = $("#dvUseCaseTemplate").html();
            $("#dvUseCaseContainer").html('');
             var category = []
            for(var i = 0;i<data.length;i++)
            {
             // $("#dvUseCaseContainer").append(useCaseTemplate.replace(/{index}/g,i) ) 
              
              $("#dvUseCaseContainer").append(useCaseTemplate.replace(/{index}/g,i) );

               // $("#dvUseCaseContainer").append(useCaseTemplate) 
                
                if($.inArray(data[i].ParentCategory+'('+data[i].ChildCategory+')',category) == -1)
                {
                    category.push(data[i].ParentCategory+'('+data[i].ChildCategory+')');
                }


                
                var tags = "";
                if(data[i].Tags != null)
                {
                  var tagArray = data[i].Tags.split(',');
                  for(var j = 0;j< tagArray.length;j++)
                  {
                      tags += '<h2 class="d-inline"> <span class="badge badge-secondary" style="background: rgba(164, 180, 196, 1); color: #fff;  font-size: .8rem;border-radius: 40px;    padding: 3px 8px;font-weight: 500;">';
                      tags += '<img src="../../assets/images/incident_icn.svg" alt="" class="img-fluid" width="20px">'
                      tags += ''+tagArray[j]+'</span></h2>'
                  }
                  $("#dvUseCaseTags_"+i).html(tags);
                }

                var reqTags = data[i].RequestType;
                 
                 $("#RequestType_"+i+ " span").addClass(reqTags);
                 $("#RequestType_"+i+ " span").html(reqTags);


                   $("#totalCount_"+i).html(data[i].Count);
                
                
                $("#dvUseCase_"+i).attr('data-parentCat',data[i].ParentCategory);
                $("#dvUseCase_"+i).attr('data-childCat',data[i].ChildCategory);
                 $("#dvUseCase_"+i).attr('data-requestType',data[i].RequestType);
                
                $("#spnUseCaseName_"+i).html(data[i].UseCaseName);
                $("#hUseCaseDescription_"+i).html(data[i].Description);
                $("#hUseCaseManualMTTR_"+i).html(Math.round(data[i].ManualMTTR),0);
                $("#hUseCaseAutoMTTR_"+i).html(Math.round(data[i].AutomationMTTR),0);
                

              

                // var successRatePer = Math.round(data[i].SuccessRate,0); // bind one arg
                var successRatePer = Math.round(data[i].SuccessRate);
                var colour = 'white'
                //debugger;
                if(successRatePer >= 0 && successRatePer < 50)
                {
                    $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                    $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                    $("#dvSuccessRateContainer-"+i).addClass("bg-red");
                    colour = '#f7bf44'
                }
                else if(successRatePer > 50 && successRatePer < 80)
                    {
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                        $("#dvSuccessRateContainer-"+i).addClass("bg-orange");

                        colour = '#ff9e6d'
                    }
                else
                    {
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                        $("#dvSuccessRateContainer-"+i).addClass("bg-green");
                        colour = '#56e6c3'
                    }


                    $('#circles-successrate-'+i).html(successRatePer + "%");

                
                var effReducedPer = 100 - ((data[i].AutomationMTTR * 100) / data[i].ManualMTTR)

                 var myCircle = Circles.create({
                  id:                  'circles-effreduced-'+i,
                  radius:              40,
                  value:               Math.round(effReducedPer),  // bind one arg    Math.round(effReducedPer,0)
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['', '#56e6c3'],
                  duration:            0,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });

            }
            
             useCase.BuildCategoryMultiselect(category)
        }) 
   

                       },
    BuildCategoryMultiselect: function(category)
    {
        var content = ""
        content += '<optgroup label="Category">';
        for(var i=0; i < category.length;i++)
        {
            content += '<option value="'+category[i]+'">'+category[i]+'</option>';
        }
         content += '</optgroup>';

        $("#option-droup-demo").append(content);
       $("#option-droup-demo").multiselect('rebuild');




    },
    filterByCategory: function(option,checked)
    {
        
        var selectedValue = $('select#option-droup-demo').val();
        
        $("#dvUseCaseContainer div.section-wrape").each(function(i){
            $(this).hide();               
        })
        
        for(var i = 0;i< selectedValue.length;i++)
        {
            //debugger
            var parentCategory = selectedValue[i].split('(')[0]
            var childCategory = selectedValue[i].split('(')[1].replace(')','')
            
              $("#dvUseCaseContainer div.section-wrape").each(function(i){
              
                if($(this).attr('data-parentCat').toLowerCase() == parentCategory.toLowerCase() && $(this).attr('data-childCat').toLowerCase() == childCategory.toLowerCase())
                {
                    $(this).show();
                }
            })
        }
        
        if(selectedValue.length == 0)
        {
             $("#dvUseCaseContainer div.section-wrape").each(function(i){
                $(this).show();               
            })
        }
    }




                }
              
useCase.init();

              
       }

       

       

  }


