export class serviceURL {	
   public prodURL : string = "https://reportit.hexaware.com/";
}