import { Injectable } from '@angular/core';

@Injectable()
export class sidebarService {
	
	visible : boolean;
	

	constructor (){ this.visible = true; }

	hide() { 	
	this.visible = false; 
	
	} 

	show() {
	 this.visible = true;
	  }


	  hideTotalCustomer(){
	   this.visible = false; 
	  }

	  showTotalCustomer(){
	   this.visible = true;
	  }
}