import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { serviceURL } from '../serviceURL';
import * as $ from "jquery";
declare var $: $
declare var session: any; 
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
  providers : [
    serviceURL
  ]
})
export class SigninComponent implements OnInit {

  constructor(private httpService: HttpClient, private router: Router, public url : serviceURL) {}


   userName : string;
   Password : any;
   success : any;
   model : any = {};



   SetCookie()
        {
             // debugger;
             var date = new Date();
             var minutes = 30;
             date.setTime(date.getTime() + (minutes * 60 * 1000));
             $.session.set("isValidUser","Y");
                     
        } 


 onSubmit() {


            console.log(this.model);
            this.userName =  $("#txtUserName").val();
            this.Password =  $("#txtPassword").val();

           

           this.httpService.get("https://reportit.hexaware.com/Report/Api/Authenticate/"+this.userName+"/"+this.Password).subscribe(
      data => {
 
         this.success = data as any []; // FILL THE ARRAY WITH DATA.
        
         if( (this.success).toUpperCase() === "LOGIN SUCCESSFULLY"){
            this.SetCookie();

           this .router.navigate(['/dashboard',{outlets: {'dashboardrouter' : ['customer']}}]);
             $('.modal-backdrop').hide();
             $('body').removeClass('modal-open');
            return false;
         }
              else{
               alert('Invalid UserName / Password')
              }
             

            },
      (err: HttpErrorResponse) => {
        console.log("error ")
        console.log (err.message);
      }
    );


    
    
  }
    
  __signIn(event: any){
            
            this.userName =  $("#txtUserName").val();
            this.Password =  $("#txtPassword").val();;


           this.httpService.get("https://reportit.hexaware.com/Report/Api/Authenticate/"+this.userName+"/"+this.Password).subscribe(
      data => {

         this.success = data as any []; // FILL THE ARRAY WITH DATA.
        
         if( (this.success).toUpperCase() === "LOGIN SUCCESSFULLY"){
           this.router.navigate(['/dashboard',{outlets: {'dashboardrouter' : ['customer']}}]);
         }
              else{
               alert('Invalid UserName / Password')
              }
             

            },
      (err: HttpErrorResponse) => {
      console.log("error ")
        console.log (err.message);
      }
    );


  }



  ngOnInit() {

 

  }

}
