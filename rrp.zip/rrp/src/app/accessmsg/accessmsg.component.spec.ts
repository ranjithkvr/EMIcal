import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessmsgComponent } from './accessmsg.component';

describe('AccessmsgComponent', () => {
  let component: AccessmsgComponent;
  let fixture: ComponentFixture<AccessmsgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccessmsgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccessmsgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
