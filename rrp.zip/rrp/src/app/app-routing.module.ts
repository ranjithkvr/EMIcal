import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CustomerComponent } from './dashboard/customer/customer.component';
import { UsecasesComponent } from './dashboard/usecases/usecases.component';
import { CustomersComponent } from './dashboard/customers/customers.component';
import { CustomerviewComponent } from './dashboard/customerview/customerview.component';

export const routes: Routes = [
	{ path: '', redirectTo: '/home', pathMatch: 'full' },
	{ path : 'home', component : HomeComponent },
	{ 
    path : 'dashboard', 
    component :  DashboardComponent , data: {title: 'Customer'} , 

    children : [  
	{ path: '', redirectTo: '/dashboard', pathMatch: 'full', data: {title: 'Customer'} },
    { path : 'allcustomer', component : CustomerComponent, data: {title: 'Customer'}},
    { path: 'usecases', component : UsecasesComponent,data: {title: 'Use cases'}},
    { path: 'customers', component : CustomersComponent,data: {title: 'Customers'}},  
    { path: 'customerview', component : CustomerviewComponent,data: {title: 'Customer View'}},   
    { path: 'customerview/:id', component : CustomerviewComponent,data: {title: 'Customer View'}},
	], runGuardsAndResolvers: 'always'}
];

@NgModule({
   exports : [RouterModule],
   imports : [RouterModule.forRoot(routes, {useHash: true})]
})
export class AppRoutingModule { }
