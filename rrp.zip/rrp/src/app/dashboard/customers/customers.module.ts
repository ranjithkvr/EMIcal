import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BrowserModule } from '@angular/platform-browser';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { CustomersComponent } from './customers.component';

@NgModule({
  imports: [
    CommonModule,
    NgModule,
    BrowserModule,
    HttpClientModule,
    FormsModule

  ],
  declarations: [CustomersComponent]
})
export class CustomersModule { }
