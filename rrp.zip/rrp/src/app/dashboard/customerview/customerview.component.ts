import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { serviceURL } from '../../serviceURL';
import { Title } from '@angular/platform-browser';


import * as $ from "jquery";
declare var $: $
import * as echarts from 'echarts';

declare var Circles: any;
declare var multiselect: any;


@Component({
  selector: 'app-customerview',
  templateUrl: './customerview.component.html',
  styleUrls: ['./customerview.component.scss'],
   providers : [
    serviceURL
  ]
})
export class CustomerviewComponent implements OnInit {


    customerID: any;
    customerByName : any = [];
    customerlist;

   
  
  constructor(private httpService: HttpClient, private router: Router, private activatedRoute: ActivatedRoute,  private location: Location, public url : serviceURL,  public titleService : Title) {

       this.customerID = (this.activatedRoute.snapshot.params).id;
              
          let totalCount : any; 

        $.getJSON(this.url.prodURL + 'GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;  
             
             $("#automated_Tkt_count").html(totalCount);
        })
        
           $('#customerlist option[value="' + this.customerID + '"]').attr("selected","selected"); 

         
    }

       __BindAAIInfo() {       
     
        $.getJSON( this.url.prodURL + "GetCustomerWiseAAI/" + this.customerID, function(data) {

          if(data !== null){
            $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
            $("#AAIRequssseCaseDev").html(data.InProgressCnt);      
          }
                   
            
        })
    };



  ngOnInit() {


  var routers =  this.router;
      
  this.titleService.setTitle("Customer view");


 $(function(){
 $(document).on('click','.more-data',function(){
                 
                 $(this).parent().next("table").toggle();
                 $(this).parent().toggleClass("no-border-top");
         })

 })
   


  var  url = this.url.prodURL;
  this.__BindAAIInfo();


     

  $('#customerlist option[value="' + this.customerID + '"]').attr("selected","selected"); 
    
    var customerDashboard = {

    defaults:{
        customerId: this.customerID
    },
    init:function(){
        customerDashboard.bindIncidentUseCase();
        customerDashboard.bindMonthWiseTicketAnalysis();
        //customerDashboard.bindUseCase();
        customerDashboard.bindAutomationStatistics();
    },
    bindIncidentUseCase: function() {     

        $.getJSON( url + "GetCustomerUseCaseDetails/" + customerDashboard.defaults.customerId, function(data) {

            var useCaseCnt = 0;
            var incidentCnt = 0;
            var serviceReqCnt = 0;
            var customerId = "";

                if(data.AutomatedUseCaseCategory[0] !== undefined){
                    $('.customer_title').html(data.AutomatedUseCaseCategory[0].CustomerName);
                }
                else{
                    routers.navigate(['/dashboard/allcustomer']);
                }



                if( data != null  && data != undefined && data.AutomatedUseCaseCategory != null && data.AutomatedUseCaseCategory != undefined)
                {

                    var wofilterjson = customerDashboard.find_in_object(data.AutomatedUseCaseCategory, {RequestType: 'Work Order'});
                
                    if(wofilterjson != null && wofilterjson != undefined && wofilterjson.length > 0)
                    {

                        $("#spnWorkOrderCnt").html(wofilterjson[0].Count);
                    }


                }

         

            if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
            {
                var filterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                {
                    useCaseCnt += filterjson[0].Count;
                    incidentCnt = filterjson[0].Count;
                    $("#hincidentUseCaseProd").html(filterjson[0].Count);
                    $("#spnIncCnt").html(filterjson[0].Count);
                }
                var srfilterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                {
                    useCaseCnt += srfilterjson[0].Count;
                    serviceReqCnt = srfilterjson[0].Count;
                    $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                    $("#spnServiceReqCnt").html(srfilterjson[0].Count);
                }
                
                var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100);
                // argument error -- var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100,0);
                
                var myCircle = Circles.create({
                  id:                  'circles-1',
                  radius:              60,
                  value:               incSuccessRate,
                  maxValue:            100,
                  width:                2,
                  text:                function(value){return value + '%';},
                  colors:              ['#EBE9E9', '#E28811'],
                  duration:            400,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });
                
                var serviceReqSuccessRate = Math.round((serviceReqCnt / useCaseCnt) * 100);
                // argument error --  Math.round((serviceReqCnt / useCaseCnt) * 100,0);

                
                var myCircle = Circles.create({
                  id:                  'circles-2',
                  radius:              60,
                  value:               serviceReqSuccessRate,
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['#EBE9E9', '#E28811'],
                  duration:            400,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });
               
           
                $("#spnautomationUSCnt").html(useCaseCnt);
            }
            if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined)
            {
                 var filterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hincidentUseCaseDev").html(filterjson[0].Count);
                }
                
                var srfilterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined && srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                }
            }
            if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined)
            {
                 var filterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined && filterjson.length > 0)
                {
                    $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                }
                
                var srfilterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined && srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                }
            }
            
            //self.customers(data);
            
        })
    },
    bindMonthWiseTicketAnalysis: function(){

    var resultData;

   function getDetails() {
  
   var settings = {
    "async": true,
    "crossDomain": true,
    "url": url+"GetCustomerMonthYrWiseTypeAnalysis/"+customerDashboard.defaults.customerId,
    "method": "GET",
   /* "headers": {
     "Authorization": "Basic ZWxhc3RpYzpwYXNzd29yZDEyMw==",
     } */
    }


      // https://reportit.hexaware.com/reportitapiv2/Api/GetCustomerMonthYrWiseTicketAnalysis
             //  https://reportit.hexaware.com/reportitapiv2/Api/GetCustomerMonthYrWiseTypeAnalysis/2
        

 function myCallback(response){

         resultData = response;
         var htmResp = "";

         

        $.getJSON( url + "GetCustomerMonthYrWiseTicketAnalysis/" + customerDashboard.defaults.customerId, function(data) {

        
            if(data.length > 0 )
            {
            var htmlTabContent = "";
            htmlTabContent += '<table class="table table-hover  table-striped mb-0">'
            htmlTabContent += '<thead>'
            htmlTabContent += '<tr cl>'
            htmlTabContent += '<th scope="col" class="border-top-0">Month</th>'
            htmlTabContent += '<th scope="col" class="border-top-0">Total Tickets</th>'
            htmlTabContent += '<th scope="col" class="border-top-0">Automated Tickets</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">Rejected Tickets</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">Success Rate</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">Rejected Rate</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">More</th>'
            htmlTabContent+= '</tr>'
            htmlTabContent += '</thead>'
            htmlTabContent+= '<tbody>'

          

            
                        
                        for(var i = 0 ; i<data.length;i++)
                        {
                            htmlTabContent+= '<tr>'
                            htmlTabContent+= '<td>'+data[i].Month+'</td>'
                            htmlTabContent+= '<td>'+data[i].Count+'</td>'
                            
                            htmlTabContent+= '<td>'+data[i].AutomatedTickets+'</td>'
            
                            htmlTabContent+= '<td>'+   data[i].RejectedTickets  + '</td>'
                            htmlTabContent+= '<td>'+Math.round(data[i].SuccessRate)+' %</td>'
                            // htmlTabContent+= '<td>'+Math.round(data[i].SuccessRate,4)+' %</td>'
                            htmlTabContent+= '<td>'+Math.round(data[i].RejectedRate)+' %</td>'
                            // htmlTabContent+= '<td>'+Math.round(data[i].RejectedRate,4)+' %</td>'
                            htmlTabContent+= '<td style="cursor:pointer" class="more-data"> <img src="assets/images/more.png" alt="more"> </td>'
                            htmlTabContent+= '</tr>'


                         


                htmlTabContent+= '<tr style="display:none" class="child-table"> <td colspan="7" class="p-0">'
                htmlTabContent+= '<table class="table m-0 p-0 table-hover table-striped"><thead class="bg-white">'
                 htmlTabContent+= '<tr> <th> Type </th> <th> Total Tickets </th>  <th> Automated Tickets </th>  <th>Rejected Tickets </th> <th>'
                 htmlTabContent+= ' Success Rate  </th>  <th> Failure Rate </th> </tr>'
                 htmlTabContent+= '</thead><tbody>'
 
 
                 htmlTabContent+= '</thead><tbody>'
                 // Incident
                     if(resultData.Incident != undefined ){
                         htmlTabContent+= '<tr class="table-incident">'
                         htmlTabContent+=  '<td width="20.0%"> Incidents </td>' 
                          htmlTabContent+=  '<td>' + resultData.Incident[i].Count + '</td>' 
                           htmlTabContent+=  '<td>' + resultData.Incident[i].AutomatedTickets + '</td>'
                           htmlTabContent+=  '<td>' +  resultData.Incident[i].RejectedTickets + '</td>'  
                            htmlTabContent+=  '<td>' + Math.round(resultData.Incident[i].SuccessRate) + '%</td>'                    
                              htmlTabContent+=  '<td>' + Math.round(resultData.Incident[i].RejectedRate) + '%</td>' 
                         htmlTabContent+= '</tr>'
             
                     }
                          
                   
                          if(resultData.ServiceRequest != undefined ){ 
                          // ServiceRequest
                          htmlTabContent+= '<tr class="table-servicereq">'
                          htmlTabContent+=  '<td> Service Requests </td>' 
                            htmlTabContent+=  '<td>' + resultData.ServiceRequest[i].Count + '</td>' 
                              htmlTabContent+=  '<td>' + resultData.ServiceRequest[i].AutomatedTickets + '</td>'                   
                                  htmlTabContent+=  '<td>' +  resultData.ServiceRequest[i].RejectedTickets + '</td>' 
                                  htmlTabContent+=  '<td>' + Math.round(resultData.ServiceRequest[i].SuccessRate) + '%</td>' 
                                    htmlTabContent+=  '<td>' + Math.round(resultData.ServiceRequest[i].RejectedRate) + '%</td>' 
                          htmlTabContent+= '</tr>'  
                          }


                        if(resultData.WorkOrder != undefined ){ 
                            // WorkOrder
                            htmlTabContent+= '<tr class="table-workorder">'
                            htmlTabContent+=  '<td> Work Order </td>' 
                              htmlTabContent+=  '<td>' + resultData.WorkOrder[i].Count + '</td>' 
                                htmlTabContent+=  '<td>' + resultData.WorkOrder[i].AutomatedTickets + '</td>'                   
                                    htmlTabContent+=  '<td>' +  resultData.WorkOrder[i].RejectedTickets + '</td>' 
                                    htmlTabContent+=  '<td>' + Math.round(resultData.WorkOrder[i].SuccessRate) + '%</td>' 
                                      htmlTabContent+=  '<td>' + Math.round(resultData.WorkOrder[i].RejectedRate) + '%</td>' 
                            htmlTabContent+= '</tr>'  
                            } 
 
                 htmlTabContent += '<tbody></table></td></tr>'  
  

            }
            
                                   
            htmlTabContent+= '</tbody>'
            htmlTabContent+= '</table>'
            
            $("#dvCustomerMonthTktAna").html(htmlTabContent);
        }
        })
         
 };

 $.ajax(settings).done(myCallback);
    
}

getDetails();



    },
    find_in_object: function (my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    },
   
    bindAutomationStatistics: function(){
        
        $.getJSON( url + "GetCustomerMonthYrWiseTicketAnalysis/" + customerDashboard.defaults.customerId, function(data) {
                     
            var monthArry = [];
            var automationTkts = [];
            var rejectedTkts = [];
            
           for(var i = 0;i<data.length;i++)
            {
                monthArry.push(data[i].Month);
                automationTkts.push(data[i].AutomatedTickets);
                rejectedTkts.push(data[i].RejectedTickets);
            }
            
            var dom = document.getElementById("container");
        var myChart = echarts.init(dom,'light');
        var app = {};
        var option = null;
        option = {    
            tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {
                data:['Automated Ticket','Rejected Ticket']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : monthArry
                }
            ],
            yAxis : [
                {
                    type : 'value'
                }
            ],
            series : [
                {
                    name:'Automated Ticket',
                    type:'line',
                    //smooth:true,
                    areaStyle: {normal: {}},
                    data:automationTkts
                },
                {
                    name:'Rejected Ticket',
                    type:'line',
                    //smooth:true,
                    areaStyle: {normal: {}},
                    data:rejectedTkts
                }

            ]
        };
        ;
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
        })
        
        
    },
    BuildCategoryMultiselect: function(category)
    {
        var content = ""
        content += '<optgroup label="All">';
        for(var i=0; i < category.length;i++)
        {
            content += '<option selected="true"  value="'+category[i]+'">'+category[i]+'</option>';
        }
         content += '</optgroup>';

        $("#option-droup-demo").html(content);
       // $("#option-droup-demo").multiselect('rebuild');

      
    },
    filterByCategory: function(option,checked)
    {
        
        var selectedValue = $('select#option-droup-demo').val();
        
        $("#dvUseCaseContainer div.section-wrape").each(function(i){
            $(this).hide();               
        })
        
        for(var i = 0;i< selectedValue.length;i++)
        {
            //debugger
            var parentCategory = selectedValue[i].split(' (')[0]
            var childCategory = selectedValue[i].split(' (')[1].replace(')','')
            
              $("#dvUseCaseContainer div.section-wrape").each(function(i){
              
                if($(this).attr('data-parentCat').toLowerCase() == parentCategory.toLowerCase() && $(this).attr('data-childCat').toLowerCase() == childCategory.toLowerCase())
                {
                    $(this).show();
                }
            })
        }
        
        if(selectedValue.length == 0)
        {
             $("#dvUseCaseContainer div.section-wrape").each(function(i){
                $(this).show();               
            })
        }
    }
}


    customerDashboard.init();
    
  }


       
}
