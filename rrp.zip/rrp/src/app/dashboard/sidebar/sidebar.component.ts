import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import {  RouterModule, Router, NavigationEnd , ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { serviceURL } from '../../serviceURL';

import { sidebarService } from '../../sidebar.service';

import { MessageService } from '../../services/intergatedservice.service';

import { OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import * as $ from "jquery";
declare var $: $
import * as echarts from 'echarts';
import * as moment from 'moment';
import { empty } from 'rxjs';

declare var Circles: any;
declare var multiselect: any;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
   providers : [
    serviceURL, sidebarService
  ]
})
export class SidebarComponent implements OnInit {


 
  title : string = "DASHBOARD";
  DeletionUseCase :   any;
  tagName : any = [];

  myCustomers: any = [];
  selected = null;  
  totalCustomer : number;
  hideElement = false;
  hideTotalCustomer = true;
  hideworkOrder : boolean = false;
  hideITSMTool : boolean;
  hideDateTime = false;
  hideOptions = false;
  customerID: any;
  today : string;
  Time : string;
  URLpath : any;
  ITSMTools : string = " ";
  ITSMToolDetails : any;
  customerlist;
  testService : any;
  ITSMIcons : boolean;
  DescriptionTitle : any;
  parentSRDes : any;

  message: any;
  subscription: Subscription;
  
 
  constructor (private messageService: MessageService,private httpService: HttpClient, private router: Router, public url : serviceURL,  private location: Location,  public sidebarnav: sidebarService , private activatedRoute: ActivatedRoute) {

    this.testService;
    
    this.subscription = this.messageService.getMessage().subscribe(message =>
        { this.message = message; });

  this.router.events.subscribe((event) => {
    if (event instanceof NavigationEnd) {

    this.URLpath = this.activatedRoute.snapshot.firstChild.url[0].path;
  
   
      if (  this.URLpath  === 'customers') {
        this.hideElement = true; 
      }  else {
        this.hideElement = false;
        $("#customerlist").prop('selected','false')
      } 

       if (this.URLpath  !== 'allcustomer') {
          this.hideTotalCustomer = true;
          this.hideDateTime = true;
        
      } 
       else {
              this.hideTotalCustomer = false;
              this.hideDateTime = false;
              this.hideOptions = false;
              this.title = "DASHBOARD"; 
           $('#customerlist option[value="0: undefined"]').prop("selected", true); 
      }
       
       if ( this.URLpath === 'usecases') {
            this.hideTotalCustomer = true;
            this.hideDateTime = true;
            this.hideOptions = true;
           
            this.title = "USE CASES"; 
            this.ITSMIcons = true;  
            $(document).find(".summit-logo").show();
            $(document).find(".serviceNow-logo").show();         
           $('#customerlist option[value="0: undefined"]').prop("selected", true); 
      }
      


       if ( this.URLpath === 'customerview') {                       
            this.hideOptions = false;
            this.ITSMIcons = true;
      }

      if(this.URLpath  === 'allcustomer'){
        this.ITSMIcons = true;   
        $(document).find(".summit-logo").show();
        $(document).find(".serviceNow-logo").show();    
      }

      
    }
  });

      
    this.today =  moment().format("MMM DD");      
    var update;

    (update = function() {
        $("#Time").html(moment().format('h:mm:ss a'));
    })();

    setInterval(update, 1000);
   
   // alert(this.activatedRoute.snapshot.firstChild.url[1].path);
 // $('#customerlist option[value="' + this.customerID + '"]').attr("selected","selected"); 

   }
   ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}


       __BindAAIInfo(id) { 
          
         if(id == "0: undefined"){
           id= 0
         }

        $.getJSON(this.url.prodURL + "GetCustomerWiseAAI/" + id, function(data) {

     if(data != null){
        $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
        $("#AAIRequssseCaseDev").html(data.InProgressCnt);    
     }else{
        $("#AAIRequssseCaseProd").html("...");
        $("#AAIRequssseCaseDev").html("...");    
     }

                 
            
        })

    };



    __GetCustomerDetails(){
   
     
    this.httpService.get( this.url.prodURL + 'GetCustomerDetails').subscribe(
      data => {
        this.myCustomers = data as any [];	// FILL THE ARRAY WITH DATA.
        this.totalCustomer = this.myCustomers.length;


       
        
        let URLID = this.activatedRoute.snapshot.firstChild.url[1].path;
        
        
           for(let i =0; i < this.myCustomers.length; i++){

            if(this.myCustomers[i].CustomerId == URLID){
              this.title = this.myCustomers[i].CustomerName ;
             
              $('.customer_title').html(this.title);            
             
            }
           
           }

           this.customerlist = +URLID;            
  
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );


    }


    __ITSMToolIntergation(customerID){

      
        
        $.getJSON(this.url.prodURL + 'GetCustomerDetails', function(data) {
            
            if(customerID  === "0: undefined"){
                $(document).find(".summit-logo").show();
                $(document).find(".serviceNow-logo").show();
                $(document).find("#workOrder").show();
                $(document).find('.workOrder').show();
            }
            else{
                for(let i=0; i < data.length; i++){


                    if(data[i].CustomerId === customerID ){                   
                    if(data[i].ITSmTool === "Summit"){
                        $(document).find(".summit-logo").show();
                        $(document).find(".serviceNow-logo").hide();
                        $(document).find("#workOrder").show();  
                        $(document).find('.workOrder').show();

                    }else if(data[i].ITSmTool === "ServiceNow"){
                        $(document).find(".summit-logo").hide();
                        $(document).find(".serviceNow-logo").show();
                        $(document).find("#workOrder").hide();  
                        $(document).find('.workOrder').hide();
                        
                    }
                    else{
                        $(document).find(".summit-logo").show();
                        $(document).find(".serviceNow-logo").show();
                    }
                    }
                
                }
            }     
        
   })
   

    }



    __getIntergatedSystem(customerID){

        this.httpService.get( this.url.prodURL + 'GetCustomerUseCaseWise/'+customerID).subscribe(
            data => {
    
                     let tagNameFlatten = [];
                     let flattenArray = [];
                     let result = [];                  
                     let myres = [];
                   
                     $("#tagNames").html("");
    
                
                    for (let key in data ){
                        tagNameFlatten = tagNameFlatten.concat(data[key]);                        
                        flattenArray.push(tagNameFlatten);
                    }
                  
                  for(let i =0; i < tagNameFlatten.length; i++){                     
                         if(tagNameFlatten[i] != undefined)
                         {
                            result = tagNameFlatten[i].Tags.split(',').map(function(item){
                                    return item.trim();
                            });
                            for (let key2 in result){
                                if(myres.indexOf(result[key2]) == -1){
                                    myres.push(result[key2]); 
                                }
                            }
                    }
    
                    } 
                   
                   

                   this.tagName = myres;
              
            },
            (err: HttpErrorResponse) => {
              console.log (err.message);
            }
          );
    }

    __getITSMTools(customerID){ 

          this.httpService.get(this.url.prodURL + 'GetCustomerDetails').subscribe(
            data => {
              
                this.ITSMToolDetails = data as any[];
                this.ITSMTools = this.ITSMToolDetails[customerID].ITSmTool;
           
            }


          ); 
    } 


    sideBarDetails(customeID){       
       
        var  url = this.url.prodURL;
        var customerDashboard = {
            defaults:{
                customerId:  customeID
            },
            init:function(){
                customerDashboard.bindIncidentUseCase();
                customerDashboard.bindMonthWiseTicketAnalysis();
                customerDashboard.bindUseCase();
                customerDashboard.bindAutomationStatistics();
            },
            bindIncidentUseCase: function() {     
        
                $.getJSON( url + "GetCustomerUseCaseDetails/" + customerDashboard.defaults.customerId, function(data) {
        
                    var useCaseCnt = 0;
                    var incidentCnt = 0;
                    var serviceReqCnt = 0;                   
                    var woReqCnt = 0;
                   
                 
                    if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
                    {
                        var filterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                       
                        if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                        {
                            
                            useCaseCnt += filterjson[0].Count;
                            incidentCnt = filterjson[0].Count;
                            $("#hincidentUseCaseProd").html(filterjson[0].Count);
                            $("#spnIncCnt").html(filterjson[0].Count);
                        }else{
                            $("#hincidentUseCaseProd").html("...");
                            $("#spnIncCnt").html("...");
                        }
                        var srfilterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                        if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                        {
                        
                            useCaseCnt += srfilterjson[0].Count;
                            serviceReqCnt = srfilterjson[0].Count;
                            $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                            $("#spnServiceReqCnt").html(srfilterjson[0].Count);
                        }else{
                            $("#hServiceRequseCaseProd").html("...");
                            $("#spnServiceReqCnt").html("...");
                        }


                        var wrfilterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Work Order'})
                        if(wrfilterjson != null && wrfilterjson != undefined &&wrfilterjson.length>0 )
                        {
                        
                            useCaseCnt += wrfilterjson[0].Count;
                            woReqCnt = wrfilterjson[0].Count;
                            $("#workOrderProd").html(wrfilterjson[0].Count);
                          //  $("#workOrderDev").html(wrfilterjson[0].Count);
                        }else{
                            $("#workOrderProd").html("...");
                          //  $("#workOrderDev").html("...");
                        }


                        var wrDevfilterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Work Order'})
                        if(wrDevfilterjson != null && wrDevfilterjson != undefined &&wrDevfilterjson.length>0 )
                        {
                        
                          
                          //  $("#workOrderProd").html(wrDevfilterjson[0].Count);
                       $("#workOrderDev").html(wrDevfilterjson[0].Count);
                        }else{
                       //     $("#workOrderProd").html("...");
                         $("#workOrderDev").html("0");
                        }
                        
                        var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100);
                        // argument error -- var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100,0);
                        
                        var myCircle = Circles.create({
                          id:                  'circles-1',
                          radius:              60,
                          value:               incSuccessRate,
                          maxValue:            100,
                          width:               2,
                          text:                function(value){return value + '%';},
                          colors:              ['#EBE9E9', '#E28811'],
                          duration:            400,
                          wrpClass:            'circles-wrp',
                          textClass:           'circles-text',
                          valueStrokeClass:    'circles-valueStroke',
                          maxValueStrokeClass: 'circles-maxValueStroke',
                          styleWrapper:        true,
                          styleText:           true
                        });
                        
                        var serviceReqSuccessRate = Math.round((serviceReqCnt / useCaseCnt) * 100);
                        // argument error --  Math.round((serviceReqCnt / useCaseCnt) * 100,0);
        
                        
                        var myCircle = Circles.create({
                          id:                  'circles-2',
                          radius:              60,
                          value:               serviceReqSuccessRate,
                          maxValue:            100,
                          width:               2,
                          text:                function(value){return value + '%';},
                          colors:              ['#EBE9E9', '#E28811'],
                          duration:            400,
                          wrpClass:            'circles-wrp',
                          textClass:           'circles-text',
                          valueStrokeClass:    'circles-valueStroke',
                          maxValueStrokeClass: 'circles-maxValueStroke',
                          styleWrapper:        true,
                          styleText:           true
                        });
                        
                        var workOrderSuccessRate = Math.round((woReqCnt / useCaseCnt) * 100);
                        var myCircle = Circles.create({
                            id:                  'circles-3',
                            radius:              60,
                            value:               workOrderSuccessRate,
                            maxValue:            100,
                            width:               2,
                            text:                function(value){return value + '%';},
                            colors:              ['#EBE9E9', '#E28811'],
                            duration:            400,
                            wrpClass:            'circles-wrp',
                            textClass:           'circles-text',
                            valueStrokeClass:    'circles-valueStroke',
                            maxValueStrokeClass: 'circles-maxValueStroke',
                            styleWrapper:        true,
                            styleText:           true
                          });
            
                                 
            
                        $("#spnautomationUSCnt").html(useCaseCnt);
                    }
        
                    if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined && data.UseCaseDevelopment.length != 0 )
                    {
                       
                        var filterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
        
                         if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                        {
                            $("#hincidentUseCaseDev").html(filterjson[0].Count);
                        }
                        
                        var srfilterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                        if(srfilterjson != null&& srfilterjson != undefined && srfilterjson.length>0)
                        {
                            $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                        }
                    }else{
                        $("#hincidentUseCaseDev").html("...");
                        $("#hServiceRequseCaseDev").html("...");
                    }
                  
                    if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined &&  data.UseCaseAnalysis.length != 0)
                    {
                         var filterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                         if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                        {
                            $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                        }
                        else{
                            $("#hIncidentUseCaseAna").html("...");
                          
                        }
                        
                        var srfilterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                        if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                        {
                            $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                        }
                        else{
                            $("#hServiceRequseCaseAnal").html("...");  
                        }
                    }
                    else{
                        $("#hIncidentUseCaseAna").html("...");
                        $("#hServiceRequseCaseAnal").html("...");
                    }
                    //self.customers(data);
                    
                })
            },
            bindMonthWiseTicketAnalysis: function(){
        
            var resultData;
        
           function getDetails() {
          
           var settings = {
            "async": true,
            "crossDomain": true,
            "url": url+ "GetCustomerMonthYrWiseTypeAnalysis/"+customerDashboard.defaults.customerId,
            "method": "GET",
           /* "headers": {
             "Authorization": "Basic ZWxhc3RpYzpwYXNzd29yZDEyMw==",
             }*/
            }
        
        
              // https://reportit.hexaware.com/reportitapiv2/Api/GetCustomerMonthYrWiseTicketAnalysis
             //  https://reportit.hexaware.com/reportitapiv2/Api/GetCustomerMonthYrWiseTypeAnalysis/2
        
        
         function myCallback(response){
        
                resultData = response;
                $.getJSON( url + "GetCustomerMonthYrWiseTicketAnalysis/" + customerDashboard.defaults.customerId, function(data) {
        
                   
                    if(data.length > 0 )
                    {
                    var htmlTabContent = "";
                    htmlTabContent += '<table class="table table-hover  table-striped mb-0">'
                    htmlTabContent += '<thead>'
                    htmlTabContent += '<tr cl>'
                    htmlTabContent += '<th scope="col" class="border-top-0">Month</th>'
                    htmlTabContent += '<th scope="col" class="border-top-0">Total Tickets</th>'
                    htmlTabContent += '<th scope="col" class="border-top-0">Automated Tickets</th>'
                    htmlTabContent+= '<th scope="col" class="border-top-0">Rejected Tickets</th>'
                    htmlTabContent+= '<th scope="col" class="border-top-0">Success Rate</th>'
                    htmlTabContent+= '<th scope="col" class="border-top-0">Rejected Rate</th>'
                    htmlTabContent+= '<th scope="col" class="border-top-0">More</th>'
                    htmlTabContent+= '</tr>'
                    htmlTabContent += '</thead>'
                    htmlTabContent+= '<tbody>'
        
        
                     
                    for(var i = 0 ; i< data.length;i++)
                    {
                        htmlTabContent+= '<tr>'
                        htmlTabContent+= '<td>'+data[i].Month+'</td>'
                        htmlTabContent+= '<td>'+data[i].Count+'</td>'
                        
                        htmlTabContent+= '<td>'+data[i].AutomatedTickets+'</td>'
        
                        htmlTabContent+= '<td>'+   data[i].RejectedTickets  + '</td>'
                        htmlTabContent+= '<td>'+Math.round(data[i].SuccessRate)+' %</td>'
                        // htmlTabContent+= '<td>'+Math.round(data[i].SuccessRate,4)+' %</td>'
                        htmlTabContent+= '<td>'+Math.round(data[i].RejectedRate)+' %</td>'
                        // htmlTabContent+= '<td>'+Math.round(data[i].RejectedRate,4)+' %</td>'
                        htmlTabContent+= '<td style="cursor:pointer" class="more-data"> <img src="assets/images/more.png" alt="more"> </td>'
                        htmlTabContent+= '</tr>'
        
        
            htmlTabContent+= '<tr style="display:none" class="child-table"> <td colspan="7" class="p-0">'
            htmlTabContent+= '<table class="table m-0 p-0 table-hover table-striped"><thead class="bg-white">'
             htmlTabContent+= '<tr> <th> Type </th> <th> Total Tickets </th>  <th> Automated Tickets </th>  <th>Rejected Tickets </th> <th>'
             htmlTabContent+= ' Success Rate  </th>  <th> Failure Rate </th> </tr>'
             htmlTabContent+= '</thead><tbody>'
    // Incident
        if(resultData.Incident != undefined ){
            htmlTabContent+= '<tr class="table-incident">'
            htmlTabContent+=  '<td width="20.0%"> Incidents </td>' 
             htmlTabContent+=  '<td>' + resultData.Incident[i].Count + '</td>' 
              htmlTabContent+=  '<td>' + resultData.Incident[i].AutomatedTickets + '</td>'
              htmlTabContent+=  '<td>' +  resultData.Incident[i].RejectedTickets + '</td>'  
               htmlTabContent+=  '<td>' + Math.round(resultData.Incident[i].SuccessRate) + '%</td>'                    
                 htmlTabContent+=  '<td>' + Math.round(resultData.Incident[i].RejectedRate) + '%</td>' 
            htmlTabContent+= '</tr>'

        }
             
      
             if(resultData.ServiceRequest != undefined ){ 
             // ServiceRequest
             htmlTabContent+= '<tr class="table-servicereq">'
             htmlTabContent+=  '<td> Service Requests </td>' 
               htmlTabContent+=  '<td>' + resultData.ServiceRequest[i].Count + '</td>' 
                 htmlTabContent+=  '<td>' + resultData.ServiceRequest[i].AutomatedTickets + '</td>'                   
                     htmlTabContent+=  '<td>' +  resultData.ServiceRequest[i].RejectedTickets + '</td>' 
                     htmlTabContent+=  '<td>' + Math.round(resultData.ServiceRequest[i].SuccessRate) + '%</td>' 
                       htmlTabContent+=  '<td>' + Math.round(resultData.ServiceRequest[i].RejectedRate) + '%</td>' 
             htmlTabContent+= '</tr>'  
             }
             
             if(resultData.WorkOrder != undefined ){ 
                // WorkOrder
                htmlTabContent+= '<tr class="table-workorder">'
                htmlTabContent+=  '<td> Work Order </td>' 
                  htmlTabContent+=  '<td>' + resultData.WorkOrder[i].Count + '</td>' 
                    htmlTabContent+=  '<td>' + resultData.WorkOrder[i].AutomatedTickets + '</td>'                   
                        htmlTabContent+=  '<td>' +  resultData.WorkOrder[i].RejectedTickets + '</td>' 
                        htmlTabContent+=  '<td>' + Math.round(resultData.WorkOrder[i].SuccessRate) + '%</td>' 
                          htmlTabContent+=  '<td>' + Math.round(resultData.WorkOrder[i].RejectedRate) + '%</td>' 
                htmlTabContent+= '</tr>'  
                } 
 
        
             htmlTabContent += '<tbody></table></td></tr>'  
        
                    }
                    
                                           
                    htmlTabContent+= '</tbody>'
                    htmlTabContent+= '</table>'
                    
                    $("#dvCustomerMonthTktAna").html(htmlTabContent);
                }
                })
                 
         };
        
         $.ajax(settings).done(myCallback);
            
        }
        
        getDetails();
        
        },
            find_in_object: function (my_object, my_criteria) {
                return my_object.filter(function (obj) {
                    return Object.keys(my_criteria).every(function (c) {
                        return obj[c] == my_criteria[c];
                    });
                });
            },
            bindUseCase: function()
            {

                
                $.getJSON( url + "GetCustomerUseCaseWise/" + customerDashboard.defaults.customerId, function(data) {

          
                    
            let SRINCArray = data.SRINC;
            let PRSROSEmptyArray = data.PRSRISEmpty;
            let SRINC_PRSROSArray;

            if( PRSROSEmptyArray === undefined ){
                PRSROSEmptyArray = [];
            }else if(SRINCArray === undefined){
                SRINCArray = []
            }
            
            SRINC_PRSROSArray =  PRSROSEmptyArray.concat(SRINCArray);

            data = SRINC_PRSROSArray;
                   
                    var useCaseTemplate = $("#dvUseCaseTemplate").html();
                    $("#dvUseCaseContainer").html('');
                     var category = []
                    for(var i = 0;i<data.length;i++)
                    {
                     // $("#dvUseCaseContainer").append(useCaseTemplate.replace(/{index}/g,i) ) 
                      
                      $("#dvUseCaseContainer").append(useCaseTemplate.replace(/{index}/g,i) );
        
                       // $("#dvUseCaseContainer").append(useCaseTemplate) 
                        
                        if($.inArray(data[i].ParentCategory+' ('+data[i].ChildCategory+')',category) == -1)
                        {
                            category.push(data[i].ParentCategory+' ('+data[i].ChildCategory+')');
                        }
        
        
                        
                        var tags = "";
                        if(data[i].Tags != null)
                        {
                          var tagArray = data[i].Tags.split(',');
                          for(var j = 0;j< tagArray.length;j++)
                          {
                              tags += '<span class="d-inline"> <span class="badge badge-secondary" style="background: rgba(164, 180, 196, 1); color: #fff;  font-size: .8rem;border-radius: 40px;    padding: 3px 8px;font-weight: 500;">';
                           //   tags += '<img src="assets/images/incident_icn.svg" alt="" class="img-fluid" width="20px">'
                              tags += ''+tagArray[j]+'</span></span>'
                          }
                          $("#dvUseCaseTags_"+i).html(tags);
                        }
        
                        var reqTags = data[i].RequestType;
                         
                         $("#RequestType_"+i+ " span").addClass(reqTags);

                    
        
                         if(  customerDashboard.defaults.customerId !== 0){
                            $("#customername_"+i ).hide(); 
                            $(".badge-customer__name").hide();
                        }
                        else{

                            $("#customername_"+i ).html(data[i].CustomerName);
                            
                        }
                       
                          
                         switch(reqTags){

                            case  "Service Request" :
                                 $("#RequestTypeIcon_"+i+ " span").html("SR");
                                 $("#RequestTypeIcon_"+i+ " span").addClass("SR");
                             break;
                           case "Incident" :
                                 $("#RequestTypeIcon_"+i+ " span").html("INC");
                                 $("#RequestTypeIcon_"+i+ " span").addClass("INC");
                                 break;
                                 case "Work Order" :
         
                                 $("#RequestTypeIcon_"+i+ " span").html("WO");
                                 $("#RequestTypeIcon_"+i+ " span").addClass("WO"); 
                                 break;
         
                                 default :
                                 $("#RequestTypeIcon_"+i+ " span").html("O");
                                 $("#RequestTypeIcon_"+i+ " span").addClass("O");
         
                                 break;
         
                          }
                         $("#RequestType_"+i+ " span").html(reqTags);
        
                         
                            $("#totalCount_"+i).html(data[i].Count);
                          
                         
                          
                        
                        
                        $("#dvUseCase_"+i).attr('data-parentCat',data[i].ParentCategory);
                        $("#dvUseCase_"+i).attr('data-childCat',data[i].ChildCategory);
                         $("#dvUseCase_"+i).attr('data-requestType',data[i].RequestType);
                        
                        $("#spnUseCaseName_"+i).html(data[i].UseCaseName);
                        $("#hUseCaseDescription_"+i).html(data[i].Description);
                        $("#hUseCaseManualMTTR_"+i).html(Math.round(data[i].ManualMTTR),0);
                     
                        
        
                      
        
                        // var successRatePer = Math.round(data[i].SuccessRate,0); // bind one arg
                        var successRatePer = Math.round(data[i].SuccessRate);
                        var colour = 'white'
                        //debugger;
                        if(successRatePer >= 0 && successRatePer <= 50)
                        {
                            $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                            $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                            $("#dvSuccessRateContainer-"+i).addClass("bg-red");
                            colour = '#f7bf44'
                        }
                        else if(successRatePer > 50 && successRatePer < 80)
                            {
                                $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                                $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                                $("#dvSuccessRateContainer-"+i).addClass("bg-orange");
        
                                colour = '#ff9e6d'
                            }
                        else
                            {
                                $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                                $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                                $("#dvSuccessRateContainer-"+i).addClass("bg-green");
                                colour = '#56e6c3'
                            }
        
                          
                            $('#circles-successrate-'+i).html(successRatePer + "%");   
        
                            var effReducedPer;
        
                            if( successRatePer === 0){
                                effReducedPer = 0;
                                $("#hUseCaseAutoMTTR_"+i).html("0");
        
                            }
                            else{
                                effReducedPer  = 100 - ((data[i].AutomationMTTR * 100) / data[i].ManualMTTR);
                                $("#hUseCaseAutoMTTR_"+i).html(Math.round(data[i].AutomationMTTR),0);
                            }
                        
                         
        
                        
                        
        
                         var myCircle = Circles.create({
                          id:                  'circles-effreduced-'+i,
                          radius:              40,
                          value:               Math.round(effReducedPer),  // bind one arg    Math.round(effReducedPer,0)
                          maxValue:            100,
                          width:               2,
                          text:                function(value){return value + '%';},
                          colors:              ['', '#56e6c3'],
                          duration:            0,
                          wrpClass:            'circles-wrp',
                          textClass:           'circles-text',
                          valueStrokeClass:    'circles-valueStroke',
                          maxValueStrokeClass: 'circles-maxValueStroke',
                          styleWrapper:        true,
                          styleText:           true
                        });
        
                    }
                    
                    customerDashboard.BuildCategoryMultiselect(category)
                })
            },
            bindAutomationStatistics: function(){
                
                $.getJSON( url + "GetCustomerMonthYrWiseTicketAnalysis/" + customerDashboard.defaults.customerId, function(data) {
                    
                    var monthArry = [];
                    var automationTkts = [];
                    var rejectedTkts = [];
                
                   for(var i = 0;i<data.length;i++)
                    {
                        monthArry.push(data[i].Month);
                        automationTkts.push(data[i].AutomatedTickets);
                        rejectedTkts.push(data[i].RejectedTickets);
                    }
                    
                    var dom = document.getElementById("container");
                var myChart = echarts.init(dom,'light');
                var app = {};
                var option = null;
                option = {    
                    tooltip : {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'cross',
                            label: {
                                backgroundColor: '#6a7985'
                            }
                        }
                    },
                    legend: {
                        data:['Automated Ticket','Rejected Ticket']
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis : [
                        {
                            type : 'category',
                            boundaryGap : false,
                            data : monthArry
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value'
                        }
                    ],
                    series : [
                        {
                            name:'Automated Ticket',
                            type:'line',
                            //smooth:true,
                            areaStyle: {normal: {}},
                            data:automationTkts
                        },
                        {
                            name:'Rejected Ticket',
                            type:'line',
                            //smooth:true,
                            areaStyle: {normal: {}},
                            data:rejectedTkts
                        }
        
                    ]
                };
                ;
                if (option && typeof option === "object") {
                    myChart.setOption(option, true);
                }
                })
                
                
            },
            BuildCategoryMultiselect: function(category)
            {
                var content = ""
                content += '<optgroup label="All">';
                for(var i=0; i < category.length;i++)
                {
                    content += '<option selected="true"  value="'+category[i]+'">'+category[i]+'</option>';
                }
                 content += '</optgroup>';
        
                $("#option-droup-demo").html(content);
                $("#option-droup-demo").multiselect('rebuild');
        
              
            },
            filterByCategory: function(option,checked)
            {
                
                var selectedValue = $('select#option-droup-demo').val();
                
                $("#dvUseCaseContainer div.section-wrape").each(function(i){
                    $(this).hide();               
                })
                
                for(var i = 0;i< selectedValue.length;i++)
                {
                    //debugger
                    var parentCategory = selectedValue[i].split(' (')[0]
                    var childCategory = selectedValue[i].split(' (')[1].replace(')','')
                    
                      $("#dvUseCaseContainer div.section-wrape").each(function(i){
                      
                        if($(this).attr('data-parentCat').toLowerCase() == parentCategory.toLowerCase() && $(this).attr('data-childCat').toLowerCase() == childCategory.toLowerCase())
                        {
                            $(this).show();
                        }
                    })
                }
                
                if(selectedValue.length == 0)
                {
                     $("#dvUseCaseContainer div.section-wrape").each(function(i){
                        $(this).show();               
                    })
                }
            }
        }
        
        
         customerDashboard.init();
        
    }


 ngOnInit () {

    var  url = this.url.prodURL;
   
      this.__GetCustomerDetails();
      this.__BindAAIInfo(0);
     

      if (this.URLpath  == 'customerview') {        
        this.customerID = this.activatedRoute.snapshot.firstChild.url[1].path
      } 
      else{
        this.customerID = 0
      }

   
      this.__getITSMTools(this.customerID);
      this.sideBarDetails(this.customerID);
      this.__ITSMToolIntergation(this.customerID);
      this.__getIntergatedSystem(this.customerID)

        $(function(){
        $(document).on('click','.more-data',function(){
                        $(this).parent().next().toggle();


         /*        var html = "";
              alert(url);

                $.getJSON( url + "GetCustomerMonthYrWiseTicketAnalysis/" + this.customerID, function(data) {
                    alert(data);

                    html += "<td>" + data.ServiceRequest.Count + "</td>"



                    $(this).parent().next().html(html);
                });
 */
                       
                })
        })
   
  
  }


 
    onChange(e) {

        let totalCount : any; 
        var id : string;
       
       if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1){
        this.customerID = e ;
        id  = e;
       }
       else{
        this.customerID = (event.target as HTMLInputElement).value ;
        id  = (event.target as HTMLInputElement).value;
       }

         this.router.navigate(['/dashboard/customerview/'+this.customerID ]);

         this.title = $("#customerlist option:selected").html(); 
                         
         $(".customer_title").html(this.title);

         if(  (this.title).toUpperCase() === "All Customers"){
           this.title = "Dashboard"
         }

         if( this.customerID  === "0: undefined" || this.customerID === undefined ){

             this.customerID = 0;
             this.router.navigate(['/dashboard/allcustomer']);
         }
      
        $.getJSON(this.url.prodURL + 'GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;
             $("#automated_Tkt_count").html(totalCount);
             
        })
     
      this.__ITSMToolIntergation(id);
      this.__BindAAIInfo(this.customerID);
      this.sideBarDetails(this.customerID );
      this.__getITSMTools(this.customerID);
      this.__getIntergatedSystem(this.customerID)




      this.httpService.get( this.url.prodURL + 'GetCustomerUseCaseWise/'+this.customerID).subscribe(
        data => {

                /*   var tagNameFlatten = [];
                 var flattenArray = [];
                 var result = [];
                 var c = [];
                 var myres = [];
               
                 $("#tagNames").html("");

           
                for (var key in data ){
                    tagNameFlatten = tagNameFlatten.concat(data[key]);
                    flattenArray.push(tagNameFlatten);
                }


              
              for(let i =0; i <= tagNameFlatten.length; i++){                     
                    result = tagNameFlatten[i].Tags.split(',');
                    for (var key2 in result ){
                        if(myres.indexOf(result[key2]) == -1){
                              myres.push(result[key2]);
                              $("#tagNames").append( '<h4 style="display:inline-block;margin-right:5px;"><span class="badge badge-secondary badge-ouline" style="background: none;border: 2px solid #3dbfa0;border-radius: 30px;color: #3dbfa0;font-size: 59%;font-weight: 600;padding-right: 12px;padding-left: 12px;" >' + result[key2] +'</span></h4>')
                        }
                       
                         // $("#tagNames").append( '<h4 style="display:inline-block;margin-right:5px;"><span class="badge badge-secondary badge-ouline" style="background: none;border: 2px solid #3dbfa0;border-radius: 30px;color: #3dbfa0;font-size: 59%;font-weight: 600;padding-right: 12px;padding-left: 12px;" >' + result[key2] +'</span></h4>')
                    }


                } 
 */
                   
           

this.DeletionUseCase = Object.values(data)[0];                    
this.DescriptionTitle  = Object.keys(data)[0];
this.parentSRDes = Object.values(data)[0][0].ParentSRDescription;



let tagNameFlatten = [];
let flattenArray = [];
let result = [];                  
let myres = [];



for (let key in data ){
   tagNameFlatten = tagNameFlatten.concat(data[0]);                        
   flattenArray.push(tagNameFlatten);
}

for(let i =0; i < tagNameFlatten.length; i++){                     
    if(tagNameFlatten[i] != undefined)
    {
       result = tagNameFlatten[i].Tags.split(',');
   
       myres.push(result);

        
   }

} 

            
            for(let i=0; i < Object.keys(data).length; i++){  
               
                if(Object.keys(data)[0] === "SRINC"){
                   $(document).find('#usecasePc').hide();
                }
                else if(Object.keys(data)[2] === "PRSRISEmpty"){
                    $(document).find('#usecasePc').hide();
                }else{
                   $(document).find('#usecasePc').show();
                }
        }       
        },
        (err: HttpErrorResponse) => {
          console.log (err.message);
        }
      );    

  }

}
