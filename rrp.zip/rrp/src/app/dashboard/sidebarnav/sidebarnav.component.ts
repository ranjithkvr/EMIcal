import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import {  RouterModule, Router, NavigationEnd , NavigationStart, ActivatedRoute, Params } from '@angular/router';
import { serviceURL } from '../../serviceURL';

import { sidebarService } from '../../sidebar.service';

import * as moment from 'moment';
import * as $ from "jquery";


import { MessageService } from '../../services/intergatedservice.service';

declare var $: $
import * as echarts from 'echarts';

import { empty } from 'rxjs';

declare var Circles: any;
declare var multiselect: any;

@Component({
  selector: 'app-sidebarnav',
  templateUrl: './sidebarnav.component.html',
  styleUrls: ['./sidebarnav.component.scss']  , providers : [
     sidebarService
  ]
})
export class SidebarnavComponent implements OnInit {

path: any;

  constructor (private messageService: MessageService, private httpService: HttpClient, private router: Router, public url : serviceURL,  public sidebarnav: sidebarService , private activatedRoute: ActivatedRoute){ 

       this.activatedRoute.snapshot.firstChild.url[0].path;
    
  }

  ngOnInit() {   
  }



  __BindAAIInfo(id) { 
          
    if(id == "0: undefined"){
      id= 0
    }

   $.getJSON(this.url.prodURL + "GetCustomerWiseAAI/" + id, function(data) {

if(data != null){
   $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
   $("#AAIRequssseCaseDev").html(data.InProgressCnt);    
}else{
   $("#AAIRequssseCaseProd").html("...");
   $("#AAIRequssseCaseDev").html("...");    
}

            
       
   })

};


  serviceBar(){
        
    this.__BindAAIInfo(0);


    this.messageService.sendMessage('Message from sidebarnav Component to sidebar Component!');




    var customeList = $(document).find('#customerlist option');
  
   $.each(customeList, function(i, val){

            $(this).removeAttr('selected')
    });
    
    var  url = this.url.prodURL;

    var customerDashboard = {

        defaults:{
            customerId:  0
        },
        init:function(){
            customerDashboard.bindIncidentUseCase();
        /*     customerDashboard.bindMonthWiseTicketAnalysis();
            customerDashboard.bindUseCase();
            customerDashboard.bindAutomationStatistics(); */
        },
        bindIncidentUseCase: function() {     
    
            $.getJSON( url + "GetCustomerUseCaseDetails/" + customerDashboard.defaults.customerId, function(data) {
    
                var useCaseCnt = 0;
                var incidentCnt = 0;
                var serviceReqCnt = 0;
               
             
                if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
                {
                    var filterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                   
                    if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                    {
                        
                        useCaseCnt += filterjson[0].Count;
                        incidentCnt = filterjson[0].Count;
                        $("#hincidentUseCaseProd").html(filterjson[0].Count);
                        $("#spnIncCnt").html(filterjson[0].Count);
                    }else{
                        $("#hincidentUseCaseProd").html("...");
                        $("#spnIncCnt").html("...");
                    }
                    var srfilterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                    if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                    {
                    
                        useCaseCnt += srfilterjson[0].Count;
                        serviceReqCnt = srfilterjson[0].Count;
                        $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                        $("#spnServiceReqCnt").html(srfilterjson[0].Count);
                    }else{
                        $("#hServiceRequseCaseProd").html("...");
                        $("#spnServiceReqCnt").html("...");
                    }
                    
                    var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100);
                    // argument error -- var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100,0);
                    
                    var myCircle = Circles.create({
                      id:                  'circles-1',
                      radius:              60,
                      value:               incSuccessRate,
                      maxValue:            100,
                      width:               2,
                      text:                function(value){return value + '%';},
                      colors:              ['#EBE9E9', '#E28811'],
                      duration:            400,
                      wrpClass:            'circles-wrp',
                      textClass:           'circles-text',
                      valueStrokeClass:    'circles-valueStroke',
                      maxValueStrokeClass: 'circles-maxValueStroke',
                      styleWrapper:        true,
                      styleText:           true
                    });
                    
                    var serviceReqSuccessRate = Math.round((serviceReqCnt / useCaseCnt) * 100);
                    // argument error --  Math.round((serviceReqCnt / useCaseCnt) * 100,0);
    
                    
                    var myCircle = Circles.create({
                      id:                  'circles-2',
                      radius:              60,
                      value:               serviceReqSuccessRate,
                      maxValue:            100,
                      width:               2,
                      text:                function(value){return value + '%';},
                      colors:              ['#EBE9E9', '#E28811'],
                      duration:            400,
                      wrpClass:            'circles-wrp',
                      textClass:           'circles-text',
                      valueStrokeClass:    'circles-valueStroke',
                      maxValueStrokeClass: 'circles-maxValueStroke',
                      styleWrapper:        true,
                      styleText:           true
                    });
                    
                    $("#spnautomationUSCnt").html(useCaseCnt);
                }
    
                if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined && data.UseCaseDevelopment.length != 0 )
                {
                   
                    var filterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
    
                     if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                    {
                        $("#hincidentUseCaseDev").html(filterjson[0].Count);
                    }
                    
                    var srfilterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                    if(srfilterjson != null&& srfilterjson != undefined && srfilterjson.length>0)
                    {
                        $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                    }
                }else{
                    $("#hincidentUseCaseDev").html("...");
                    $("#hServiceRequseCaseDev").html("...");
                }
              
                if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined &&  data.UseCaseAnalysis.length != 0)
                {
                     var filterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                     if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                    {
                        $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                    }
                    else{
                        $("#hIncidentUseCaseAna").html("...");
                      
                    }
                    
                    var srfilterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                    if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                    {
                        $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                    }
                    else{
                        $("#hServiceRequseCaseAnal").html("...");  
                    }
                }
                else{
                    $("#hIncidentUseCaseAna").html("...");
                    $("#hServiceRequseCaseAnal").html("...");
                }
                //self.customers(data);
                
            })
        },
  
        find_in_object: function (my_object, my_criteria) {
            return my_object.filter(function (obj) {
                return Object.keys(my_criteria).every(function (c) {
                    return obj[c] == my_criteria[c];
                });
            });
        }
    }
    
    
     customerDashboard.init();
    

    
  }


}
