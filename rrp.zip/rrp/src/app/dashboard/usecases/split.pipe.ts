import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'splitStr'})
export class SplitStr implements PipeTransform {

  transform(value: any): string {
    let newStr: any = value.split(',');
    let final : any = [];
      for(var i = 0; i < newStr.length; i++)
            {
                final.push(newStr[i].split(','))
            }
   
    return final;
  } 
}