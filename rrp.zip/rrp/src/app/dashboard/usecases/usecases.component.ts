import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Router, ActivatedRoute, Params, NavigationEnd, RouterModule } from '@angular/router';
import { Location } from '@angular/common';
import { serviceURL } from '../../serviceURL';
import {NgbDropdownConfig} from '@ng-bootstrap/ng-bootstrap';
import { Title } from '@angular/platform-browser';
import { SplitStr } from './split.pipe';


import { MessageService } from '../../services/intergatedservice.service';



import * as $ from "jquery";
declare var $: $
import * as echarts from 'echarts';
import { empty } from 'rxjs';

declare var Circles: any;
declare var multiselect: any;


@Component({
  selector: 'app-usecases',
  templateUrl: './usecases.component.html', 
  styleUrls: ['./usecases.component.scss'],
   providers : [
    serviceURL
  ]
})
export class UsecasesComponent implements OnInit { 
    
    customerID: any;
    isChecked : boolean = true;
    ID : any;
    DeletionUseCase :   any;
    URLpath : any;
    DescriptionTitle : any;
    parentSRDes : any;
    tagName : any;
    DDValue : any;
    customerName : boolean = true;
    tagmyName : any = [];
    successColor : string;
    inDevelopmentUseCase : any;

  

    requestType =
     [
    {
      RequestType : "Service Request"
    },

    {
      RequestType : "Incident"
    }

    ];

  

    constructor(private messageService: MessageService, private router : Router, private httpService: HttpClient,  private activatedRoute: ActivatedRoute,  private location: Location,  public url : serviceURL, config: NgbDropdownConfig,  public titleService : Title) {

      
          this.customerID = (this.activatedRoute.snapshot.params).id;
          this.customerID == undefined ?  this.customerID = 0 : 
          this.customerID = (this.activatedRoute.snapshot.params).id;
      
            config.placement = 'bottom-left';
            config.autoClose = 'outside';
         
           let totalCount : any; 


      

        $.getJSON(this.url.prodURL + 'GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;
             $("#automated_Tkt_count").html(totalCount);
        })

       
      

       }


    
 
    clearMessage(): void {
        // clear message
        this.messageService.clearMessage();
    }
       __BindAAIInfo() {       
     
        $.getJSON(this.url.prodURL + "GetCustomerWiseAAI/" + this.customerID, function(data) {
               
         
                    $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
                    $("#AAIRequssseCaseDev").html(data.InProgressCnt); 
                
           
                      
          
        })

       
    };



   

 typeHideShow(isChecked: boolean, RequestType: string){

           if(isChecked) {

           alert(RequestType);
                 
      } else {
         alert(RequestType);
      }

 } 

        usecasePc : boolean = false;


__DeletionUseCase() {

    this.httpService.get( this.url.prodURL + 'GetCustomerUseCaseWise/'+this.customerID).subscribe(
        data => {
            
          
            delete data["PRSRISEmpty"];
            delete data["SRINC"];

            this.DeletionUseCase = Object.values(data)[0];                  
            this.DescriptionTitle  = Object.keys(data)[0];
            this.parentSRDes = Object.values(data)[0][0].ParentSRDescription;

            this.tagmyName = Object.values(data)[0][0].Tags;

          /* 
            this.successColor = Object.values(data)[0][0].SuccessRate;
            console.log( this.successColor); */

            if(this.customerID !== 0){
             this.customerName =  true
             
            }
            else{ 
              this.customerName =  false               
            }
        });
}


__inDevelopment(){

    this.httpService.get( this.url.prodURL + 'GetCustomerUseCaseWiseInProgress/'+this.customerID).subscribe(
        data => {             

            this.inDevelopmentUseCase = data["SRINC"];                    
                   
            
            if(this.customerID !== 0){
                this.customerName =  true
                
               }
               else{ 
                 this.customerName =  false               
               }

        });

}


  ngOnInit() {
    
    this.httpService.get( this.url.prodURL + 'GetCustomerUseCaseWise/'+this.customerID).subscribe(
        data => {


          
        
          this.__DeletionUseCase();
          this.__inDevelopment();
           

            let tagNameFlatten = [];
            let flattenArray = [];
            let result = [];                  
            let myres = [];
          
       
       
           for (let key in data ){
               tagNameFlatten = tagNameFlatten.concat(data[0]);                        
               flattenArray.push(tagNameFlatten);
           }
         
         for(let i =0; i < tagNameFlatten.length; i++){                     
                if(tagNameFlatten[i] != undefined)
                {
                   result = tagNameFlatten[i].Tags.split(',');               
                   myres.push(result);                    
               }
           } 
          
          
           //console.log( this.tagName = myres)
        
            
            for(let i=0; i < Object.keys(data).length; i++){  
               
                if(Object.keys(data)[0] === "SRINC"){
                   $(document).find('#usecasePc').hide();
                }
                else if(Object.keys(data)[2] === "PRSRISEmpty"){
                    $(document).find('#usecasePc').hide();
                }else{
                   $(document).find('#usecasePc').show();
                }
        }       
        },
        (err: HttpErrorResponse) => {
          console.log (err.message);
        }
      );  

// var httpService =  this.httpService;
  this.titleService.setTitle("Report IT- Dashboard - Use cases");

   $('#type-option').multiselect({
    enableClickableOptGroups: true,
    includeSelectAllOption: true,
    nonSelectedText: 'Select Type', 
    disableIfEmpty: true,
    selectAllText: 'All',
    onChange : function(option, checked, select) {
     
      var val = $(option).val();
        
          if(checked == false && val == 'Service Request'){
            $("#dvUseCaseContainer div[data-requesttype='Service Request']").fadeOut(500);
           
           // $("#dropdownConfig").text("Type"); 
          }
          else if(checked == false && val == 'Incident'){   
             $("#dvUseCaseContainer div[data-requesttype='Incident']").fadeOut(500);
              
          }else if(checked == false && val == 'Work Order'){   
            $("#dvUseCaseContainer div[data-requesttype='Work Order']").fadeOut(500);
             
         }
          
          if(checked == true && val == 'Service Request'){
            $("#dvUseCaseContainer div[data-requesttype='Service Request']").fadeIn(500);
          }
          else if(checked == true && val == 'Incident'){   
             $("#dvUseCaseContainer div[data-requesttype='Incident']").fadeIn(500);
          }
          else if(checked == true && val == 'Work Order'){   
             $("#dvUseCaseContainer div[data-requesttype='Work Order']").fadeIn(500);
          }
          
    },
    onSelectAll: function() {
        $("#dvUseCaseContainer div[data-requesttype='Service Request']").fadeIn(500);
        $("#dvUseCaseContainer div[data-requesttype='Incident']").fadeIn(500);
        $("#dvUseCaseContainer div[data-requesttype='Work Order']").fadeIn(500);
    },
    onDeselectAll: function() {
        $("#dvUseCaseContainer div[data-requesttype='Service Request']").fadeOut(500);
        $("#dvUseCaseContainer div[data-requesttype='Incident']").fadeOut(500);
        $("#dvUseCaseContainer div[data-requesttype='Work Order']").fadeOut(500);
    }

}); 



  

       $('#option-droup-demo').multiselect({
            enableClickableOptGroups: true,
            nonSelectedText: 'Select Category',
            disableIfEmpty: true,
            onChange : function(option, checked) {
                   useCase.filterByCategory(option, checked)
            },

        }); 


 
     var  url = this.url.prodURL;

        

              var useCase = {
					    defaults:{                              
                             customerId :  this.customerID                                      
					    },
					    init:function(){

					          
                                  useCase.bindUseCase();
                                  useCase.bindUseCaseDeletion();
					    },
					    find_in_object: function (my_object, my_criteria) {
					        return my_object.filter(function (obj) {
					            return Object.keys(my_criteria).every(function (c) {
					                return obj[c] == my_criteria[c];
					            });
					        });
					    },
        
                       bindUseCase : function() {
                          
        $.getJSON( url +"GetCustomerUseCaseWise/" + useCase.defaults.customerId, function(data) {
      
            
            let SRINCArray = data.SRINC;
            let PRSROSEmptyArray = data.PRSRISEmpty;
            let SRINC_PRSROSArray;



            if( PRSROSEmptyArray === undefined ){
                PRSROSEmptyArray = [];
            }else if(SRINCArray === undefined){
                SRINCArray = []
            }
            
            SRINC_PRSROSArray =  PRSROSEmptyArray.concat(SRINCArray);

            data = SRINC_PRSROSArray;
           
           
            var useCaseTemplate = $("#dvUseCaseTemplate").html();
            $("#dvUseCaseContainer").html('');
             var category = []
            for(var i = 0;i<data.length;i++)
            {       
              
              $("#dvUseCaseContainer").append(useCaseTemplate.replace(/{index}/g,i) );            
                
                if($.inArray(data[i].ParentCategory+' ('+data[i].ChildCategory+')',category) == -1)
                {
                    category.push(data[i].ParentCategory+' ('+data[i].ChildCategory+')');
                }


                
                var tags = "";
                if(data[i].Tags != null)
                {
                  var tagArray = data[i].Tags.split(',');
                  for(var j = 0;j< tagArray.length;j++)
                  {
                      tags += '<span class="d-inline"> <span class="badge badge-secondary" style="background: rgba(164, 180, 196, 1); color: #fff;  font-size: .8rem;border-radius: 40px;    padding: 3px 8px;font-weight: 500;">';
                   // tags += '<img src="assets/images/incident_icn.svg" alt="" class="img-fluid" width="20px">'
                      tags += ''+tagArray[j]+'</span></span>'
                  }
                  $("#dvUseCaseTags_"+i).html(tags);
                }

                var reqTags = data[i].RequestType;
                 
                $("#RequestType_"+i+ " span").addClass(reqTags);
         
                if(  useCase.defaults.customerId !== 0){
                    $("#customername_"+i ).hide(); 
                    $(".badge-customer__name").hide();
                }
                else{

                    $("#customername_"+i ).html(data[i].CustomerName);
                    
                }
               
               

                 switch(reqTags){

                   case  "Service Request" :
                        $("#RequestTypeIcon_"+i+ " span").html("SR");
                        $("#RequestTypeIcon_"+i+ " span").addClass("SR");
                    break;
                  case "Incident" :
                        $("#RequestTypeIcon_"+i+ " span").html("INC");
                        $("#RequestTypeIcon_"+i+ " span").addClass("INC");
                        break;
                        case "Work Order" :

                        $("#RequestTypeIcon_"+i+ " span").html("WO");
                        $("#RequestTypeIcon_"+i+ " span").addClass("WO"); 
                        break;

                        default :
                        $("#RequestTypeIcon_"+i+ " span").html("O");
                        $("#RequestTypeIcon_"+i+ " span").addClass("O");

                        break;

                 }
                

                 $("#RequestType_"+i+ " span").html(reqTags);

                 
                    $("#totalCount_"+i).html(data[i].Count);
                  
                 
                  
                
                
                $("#dvUseCase_"+i).attr('data-parentCat',data[i].ParentCategory);
                $("#dvUseCase_"+i).attr('data-childCat',data[i].ChildCategory);
                 $("#dvUseCase_"+i).attr('data-requestType',data[i].RequestType);
                
                $("#spnUseCaseName_"+i).html(data[i].UseCaseName);
                $("#hUseCaseDescription_"+i).html(data[i].Description);
                $("#hUseCaseManualMTTR_"+i).html(Math.round(data[i].ManualMTTR),0);
             
                

              

                // var successRatePer = Math.round(data[i].SuccessRate,0); // bind one arg
                var successRatePer = Math.round(data[i].SuccessRate);
                var colour = 'white'
                //debugger;
                if(successRatePer >= 0 && successRatePer  <= 50)
                {
                    $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                    $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                    $("#dvSuccessRateContainer-"+i).addClass("bg-red");
                    colour = '#f7bf44'
                }
                else if(successRatePer > 50 && successRatePer < 80)
                    {
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                        $("#dvSuccessRateContainer-"+i).addClass("bg-orange");

                        colour = '#ff9e6d'
                    }
                else
                    {
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                        $("#dvSuccessRateContainer-"+i).addClass("bg-green");
                        colour = '#56e6c3'
                    }

                  
                    $('#circles-successrate-'+i).html(successRatePer + "%");   

                    var effReducedPer;

                    if( successRatePer === 0){
                        effReducedPer = 0;
                        $("#hUseCaseAutoMTTR_"+i).html("0");

                    }
                    else{
                        effReducedPer  = 100 - ((data[i].AutomationMTTR * 100) / data[i].ManualMTTR);
                        $("#hUseCaseAutoMTTR_"+i).html(Math.round(data[i].AutomationMTTR),0);
                    }
                
                 

                
                

                 var myCircle = Circles.create({
                  id:                  'circles-effreduced-'+i,
                  radius:              40,
                  value:               Math.round(effReducedPer),  // bind one arg    Math.round(effReducedPer,0)
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['', '#56e6c3'],
                  duration:            0,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });

            }
            
             useCase.BuildCategoryMultiselect(category)
        }) 
   

                       },


                       bindUseCaseDeletion : function(){/* 
                     
 var Deletion;
                     
    httpService.get(url +"GetCustomerUseCaseWise/" + useCase.defaults.customerId).subscribe(
        data => {
            console.log("---data Deletion----");
            this.Deletion = data as string [];
            console.log( this.Deletion);
        },
        (err: HttpErrorResponse) => {
          console.log (err.message);
        }
      );
 */
                       },
    BuildCategoryMultiselect: function(category)
    {
        var content = ""
        content += '<optgroup label="All">';
        for(var i=0; i < category.length;i++)
        {
            content += '<option selected="true" value="'+ category[i]+'">'+ category[i]+'</option>';
        }
         content += '</optgroup>';

        $("#option-droup-demo").html(content);
       $("#option-droup-demo").multiselect('rebuild');

    },
    filterByCategory: function(option,checked)
    {
        
        var selectedValue = $('select#option-droup-demo').val();
        
        $("#dvUseCaseContainer div.section-wrape").each(function(i){
            $(this).fadeOut(500);               
        })
        
        for(var i = 0;i< selectedValue.length;i++)
        {
            
            var parentCategory = selectedValue[i].split(' (')[0]
            var childCategory = selectedValue[i].split(' (')[1].replace(')','')
            
              $("#dvUseCaseContainer div.section-wrape").each(function(i){
              
                if($(this).attr('data-parentCat').toLowerCase() == parentCategory.toLowerCase() && $(this).attr('data-childCat').toLowerCase() == childCategory.toLowerCase())
                {
                    $(this).fadeIn(500);
                }
            })
        }
        
        if(selectedValue.length == 0)
        {
             $("#dvUseCaseContainer div.section-wrape").each(function(i){
                $(this).fadeIn(500);            
            })
        }
    }




                }
              
useCase.init();

              
       }

       

       filter_by_category(){
          console.log("filter");
       }

  }


