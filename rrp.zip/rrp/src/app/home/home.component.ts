import { Component, OnInit } from '@angular/core';


import * as $ from "jquery";
declare var $: $
declare var session: any; 
declare var userSession: any; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
 
  }

}
