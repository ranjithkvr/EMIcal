import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor{

  constructor(private injector: Injectable) { }

  intercept(req, next){
  		let tokenizedReq = req.clone({
              setHeader: {
                Authorization : 'Basic ZWxhc3RpYzpwYXNzd29yZDEyMw=='
              }

  		})
  		console.log(tokenizedReq);
  		return next.handle(tokenizedReq)
  }

  getToken(){

  }
}
